if False:
    from typing import Dict, List, Tuple, Union, Optional

def registerTemplate(classPath, nodeType): pass
def addCustom(obj): pass
def registeredTypes(): pass

