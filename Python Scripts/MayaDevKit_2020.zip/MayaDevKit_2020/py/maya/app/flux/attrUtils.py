if False:
    from typing import Dict, List, Tuple, Union, Optional

def attrType(nodeType, attribute): pass
def niceName(nodeType, attribute): pass
def registerNiceNames(namesMap): pass
def checkNiceNames(namesMap): pass

