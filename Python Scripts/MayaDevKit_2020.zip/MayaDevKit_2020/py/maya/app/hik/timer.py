if False:
    from typing import Dict, List, Tuple, Union, Optional

import threading

class TimerObj(threading.Thread):
    def __init__(self, runTime, command): pass
    def run(self): pass




def startTimer(runTime, command): pass
def prepMelCommand(commandString):
    """
    ######################
    #       functions
    ######################
    """
    pass

