from PySide2.QtCore import Slot


if False:
    from typing import Dict, List, Tuple, Union, Optional

class ScriptJobWrapper:
    def __del__(self): pass
    def __init__(self, scriptJobId): pass




def getSelectionStatistics(): pass
def openWebDocs(command, lang): pass
def unwrapInstance(*args, **kwargs): pass
def getRelatives(name): pass
def getSelectedNodes(): pass
def mayaPrefsFolder(): pass
def loadInconsolata(): pass
def wrapInstance(*args, **kwargs): pass
def onMayaQuitCallback(func): pass
def rgbToHex(color): pass
def printSelectionStatistics(): pass
def getAssignCommandAnnotation(index): pass
def getAssignCommandHotkey(index): pass
def hexToRGB(color): pass
def getAssignCommandsMap(): pass
def openWebSearch(search): pass
def getNodeType(name): pass
def getSuggestedContext(): pass

