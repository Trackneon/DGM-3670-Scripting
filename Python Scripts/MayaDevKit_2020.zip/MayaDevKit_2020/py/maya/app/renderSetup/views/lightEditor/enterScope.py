if False:
    from typing import Dict, List, Tuple, Union, Optional

class EnterLightScope:
    def __enter__(self): pass
    def __exit__(self, type, value, traceback): pass
    def __init__(self, model): pass


class EnterMayaScope:
    def __enter__(self): pass
    def __exit__(self, type, value, traceback): pass
    def __init__(self, model): pass



