if False:
    from typing import Dict, List, Tuple, Union, Optional

kInvalidAttribute = []

kDragAttributeFromAE = []

kLayer = []

kAppliedToUnique = []

kIncompatibleAttribute = []


