from PySide2.QtGui import QStandardItem


if False:
    from typing import Dict, List, Tuple, Union, Optional

class StandardItem(QStandardItem):
    def __eq__(self, o): pass
    def __ne__(self, o): pass
    def depth(self): pass



