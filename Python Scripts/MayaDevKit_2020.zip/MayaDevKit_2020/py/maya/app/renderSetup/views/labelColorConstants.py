if False:
    from typing import Dict, List, Tuple, Union, Optional

kDefault = []

kRed = []

LABEL_COLORS = []

kGreen = []

kOrange = []

kLabelColor = []

kBlue = []

kViolet = []

colors = {}

kYellow = []


