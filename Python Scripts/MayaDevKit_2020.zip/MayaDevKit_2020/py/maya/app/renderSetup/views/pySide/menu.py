from PySide2.QtGui import QCursor
from PySide2.QtWidgets import QToolTip
from PySide2.QtWidgets import QMenu


if False:
    from typing import Dict, List, Tuple, Union, Optional

class Menu(QMenu):
    def __init__(self, title, parent='None'): pass
    def handleMenuHovered(self, action): pass
    staticMetaObject = None



