if False:
    from typing import Dict, List, Tuple, Union, Optional

class SerializableNode(object):
    def __init__(self): pass
    def copyForClipboard(self, notes='None'): pass
    def decode(self, dict, mergeType, prependToName): pass
    def encode(self, notes='None'): pass
    __dict__ = None
    
    
    __weakref__ = None



