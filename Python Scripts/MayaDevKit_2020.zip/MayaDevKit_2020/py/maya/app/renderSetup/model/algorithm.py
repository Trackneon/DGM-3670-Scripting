from collections import deque
from maya.app.renderSetup.model.memberSet import MemberSet


if False:
    from typing import Dict, List, Tuple, Union, Optional

def traverseDepthFirst(objs, direction='0', predicate="'<function <lambda>>'"): pass
def _traverseOne(obj, nexts, predicate, visited): pass
def traverseBreadthFirst(objs, direction='0', predicate="'<function <lambda>>'"): pass
def traverse(objs, strategy='0', direction='0', predicate="'<function <lambda>>'"): pass
def _hierarchy(path): pass
def _getSources(node): pass
def _getDestinations(node): pass
def hierarchy(paths): pass


kBreadthFirst = 1

kDepthFirst = 0

kUpstream = kDepthFirst

