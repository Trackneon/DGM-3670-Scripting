from maya.app.renderSetup.lightEditor.model.light import LightItem
from maya.app.renderSetup.lightEditor.model.group import LightGroup


if False:
    from typing import Dict, List, Tuple, Union, Optional

def uninitialize(mplugin): pass
def initialize(mplugin): pass


proxyEntries = {}


