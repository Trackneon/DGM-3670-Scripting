from pkgutil import extend_path


if False:
    from typing import Dict, List, Tuple, Union, Optional

def finalize(*args, **kwargs):
    """
    Finalization function for Maya functionality when the interpreter shuts down
    """
    pass

