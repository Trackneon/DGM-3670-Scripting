"""
# Description:
#
"""


if False:
    from typing import Dict, List, Tuple, Union, Optional

def getVar(type, varName): pass
def setVar(type, varName, value): pass

