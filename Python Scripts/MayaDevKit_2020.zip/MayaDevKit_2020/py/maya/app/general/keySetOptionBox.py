if False:
    from typing import Dict, List, Tuple, Union, Optional

def keySetOptionBoxPreviewUIDeleted(ui_name, mel_callback): pass
def keySetOptionBoxPreviewUIDeletedCallback(data): pass

