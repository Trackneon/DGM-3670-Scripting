if False:
    from typing import Dict, List, Tuple, Union, Optional

def pyResult(resultString):
    """
    print a result message
    """
    pass
def pyError(errorString):
    """
    print an error message
    """
    pass
def zipScene(archiveUnloadedReferences): pass

