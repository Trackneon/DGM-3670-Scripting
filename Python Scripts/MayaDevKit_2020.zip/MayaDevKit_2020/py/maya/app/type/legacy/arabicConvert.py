if False:
    from typing import Dict, List, Tuple, Union, Optional

def convertText(text): pass
def canMegerBefore(ch): pass
def getConvertType(ch): pass
def filterAndCorrectArabic(hexText): pass
def isLamChar(a): pass
def isSpaceChar(a): pass
def inMergeRange(ch): pass
def convertCharacters(chars): pass
def convertLamAlef(ch, offset): pass
def convertChar(ch, offset): pass
def HexToUni(hexStr): pass
def isAlefChar(a): pass
def canMergeAfter(ch): pass
def ByteToHex(byteStr): pass
def isArabic(ch): pass


MERGE_MAP = []

MERGE_TYPE = []

t_start = 1

t_end = 2

t_middle = 3

t_none = 0


