from __builtin__ import object as _object
from __builtin__ import property as _swig_property


if False:
    from typing import Dict, List, Tuple, Union, Optional

class MEvaluationNode(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def child(self, *args): pass
    def childCount(self, *args): pass
    def connect(self, *args): pass
    def datablock(self, *args): pass
    def dependencyNode(self, *args): pass
    def dirtyPlug(self, *args): pass
    def dirtyPlugExists(self, *args): pass
    def iterator(self, *args): pass
    def parent(self, *args): pass
    def parentCount(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MRampAttribute(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addEntries(self, *args): pass
    def assign(self, *args): pass
    def deleteEntries(self, *args): pass
    def getColorAtPosition(self, *args): pass
    def getEntries(self, *args): pass
    def getNumEntries(self, *args): pass
    def getValueAtPosition(self, *args): pass
    def hasIndex(self, *args): pass
    def isColorRamp(self, *args): pass
    def isCurveRamp(self, *args): pass
    def pack(self, *args): pass
    def sampleColorRamp(self, *args): pass
    def sampleValueRamp(self, *args): pass
    def setColorAtIndex(self, *args): pass
    def setInterpolationAtIndex(self, *args): pass
    def setPositionAtIndex(self, *args): pass
    def setRamp(self, *args): pass
    def setValueAtIndex(self, *args): pass
    def sort(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def createColorRamp(*args, **kwargs): pass
    @staticmethod
    def createCurveRamp(*args, **kwargs): pass
    @staticmethod
    def createRamp(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kLinear = 1
    
    
    kNone = 0
    
    
    kSmooth = 2
    
    
    kSpline = 3


class MDagPathArray(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def append(self, *args): pass
    def assign(self, *args): pass
    def clear(self, *args): pass
    def copy(self, *args): pass
    def insert(self, *args): pass
    def length(self, *args): pass
    def remove(self, *args): pass
    def set(self, *args): pass
    def setLength(self, *args): pass
    def setSizeIncrement(self, *args): pass
    def sizeIncrement(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MMeshIntersector(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def getClosestPoint(self, *args): pass
    def isCreated(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MObject(_object):
    def __del__(self): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __ne__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def apiType(self, *args): pass
    def apiTypeStr(self, *args): pass
    def assign(self, *args): pass
    def hasFn(self, *args): pass
    def isNull(self, *args): pass
    @property
    def kNullObj(self): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class intPtr(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def cast(self, *args): pass
    def value(self, *args): pass
    @staticmethod
    def frompointer(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MTimeArray(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def append(self, *args): pass
    def assign(self, *args): pass
    def clear(self, *args): pass
    def copy(self, *args): pass
    def insert(self, *args): pass
    def length(self, *args): pass
    def remove(self, *args): pass
    def set(self, *args): pass
    def setLength(self, *args): pass
    def setSizeIncrement(self, *args): pass
    def sizeIncrement(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MItMeshEdge(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def center(self, *args): pass
    def cleanupSmoothing(self, *args): pass
    def connectedToEdge(self, *args): pass
    def connectedToFace(self, *args): pass
    def count(self, *args): pass
    def currentItem(self, *args): pass
    def edge(self, *args): pass
    def geomChanged(self, *args): pass
    def getConnectedEdges(self, *args): pass
    def getConnectedFaces(self, *args): pass
    def getLength(self, *args): pass
    def index(self, *args): pass
    def isDone(self, *args): pass
    def isSmooth(self, *args): pass
    def next(self, *args): pass
    def numConnectedEdges(self, *args): pass
    def numConnectedFaces(self, *args): pass
    def onBoundary(self, *args): pass
    def point(self, *args): pass
    def reset(self, *args): pass
    def setIndex(self, *args): pass
    def setPoint(self, *args): pass
    def setSmoothing(self, *args): pass
    def updateSurface(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class array2dDouble(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def get(self, *args): pass
    def getptr(self, *args): pass
    def set(self, *args): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MTimer(_object):
    def __del__(self): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __ne__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def beginTimer(self, *args): pass
    def clear(self, *args): pass
    def elapsedTime(self, *args): pass
    def endTimer(self, *args): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MItDependencyNodes(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def isDone(self, *args): pass
    def item(self, *args): pass
    def next(self, *args): pass
    def reset(self, *args): pass
    def thisNode(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MDagPath(_object):
    def __del__(self): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def apiType(self, *args): pass
    def assign(self, *args): pass
    def child(self, *args): pass
    def childCount(self, *args): pass
    def exclusiveMatrix(self, *args): pass
    def exclusiveMatrixInverse(self, *args): pass
    def extendToShape(self, *args): pass
    def extendToShapeDirectlyBelow(self, *args): pass
    def fullPathName(self, *args): pass
    def getAllPathsBelow(self, *args): pass
    def getDisplayStatus(self, *args): pass
    def getDrawOverrideInfo(self, *args): pass
    def getPath(self, *args): pass
    def hasFn(self, *args): pass
    def inclusiveMatrix(self, *args): pass
    def inclusiveMatrixInverse(self, *args): pass
    def instanceNumber(self, *args): pass
    def isInstanced(self, *args): pass
    def isTemplated(self, *args): pass
    def isValid(self, *args): pass
    def isVisible(self, *args): pass
    def length(self, *args): pass
    def node(self, *args): pass
    def numberOfShapesDirectlyBelow(self, *args): pass
    def partialPathName(self, *args): pass
    def pathCount(self, *args): pass
    def pop(self, *args): pass
    def push(self, *args): pass
    def set(self, *args): pass
    def transform(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def getAPathTo(*args, **kwargs): pass
    @staticmethod
    def getAllPathsTo(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MIntArray(_object):
    def __add__(self, *args): pass
    def __del__(self): pass
    def __delitem__(self, *args): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __iadd__(self, *args): pass
    def __init__(self, *args): pass
    def __len__(self, *args): pass
    def __ne__(self, *args): pass
    def __radd__(self, *args): pass
    def __repr__(self, *args): pass
    def __setattr__(self, name, value): pass
    def __setitem__(self, *args): pass
    def append(self, *args): pass
    def assign(self, *args): pass
    def clear(self, *args): pass
    def copy(self, *args): pass
    def get(self, *args): pass
    def insert(self, *args): pass
    def length(self, *args): pass
    def remove(self, *args): pass
    def set(self, *args): pass
    def setLength(self, *args): pass
    def setSizeIncrement(self, *args): pass
    def sizeIncrement(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class array4dFloat(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def get(self, *args): pass
    def getptr(self, *args): pass
    def set(self, *args): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class array3dFloat(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def get(self, *args): pass
    def getptr(self, *args): pass
    def set(self, *args): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MAttributePattern(_object):
    def __del__(self): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addRootAttr(self, *args): pass
    def assign(self, *args): pass
    def name(self, *args): pass
    def removeRootAttr(self, *args): pass
    def rootAttr(self, *args): pass
    def rootAttrCount(self, *args): pass
    @staticmethod
    def attrPattern(*args, **kwargs): pass
    @staticmethod
    def attrPatternCount(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def findPattern(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MRichSelection(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def clear(self, *args): pass
    def getSelection(self, *args): pass
    def getSymmetry(self, *args): pass
    def getSymmetryMatrix(self, *args): pass
    def getSymmetryPlane(self, *args): pass
    def setSelection(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MAttributePatternArray(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def append(self, *args): pass
    def assign(self, *args): pass
    def clear(self, *args): pass
    def copy(self, *args): pass
    def insert(self, *args): pass
    def length(self, *args): pass
    def remove(self, *args): pass
    def set(self, *args): pass
    def setLength(self, *args): pass
    def setSizeIncrement(self, *args): pass
    def sizeIncrement(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MItSubdEdge(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def index(self, *args): pass
    def isBoundary(self, *args): pass
    def isDone(self, *args): pass
    def isSharp(self, *args): pass
    def isValid(self, *args): pass
    def level(self, *args): pass
    def next(self, *args): pass
    def reset(self, *args): pass
    def setLevel(self, *args): pass
    def setSharpness(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MRenderPassRegistry(_object):
    def __getattr__(self, name): pass
    def __init__(self, *args, **kwargs): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def getRenderPassDefinition(*args, **kwargs): pass
    @staticmethod
    def registerRenderPassDefinition(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MItMeshPolygon(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def center(self, *args): pass
    def count(self, *args): pass
    def currentItem(self, *args): pass
    def geomChanged(self, *args): pass
    def getArea(self, *args): pass
    def getAxisAtUV(self, *args): pass
    def getColor(self, *args): pass
    def getColorIndex(self, *args): pass
    def getColorIndices(self, *args): pass
    def getColors(self, *args): pass
    def getConnectedEdges(self, *args): pass
    def getConnectedFaces(self, *args): pass
    def getConnectedVertices(self, *args): pass
    def getEdges(self, *args): pass
    def getNormal(self, *args): pass
    def getNormals(self, *args): pass
    def getPointAtUV(self, *args): pass
    def getPoints(self, *args): pass
    def getTriangle(self, *args): pass
    def getTriangles(self, *args): pass
    def getUV(self, *args): pass
    def getUVArea(self, *args): pass
    def getUVAtPoint(self, *args): pass
    def getUVIndex(self, *args): pass
    def getUVSetNames(self, *args): pass
    def getUVs(self, *args): pass
    def getVertices(self, *args): pass
    def hasColor(self, *args): pass
    def hasUVs(self, *args): pass
    def hasValidTriangulation(self, *args): pass
    def index(self, *args): pass
    def isConnectedToEdge(self, *args): pass
    def isConnectedToFace(self, *args): pass
    def isConnectedToVertex(self, *args): pass
    def isConvex(self, *args): pass
    def isDone(self, *args): pass
    def isHoled(self, *args): pass
    def isLamina(self, *args): pass
    def isPlanar(self, *args): pass
    def isStarlike(self, *args): pass
    def isUVReversed(self, *args): pass
    def next(self, *args): pass
    def normalIndex(self, *args): pass
    def numColors(self, *args): pass
    def numConnectedEdges(self, *args): pass
    def numConnectedFaces(self, *args): pass
    def numTriangles(self, *args): pass
    def onBoundary(self, *args): pass
    def point(self, *args): pass
    def polygon(self, *args): pass
    def polygonVertexCount(self, *args): pass
    def reset(self, *args): pass
    def setIndex(self, *args): pass
    def setPoint(self, *args): pass
    def setPoints(self, *args): pass
    def setUV(self, *args): pass
    def setUVs(self, *args): pass
    def tangentIndex(self, *args): pass
    def updateSurface(self, *args): pass
    def vertexIndex(self, *args): pass
    def zeroArea(self, *args): pass
    def zeroUVArea(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MVector(_object):
    def __add__(self, *args): pass
    def __call__(self, *args): pass
    def __del__(self): pass
    def __div__(self, *args): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __iadd__(self, *args): pass
    def __idiv__(self, *args): pass
    def __imul__(self, *args): pass
    def __init__(self, *args): pass
    def __isub__(self, *args): pass
    def __iter__(self):
        """
        Iterates on all components of a Maya api Vector
        """
        pass
    def __itruediv__(self, *args): pass
    def __len__(self):
        """
        Number of components in the Maya api Vector, ie 3
        """
        pass
    def __mul__(self, *args): pass
    def __ne__(self, *args): pass
    def __neg__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def __sub__(self, *args): pass
    def __truediv__(self, *args): pass
    def __xor__(self, *args): pass
    def angle(self, *args): pass
    def assign(self, *args): pass
    def get(self, *args): pass
    def isEquivalent(self, *args): pass
    def isParallel(self, *args): pass
    def length(self, *args): pass
    def normal(self, *args): pass
    def normalize(self, *args): pass
    def rotateBy(self, *args): pass
    def rotateTo(self, *args): pass
    def transformAsNormal(self, *args): pass
    @property
    def x(self): pass
    @property
    def y(self): pass
    @property
    def z(self): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kWaxis = 3
    
    
    kXaxis = 0
    
    
    kYaxis = 1
    
    
    kZaxis = 2
    
    
    one = None
    
    
    xAxis = None
    
    
    xNegAxis = None
    
    
    yAxis = None
    
    
    yNegAxis = None
    
    
    zAxis = None
    
    
    zNegAxis = None
    
    
    zero = None


class MFloatVectorArray(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def append(self, *args): pass
    def assign(self, *args): pass
    def clear(self, *args): pass
    def copy(self, *args): pass
    def get(self, *args): pass
    def insert(self, *args): pass
    def length(self, *args): pass
    def remove(self, *args): pass
    def set(self, *args): pass
    def setLength(self, *args): pass
    def setSizeIncrement(self, *args): pass
    def sizeIncrement(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MTrimBoundaryArray(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def append(self, *args): pass
    def clear(self, *args): pass
    def get(self, *args): pass
    def getMergedBoundary(self, *args): pass
    def insert(self, *args): pass
    def length(self, *args): pass
    def remove(self, *args): pass
    def reserve(self, *args): pass
    def set(self, *args): pass
    def size(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MPlugArray(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def append(self, *args): pass
    def assign(self, *args): pass
    def clear(self, *args): pass
    def copy(self, *args): pass
    def insert(self, *args): pass
    def length(self, *args): pass
    def remove(self, *args): pass
    def set(self, *args): pass
    def setLength(self, *args): pass
    def setSizeIncrement(self, *args): pass
    def sizeIncrement(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MIteratorType(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def filterListEnabled(self, *args): pass
    def getFilterList(self, *args): pass
    def getFilterType(self, *args): pass
    def getObjectType(self, *args): pass
    def setFilterList(self, *args): pass
    def setFilterType(self, *args): pass
    def setObjectType(self, *args): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kMDagPathObject = 1
    
    
    kMObject = 0
    
    
    kMPlugObject = 2


class MCommandResult(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def getResult(self, *args): pass
    def resultType(self, *args): pass
    def stringResult(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kDouble = 5
    
    
    kDoubleArray = 6
    
    
    kInt = 1
    
    
    kInt64 = 2
    
    
    kInt64Array = 4
    
    
    kIntArray = 3
    
    
    kInvalid = 0
    
    
    kMatrix = 11
    
    
    kMatrixArray = 12
    
    
    kString = 7
    
    
    kStringArray = 8
    
    
    kVector = 9
    
    
    kVectorArray = 10


class MIffTag(_object):
    def __del__(self): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kCAT = None
    
    
    kCAT4 = None
    
    
    kCAT8 = None
    
    
    kFOR4 = None
    
    
    kFOR8 = None
    
    
    kFORM = None
    
    
    kLIS4 = None
    
    
    kLIS8 = None
    
    
    kLIST = None
    
    
    kPRO4 = None
    
    
    kPRO8 = None
    
    
    kPROP = None


class uIntPtr(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def cast(self, *args): pass
    def value(self, *args): pass
    @staticmethod
    def frompointer(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MArgList(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addArg(self, *args): pass
    def asAngle(self, *args): pass
    def asBool(self, *args): pass
    def asDistance(self, *args): pass
    def asDouble(self, *args): pass
    def asDoubleArray(self, *args): pass
    def asInt(self, *args): pass
    def asIntArray(self, *args): pass
    def asMatrix(self, *args): pass
    def asPoint(self, *args): pass
    def asString(self, *args): pass
    def asStringArray(self, *args): pass
    def asTime(self, *args): pass
    def asVector(self, *args): pass
    def assign(self, *args): pass
    def flagIndex(self, *args): pass
    def length(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kInvalidArgIndex = 4294967295L


class MEdit(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args, **kwargs): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def editType(self, *args): pass
    def getString(self, *args): pass
    def hasEditData(self, *args): pass
    def isApplied(self, *args): pass
    def isFailed(self, *args): pass
    def isTopLevel(self, *args): pass
    def matches(self, *args): pass
    def setApplied(self, *args): pass
    def setFailed(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kAddRemoveAttrEdit = 3
    
    
    kConnectDisconnectEdit = 2
    
    
    kFcurveEdit = 5
    
    
    kNullEdit = 0
    
    
    kParentEdit = 4
    
    
    kSetAttrEdit = 1


class MBoundingBox(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def center(self, *args): pass
    def clear(self, *args): pass
    def contains(self, *args): pass
    def depth(self, *args): pass
    def expand(self, *args): pass
    def height(self, *args): pass
    def intersects(self, *args): pass
    def max(self, *args): pass
    def min(self, *args): pass
    def transformUsing(self, *args): pass
    def width(self, *args): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MNurbsIntersector(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def getClosestPoint(self, *args): pass
    def getIntersect(self, *args): pass
    def getIntersects(self, *args): pass
    def isCreated(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class array4dDouble(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def get(self, *args): pass
    def getptr(self, *args): pass
    def set(self, *args): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MFloatMatrix(_object):
    def __add__(self, *args): pass
    def __call__(self, *args): pass
    def __del__(self): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __iadd__(self, *args): pass
    def __imul__(self, *args): pass
    def __init__(self, *args): pass
    def __isub__(self, *args): pass
    def __iter__(self):
        """
        Iterates on all 4 rows of a Maya api FloatMatrix
        """
        pass
    def __len__(self):
        """
        Number of rows in the Maya api FloatMatrix, ie 4.
        Not to be confused with the number of components (16) given by the size method
        """
        pass
    def __mul__(self, *args): pass
    def __ne__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def __sub__(self, *args): pass
    def adjoint(self, *args): pass
    def assign(self, *args): pass
    def det3x3(self, *args): pass
    def det4x4(self, *args): pass
    def get(self, *args): pass
    def homogenize(self, *args): pass
    def inverse(self, *args): pass
    def isEquivalent(self, *args): pass
    def setToIdentity(self, *args): pass
    def setToProduct(self, *args): pass
    def transpose(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @property
    def matrix(self): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MTime(_object):
    def __add__(self, *args): pass
    def __del__(self): pass
    def __div__(self, *args): pass
    def __eq__(self, *args): pass
    def __ge__(self, *args): pass
    def __getattr__(self, name): pass
    def __gt__(self, *args): pass
    def __iadd__(self, *args): pass
    def __idiv__(self, *args): pass
    def __imul__(self, *args): pass
    def __init__(self, *args): pass
    def __isub__(self, *args): pass
    def __itruediv__(self, *args): pass
    def __le__(self, *args): pass
    def __lt__(self, *args): pass
    def __mul__(self, *args): pass
    def __ne__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def __sub__(self, *args): pass
    def __truediv__(self, *args): pass
    def asUnits(self, *args): pass
    def assign(self, *args): pass
    def setUnit(self, *args): pass
    def setValue(self, *args): pass
    def unit(self, *args): pass
    def value(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def setUIUnit(*args, **kwargs): pass
    @staticmethod
    def ticksPerSecond(*args, **kwargs): pass
    @staticmethod
    def uiUnit(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    k100FPS = 25
    
    
    k10FPS = 18
    
    
    k1200FPS = 38
    
    
    k120FPS = 26
    
    
    k125FPS = 27
    
    
    k12FPS = 19
    
    
    k1500FPS = 39
    
    
    k150FPS = 28
    
    
    k15FPS = 5
    
    
    k16FPS = 20
    
    
    k2000FPS = 40
    
    
    k200FPS = 29
    
    
    k20FPS = 21
    
    
    k23_976FPS = 43
    
    
    k240FPS = 30
    
    
    k24FPS = 6
    
    
    k250FPS = 31
    
    
    k25FPS = 7
    
    
    k29_97DF = 45
    
    
    k29_97FPS = 44
    
    
    k2FPS = 12
    
    
    k3000FPS = 41
    
    
    k300FPS = 32
    
    
    k30FPS = 8
    
    
    k375FPS = 33
    
    
    k3FPS = 13
    
    
    k400FPS = 34
    
    
    k40FPS = 22
    
    
    k44100FPS = 48
    
    
    k47_952FPS = 46
    
    
    k48000FPS = 49
    
    
    k48FPS = 9
    
    
    k4FPS = 14
    
    
    k500FPS = 35
    
    
    k50FPS = 10
    
    
    k59_94FPS = 47
    
    
    k5FPS = 15
    
    
    k6000FPS = 42
    
    
    k600FPS = 36
    
    
    k60FPS = 11
    
    
    k6FPS = 16
    
    
    k750FPS = 37
    
    
    k75FPS = 23
    
    
    k80FPS = 24
    
    
    k8FPS = 17
    
    
    k90FPS = 50
    
    
    kFilm = 6
    
    
    kGames = 5
    
    
    kHours = 1
    
    
    kInvalid = 0
    
    
    kLast = 52
    
    
    kMilliseconds = 4
    
    
    kMinutes = 2
    
    
    kNTSCField = 11
    
    
    kNTSCFrame = 8
    
    
    kPALField = 10
    
    
    kPALFrame = 7
    
    
    kSeconds = 3
    
    
    kShowScan = 9
    
    
    kUserDef = 51


class MInt64Array(_object):
    def __add__(self, *args): pass
    def __del__(self): pass
    def __delitem__(self, *args): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __iadd__(self, *args): pass
    def __init__(self, *args): pass
    def __len__(self, *args): pass
    def __ne__(self, *args): pass
    def __radd__(self, *args): pass
    def __repr__(self, *args): pass
    def __setattr__(self, name, value): pass
    def __setitem__(self, *args): pass
    def append(self, *args): pass
    def assign(self, *args): pass
    def clear(self, *args): pass
    def copy(self, *args): pass
    def get(self, *args): pass
    def insert(self, *args): pass
    def length(self, *args): pass
    def remove(self, *args): pass
    def set(self, *args): pass
    def setLength(self, *args): pass
    def setSizeIncrement(self, *args): pass
    def sizeIncrement(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MMessage(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def currentCallbackId(*args, **kwargs): pass
    @staticmethod
    def nodeCallbacks(*args, **kwargs): pass
    @staticmethod
    def registeringCallableScript(*args, **kwargs): pass
    @staticmethod
    def registeringCallableScriptNewAPI(*args, **kwargs): pass
    @staticmethod
    def removeCallback(*args, **kwargs): pass
    @staticmethod
    def removeCallbacks(*args, **kwargs): pass
    @staticmethod
    def setRegisteringCallableScript(*args, **kwargs): pass
    @staticmethod
    def setRegisteringCallableScriptNewAPI(*args, **kwargs): pass
    @staticmethod
    def stopRegisteringCallableScript(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kDefaultAction = 0
    
    
    kDoAction = 2
    
    
    kDoNotDoAction = 1


class array4dInt(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def get(self, *args): pass
    def getptr(self, *args): pass
    def set(self, *args): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MSelectionMask(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __or__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addMask(self, *args): pass
    def assign(self, *args): pass
    def intersects(self, *args): pass
    def setMask(self, *args): pass
    @staticmethod
    def deregisterSelectionType(*args, **kwargs): pass
    @staticmethod
    def getSelectionTypePriority(*args, **kwargs): pass
    @staticmethod
    def registerSelectionType(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kSelectAnimAny = 68
    
    
    kSelectAnimCurves = 63
    
    
    kSelectAnimInTangents = 65
    
    
    kSelectAnimKeyframes = 64
    
    
    kSelectAnimMask = 67
    
    
    kSelectAnimOutTangents = 66
    
    
    kSelectCVs = 30
    
    
    kSelectCameras = 6
    
    
    kSelectClusters = 8
    
    
    kSelectCollisionModels = 21
    
    
    kSelectComponentsMask = 62
    
    
    kSelectCurveKnots = 47
    
    
    kSelectCurveParmPoints = 46
    
    
    kSelectCurves = 26
    
    
    kSelectCurvesOnSurfaces = 53
    
    
    kSelectDynamicConstraints = 82
    
    
    kSelectEdges = 42
    
    
    kSelectEditPoints = 32
    
    
    kSelectEmitters = 16
    
    
    kSelectFacets = 43
    
    
    kSelectFields = 17
    
    
    kSelectFluids = 77
    
    
    kSelectFollicles = 79
    
    
    kSelectGuideLines = 71
    
    
    kSelectHairSystems = 78
    
    
    kSelectHandles = 0
    
    
    kSelectHulls = 31
    
    
    kSelectIkEndEffectors = 3
    
    
    kSelectIkHandles = 2
    
    
    kSelectIsoparms = 52
    
    
    kSelectJointPivots = 57
    
    
    kSelectJoints = 4
    
    
    kSelectLatticePoints = 55
    
    
    kSelectLattices = 7
    
    
    kSelectLights = 5
    
    
    kSelectLocalAxis = 1
    
    
    kSelectLocators = 28
    
    
    kSelectManipulators = 70
    
    
    kSelectMeshComponents = 45
    
    
    kSelectMeshEdges = 34
    
    
    kSelectMeshFaces = 36
    
    
    kSelectMeshFreeEdges = 35
    
    
    kSelectMeshLines = 44
    
    
    kSelectMeshUVs = 40
    
    
    kSelectMeshVerts = 33
    
    
    kSelectMeshes = 12
    
    
    kSelectNCloths = 80
    
    
    kSelectNParticles = 83
    
    
    kSelectNRigids = 81
    
    
    kSelectNurbsCurves = 10
    
    
    kSelectNurbsSurfaces = 11
    
    
    kSelectObjectGroups = 75
    
    
    kSelectObjectsMask = 29
    
    
    kSelectOrientationLocators = 23
    
    
    kSelectPPStrokes = 54
    
    
    kSelectParticleShapes = 15
    
    
    kSelectParticles = 56
    
    
    kSelectPivots = 60
    
    
    kSelectPointsForGravity = 72
    
    
    kSelectPointsOnCurvesForGravity = 73
    
    
    kSelectPointsOnSurfacesForGravity = 74
    
    
    kSelectRigidBodies = 19
    
    
    kSelectRigidConstraints = 20
    
    
    kSelectRotatePivots = 59
    
    
    kSelectScalePivots = 58
    
    
    kSelectSculpts = 9
    
    
    kSelectSelectHandles = 61
    
    
    kSelectSketchPlanes = 14
    
    
    kSelectSprings = 18
    
    
    kSelectSubdiv = 13
    
    
    kSelectSubdivMeshEdges = 38
    
    
    kSelectSubdivMeshFaces = 39
    
    
    kSelectSubdivMeshMaps = 76
    
    
    kSelectSubdivMeshPoints = 37
    
    
    kSelectSurfaceEdge = 51
    
    
    kSelectSurfaceKnots = 49
    
    
    kSelectSurfaceParmPoints = 48
    
    
    kSelectSurfaceRange = 50
    
    
    kSelectSurfaces = 27
    
    
    kSelectTemplates = 69
    
    
    kSelectTextures = 25
    
    
    kSelectUVLocators = 24
    
    
    kSelectVertices = 41
    
    
    kSelectXYZLocators = 22


class MProfiler(_object):
    def __getattr__(self, name): pass
    def __init__(self, *args, **kwargs): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def addCategory(*args, **kwargs): pass
    @staticmethod
    def categoryRecording(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def eventBegin(*args, **kwargs): pass
    @staticmethod
    def eventDataAvailable(*args, **kwargs): pass
    @staticmethod
    def eventEnd(*args, **kwargs): pass
    @staticmethod
    def getAllCategories(*args, **kwargs): pass
    @staticmethod
    def getBufferSize(*args, **kwargs): pass
    @staticmethod
    def getCPUId(*args, **kwargs): pass
    @staticmethod
    def getCategoryIndex(*args, **kwargs): pass
    @staticmethod
    def getCategoryInfo(*args, **kwargs): pass
    @staticmethod
    def getCategoryName(*args, **kwargs): pass
    @staticmethod
    def getColor(*args, **kwargs): pass
    @staticmethod
    def getDescription(*args, **kwargs): pass
    @staticmethod
    def getEventCategory(*args, **kwargs): pass
    @staticmethod
    def getEventCount(*args, **kwargs): pass
    @staticmethod
    def getEventDuration(*args, **kwargs): pass
    @staticmethod
    def getEventName(*args, **kwargs): pass
    @staticmethod
    def getEventTime(*args, **kwargs): pass
    @staticmethod
    def getNumberOfCPUs(*args, **kwargs): pass
    @staticmethod
    def getThreadDuration(*args, **kwargs): pass
    @staticmethod
    def getThreadId(*args, **kwargs): pass
    @staticmethod
    def isDataFromFile(*args, **kwargs): pass
    @staticmethod
    def isSignalEvent(*args, **kwargs): pass
    @staticmethod
    def loadRecording(*args, **kwargs): pass
    @staticmethod
    def recordingActive(*args, **kwargs): pass
    @staticmethod
    def removeCategory(*args, **kwargs): pass
    @staticmethod
    def resetRecording(*args, **kwargs): pass
    @staticmethod
    def saveRecording(*args, **kwargs): pass
    @staticmethod
    def setBufferSize(*args, **kwargs): pass
    @staticmethod
    def setCategoryRecording(*args, **kwargs): pass
    @staticmethod
    def setRecordingActive(*args, **kwargs): pass
    @staticmethod
    def signalEvent(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kColorA_L1 = 0
    
    
    kColorA_L2 = 1
    
    
    kColorA_L3 = 2
    
    
    kColorB_L1 = 3
    
    
    kColorB_L2 = 4
    
    
    kColorB_L3 = 5
    
    
    kColorC_L1 = 6
    
    
    kColorC_L2 = 7
    
    
    kColorC_L3 = 8
    
    
    kColorCount = 18
    
    
    kColorD_L1 = 9
    
    
    kColorD_L2 = 10
    
    
    kColorD_L3 = 11
    
    
    kColorE_L1 = 12
    
    
    kColorE_L2 = 13
    
    
    kColorE_L3 = 14
    
    
    kColorG_L1 = 15
    
    
    kColorG_L2 = 16
    
    
    kColorG_L3 = 17


class MUuid(_object):
    def __del__(self): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __ne__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def asString(self, *args): pass
    def assign(self, *args): pass
    def copy(self, *args): pass
    def generate(self, *args): pass
    def get(self, *args): pass
    def valid(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MItDependencyGraph(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def atNodeLevel(self, *args): pass
    def currentDirection(self, *args): pass
    def currentFilter(self, *args): pass
    def currentItem(self, *args): pass
    def currentLevel(self, *args): pass
    def currentTraversal(self, *args): pass
    def disablePruningOnFilter(self, *args): pass
    def enablePruningOnFilter(self, *args): pass
    def getNodePath(self, *args): pass
    def getNodesVisited(self, *args): pass
    def getPlugPath(self, *args): pass
    def getPlugsVisited(self, *args): pass
    def isDirectionDownStream(self, *args): pass
    def isDone(self, *args): pass
    def isPruningOnFilter(self, *args): pass
    def isTraversalDepthFirst(self, *args): pass
    def isTraversingOverWorldSpaceDependents(self, *args): pass
    def next(self, *args): pass
    def previousPlug(self, *args): pass
    def prune(self, *args): pass
    def reset(self, *args): pass
    def resetFilter(self, *args): pass
    def resetTo(self, *args): pass
    def rootNode(self, *args): pass
    def rootPlug(self, *args): pass
    def setCurrentFilter(self, *args): pass
    def setTraversalOverWorldSpaceDependents(self, *args): pass
    def thisNode(self, *args): pass
    def thisNodeHasUnknownType(self, *args): pass
    def thisPlug(self, *args): pass
    def toggleDirection(self, *args): pass
    def toggleLevel(self, *args): pass
    def toggleTraversal(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kBreadthFirst = 1
    
    
    kDepthFirst = 0
    
    
    kDownstream = 0
    
    
    kNodeLevel = 0
    
    
    kPlugLevel = 1
    
    
    kUpstream = 1


class MMeshIsectAccelParams(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MUint64Array(_object):
    def __add__(self, *args): pass
    def __del__(self): pass
    def __delitem__(self, *args): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __iadd__(self, *args): pass
    def __init__(self, *args): pass
    def __len__(self, *args): pass
    def __ne__(self, *args): pass
    def __radd__(self, *args): pass
    def __repr__(self, *args): pass
    def __setattr__(self, name, value): pass
    def __setitem__(self, *args): pass
    def append(self, *args): pass
    def assign(self, *args): pass
    def clear(self, *args): pass
    def copy(self, *args): pass
    def get(self, *args): pass
    def insert(self, *args): pass
    def length(self, *args): pass
    def remove(self, *args): pass
    def set(self, *args): pass
    def setLength(self, *args): pass
    def setSizeIncrement(self, *args): pass
    def sizeIncrement(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MMatrix(_object):
    def __add__(self, *args): pass
    def __call__(self, *args): pass
    def __del__(self): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __iadd__(self, *args): pass
    def __imul__(self, *args): pass
    def __init__(self, *args): pass
    def __isub__(self, *args): pass
    def __iter__(self):
        """
        Iterates on all 4 rows of a Maya api Matrix
        """
        pass
    def __len__(self):
        """
        Number of rows in the Maya api Matrix, ie 4.
        Not to be confused with the number of components (16) given by the size method
        """
        pass
    def __mul__(self, *args): pass
    def __ne__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def __sub__(self, *args): pass
    def adjoint(self, *args): pass
    def assign(self, *args): pass
    def det3x3(self, *args): pass
    def det4x4(self, *args): pass
    def get(self, *args): pass
    def homogenize(self, *args): pass
    def inverse(self, *args): pass
    def isEquivalent(self, *args): pass
    def isSingular(self, *args): pass
    def setToIdentity(self, *args): pass
    def setToProduct(self, *args): pass
    def transpose(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @property
    def matrix(self): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    identity = None


class MArrayDataBuilder(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addElement(self, *args): pass
    def addElementArray(self, *args): pass
    def addLast(self, *args): pass
    def addLastArray(self, *args): pass
    def assign(self, *args): pass
    def elementCount(self, *args): pass
    def growArray(self, *args): pass
    def removeElement(self, *args): pass
    def setGrowSize(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MDGContextGuard(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MPoint(_object):
    def __add__(self, *args): pass
    def __call__(self, *args): pass
    def __del__(self): pass
    def __div__(self, *args): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __iadd__(self, *args): pass
    def __imul__(self, *args): pass
    def __init__(self, *args): pass
    def __isub__(self, *args): pass
    def __iter__(self):
        """
        Iterates on all components of a Maya api Point
        """
        pass
    def __len__(self):
        """
        Number of components in the Maya api Point, ie 4
        """
        pass
    def __mul__(self, *args): pass
    def __ne__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def __sub__(self, *args): pass
    def __truediv__(self, *args): pass
    def assign(self, *args): pass
    def cartesianize(self, *args): pass
    def distanceTo(self, *args): pass
    def get(self, *args): pass
    def homogenize(self, *args): pass
    def isEquivalent(self, *args): pass
    def rationalize(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @property
    def w(self): pass
    @property
    def x(self): pass
    @property
    def y(self): pass
    @property
    def z(self): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    origin = None


class MItSubdVertex(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def index(self, *args): pass
    def isDone(self, *args): pass
    def isValid(self, *args): pass
    def level(self, *args): pass
    def next(self, *args): pass
    def reset(self, *args): pass
    def setLevel(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MWeight(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def influence(self, *args): pass
    def seam(self, *args): pass
    def setInfluence(self, *args): pass
    def setSeam(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MUserData(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def deleteAfterUse(self, *args): pass
    def setDeleteAfterUse(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MFloatPointArray(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def append(self, *args): pass
    def assign(self, *args): pass
    def clear(self, *args): pass
    def copy(self, *args): pass
    def get(self, *args): pass
    def insert(self, *args): pass
    def length(self, *args): pass
    def remove(self, *args): pass
    def set(self, *args): pass
    def setLength(self, *args): pass
    def setSizeIncrement(self, *args): pass
    def sizeIncrement(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MVectorArray(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def append(self, *args): pass
    def assign(self, *args): pass
    def clear(self, *args): pass
    def copy(self, *args): pass
    def get(self, *args): pass
    def insert(self, *args): pass
    def length(self, *args): pass
    def remove(self, *args): pass
    def set(self, *args): pass
    def setLength(self, *args): pass
    def setSizeIncrement(self, *args): pass
    def sizeIncrement(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class shortPtr(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def cast(self, *args): pass
    def value(self, *args): pass
    @staticmethod
    def frompointer(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class array3dDouble(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def get(self, *args): pass
    def getptr(self, *args): pass
    def set(self, *args): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MPointArray(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def append(self, *args): pass
    def assign(self, *args): pass
    def clear(self, *args): pass
    def copy(self, *args): pass
    def get(self, *args): pass
    def insert(self, *args): pass
    def length(self, *args): pass
    def remove(self, *args): pass
    def set(self, *args): pass
    def setLength(self, *args): pass
    def setSizeIncrement(self, *args): pass
    def sizeIncrement(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MObjectHandle(_object):
    def __del__(self): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __ne__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def hashCode(self, *args): pass
    def isAlive(self, *args): pass
    def isValid(self, *args): pass
    def object(self, *args): pass
    def objectRef(self, *args): pass
    @staticmethod
    def objectHashCode(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MItSelectionList(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def getDagPath(self, *args): pass
    def getDependNode(self, *args): pass
    def getPlug(self, *args): pass
    def getStrings(self, *args): pass
    def hasComponents(self, *args): pass
    def isDone(self, *args): pass
    def itemType(self, *args): pass
    def next(self, *args): pass
    def reset(self, *args): pass
    def setFilter(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kAnimSelectionItem = 1
    
    
    kDNselectionItem = 2
    
    
    kDagSelectionItem = 0
    
    
    kPlugSelectionItem = 3
    
    
    kUnknownItem = -1


class MDataBlock(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args, **kwargs): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def context(self, *args): pass
    def inputArrayValue(self, *args): pass
    def inputValue(self, *args): pass
    def isClean(self, *args): pass
    def outputArrayValue(self, *args): pass
    def outputValue(self, *args): pass
    def setClean(self, *args): pass
    def setContext(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MAttributeIndex(_object):
    def __del__(self): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __ne__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def getLower(self, *args): pass
    def getUpper(self, *args): pass
    def getValue(self, *args): pass
    def hasLowerBound(self, *args): pass
    def hasRange(self, *args): pass
    def hasUpperBound(self, *args): pass
    def hasValidRange(self, *args): pass
    def isBounded(self, *args): pass
    def setLower(self, *args): pass
    def setType(self, *args): pass
    def setUpper(self, *args): pass
    def setValue(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kFloat = 1
    
    
    kInteger = 0


class MPlane(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def directedDistance(self, *args): pass
    def distance(self, *args): pass
    def normal(self, *args): pass
    def setPlane(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MItCurveCV(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def currentItem(self, *args): pass
    def cv(self, *args): pass
    def hasHistoryOnCreate(self, *args): pass
    def index(self, *args): pass
    def isDone(self, *args): pass
    def next(self, *args): pass
    def position(self, *args): pass
    def reset(self, *args): pass
    def setPosition(self, *args): pass
    def translateBy(self, *args): pass
    def updateCurve(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MDAGDrawOverrideInfo(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @property
    def fDisplayType(self): pass
    @property
    def fEnableShading(self): pass
    @property
    def fEnableTexturing(self): pass
    @property
    def fEnableVisible(self): pass
    @property
    def fLOD(self): pass
    @property
    def fOverrideEnabled(self): pass
    @property
    def fPlaybackVisible(self): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kDisplayTypeNormal = 0
    
    
    kDisplayTypeReference = 1
    
    
    kDisplayTypeTemplate = 2
    
    
    kLODBoundingBox = 1
    
    
    kLODFull = 0


class MEvaluationManager(_object):
    def __getattr__(self, name): pass
    def __init__(self, *args, **kwargs): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def evaluationInExecution(*args, **kwargs): pass
    @staticmethod
    def evaluationManagerActive(*args, **kwargs): pass
    @staticmethod
    def graphConstructionActive(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MColor(_object):
    def __add__(self, *args): pass
    def __call__(self, *args): pass
    def __del__(self): pass
    def __div__(self, *args): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __iadd__(self, *args): pass
    def __idiv__(self, *args): pass
    def __imul__(self, *args): pass
    def __init__(self, *args): pass
    def __iter__(self):
        """
        Iterates on all components of a Maya api Color
        """
        pass
    def __itruediv__(self, *args): pass
    def __len__(self):
        """
        Number of components in the Maya api Color, ie 4
        """
        pass
    def __mul__(self, *args): pass
    def __ne__(self, *args): pass
    def __neg__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def __sub__(self, *args): pass
    def __truediv__(self, *args): pass
    def assign(self, *args): pass
    def get(self, *args): pass
    def set(self, *args): pass
    @property
    def a(self): pass
    @property
    def b(self): pass
    @property
    def g(self): pass
    @property
    def r(self): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kCMY = 2
    
    
    kCMYK = 3
    
    
    kHSV = 1
    
    
    kOpaqueBlack = None
    
    
    kRGB = 0


class MFileIO(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def beforeExportFilename(*args, **kwargs): pass
    @staticmethod
    def beforeExportUserFileTranslator(*args, **kwargs): pass
    @staticmethod
    def beforeImportFilename(*args, **kwargs): pass
    @staticmethod
    def beforeImportUserFileTranslator(*args, **kwargs): pass
    @staticmethod
    def beforeOpenFilename(*args, **kwargs): pass
    @staticmethod
    def beforeOpenUserFileTranslator(*args, **kwargs): pass
    @staticmethod
    def beforeReferenceFilename(*args, **kwargs): pass
    @staticmethod
    def beforeReferenceUserFileTranslator(*args, **kwargs): pass
    @staticmethod
    def beforeSaveFilename(*args, **kwargs): pass
    @staticmethod
    def beforeSaveUserFileTranslator(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def cleanReference(*args, **kwargs): pass
    @staticmethod
    def currentFile(*args, **kwargs): pass
    @staticmethod
    def currentlyReadingFileVersion(*args, **kwargs): pass
    @staticmethod
    def exportAll(*args, **kwargs): pass
    @staticmethod
    def exportAnim(*args, **kwargs): pass
    @staticmethod
    def exportAnimFromReference(*args, **kwargs): pass
    @staticmethod
    def exportAsReference(*args, **kwargs): pass
    @staticmethod
    def exportSelected(*args, **kwargs): pass
    @staticmethod
    def exportSelectedAnim(*args, **kwargs): pass
    @staticmethod
    def exportSelectedAnimFromReference(*args, **kwargs): pass
    @staticmethod
    def exportType(*args, **kwargs): pass
    @staticmethod
    def fileCurrentlyLoading(*args, **kwargs): pass
    @staticmethod
    def fileType(*args, **kwargs): pass
    @staticmethod
    def getErrorStatus(*args, **kwargs): pass
    @staticmethod
    def getFileTypes(*args, **kwargs): pass
    @staticmethod
    def getFiles(*args, **kwargs): pass
    @staticmethod
    def getLastTempFile(*args, **kwargs): pass
    @staticmethod
    def getReferenceConnectionsBroken(*args, **kwargs): pass
    @staticmethod
    def getReferenceConnectionsMade(*args, **kwargs): pass
    @staticmethod
    def getReferenceFileByNode(*args, **kwargs): pass
    @staticmethod
    def getReferenceNodes(*args, **kwargs): pass
    @staticmethod
    def getReferences(*args, **kwargs): pass
    @staticmethod
    def importFile(*args, **kwargs): pass
    @staticmethod
    def isImportingFile(*args, **kwargs): pass
    @staticmethod
    def isNewingFile(*args, **kwargs): pass
    @staticmethod
    def isOpeningFile(*args, **kwargs): pass
    @staticmethod
    def isReadingFile(*args, **kwargs): pass
    @staticmethod
    def isReferencingFile(*args, **kwargs): pass
    @staticmethod
    def isSavingReference(*args, **kwargs): pass
    @staticmethod
    def isWritingFile(*args, **kwargs): pass
    @staticmethod
    def latestMayaFileVersion(*args, **kwargs): pass
    @staticmethod
    def loadReference(*args, **kwargs): pass
    @staticmethod
    def loadReferenceByNode(*args, **kwargs): pass
    @staticmethod
    def mustRenameToSave(*args, **kwargs): pass
    @staticmethod
    def mustRenameToSaveMsg(*args, **kwargs): pass
    @staticmethod
    def newFile(*args, **kwargs): pass
    @staticmethod
    def open(*args, **kwargs): pass
    @staticmethod
    def reference(*args, **kwargs): pass
    @staticmethod
    def removeReference(*args, **kwargs): pass
    @staticmethod
    def resetError(*args, **kwargs): pass
    @staticmethod
    def save(*args, **kwargs): pass
    @staticmethod
    def saveAs(*args, **kwargs): pass
    @staticmethod
    def saveReference(*args, **kwargs): pass
    @staticmethod
    def setCurrentFile(*args, **kwargs): pass
    @staticmethod
    def setError(*args, **kwargs): pass
    @staticmethod
    def setMustRenameToSave(*args, **kwargs): pass
    @staticmethod
    def setMustRenameToSaveMsg(*args, **kwargs): pass
    @staticmethod
    def unloadReference(*args, **kwargs): pass
    @staticmethod
    def unloadReferenceByNode(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kExportTypeAll = 0
    
    
    kExportTypeAnim = 2
    
    
    kExportTypeAnimFromReference = 3
    
    
    kExportTypeAsReference = 4
    
    
    kExportTypeEdits = 5
    
    
    kExportTypePrefObjects = 6
    
    
    kExportTypeSelected = 1
    
    
    kForceDeleteNamespaceContent = 3
    
    
    kLoadAllReferences = 1
    
    
    kLoadDefault = 0
    
    
    kLoadNoReferences = 2
    
    
    kMergeNamespaceWithParentNamespace = 2
    
    
    kMergeNamespaceWithRootNamespace = 1
    
    
    kRemoveNamespaceIfEmpty = 0
    
    
    kVersion2008 = 144
    
    
    kVersion2009 = 147
    
    
    kVersion2010 = 152
    
    
    kVersion2011 = 156
    
    
    kVersion2012 = 161
    
    
    kVersion2013 = 167
    
    
    kVersion2014 = 179
    
    
    kVersion2015 = 184
    
    
    kVersion2016 = 192
    
    
    kVersion2016R2 = 198
    
    
    kVersion2017 = 201
    
    
    kVersion2017Update3 = 202
    
    
    kVersion2017Update4 = 203
    
    
    kVersion2018 = 210
    
    
    kVersion2018Update2 = 211
    
    
    kVersion2018Update3 = 212
    
    
    kVersion2018Update4 = 213
    
    
    kVersion2018Update5 = 214
    
    
    kVersion2019 = 232
    
    
    kVersion4_0 = 74
    
    
    kVersion4_5 = 83
    
    
    kVersion5_0 = 90
    
    
    kVersion6_0 = 105
    
    
    kVersion6_5 = 117
    
    
    kVersion7_0 = 128
    
    
    kVersion8_0 = 133
    
    
    kVersion8_5 = 139


class MTypeId(_object):
    def __del__(self): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __ne__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def id(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MMessageNode(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @property
    def fClientPtr(self): pass
    @property
    def fHeadNode(self): pass
    @property
    def fId(self): pass
    @property
    def fNextNode(self): pass
    @property
    def fServerPtr(self): pass
    @property
    def fSubClientPtr(self): pass
    @property
    def isValid(self): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MURI(_object):
    def __del__(self): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __ne__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addQueryItem(self, *args): pass
    def asString(self, *args): pass
    def assign(self, *args): pass
    def clear(self, *args): pass
    def copy(self, *args): pass
    def getAllQueryItemKeys(self, *args): pass
    def getAllQueryItemValues(self, *args): pass
    def getAuthority(self, *args): pass
    def getDirectory(self, *args): pass
    def getFileName(self, *args): pass
    def getFragment(self, *args): pass
    def getHost(self, *args): pass
    def getPassword(self, *args): pass
    def getPath(self, *args): pass
    def getPort(self, *args): pass
    def getQueryItemValue(self, *args): pass
    def getQueryPairDelimiter(self, *args): pass
    def getQueryValueDelimiter(self, *args): pass
    def getScheme(self, *args): pass
    def getUserInfo(self, *args): pass
    def getUserName(self, *args): pass
    def isEmpty(self, *args): pass
    def isValid(self, *args): pass
    def removeAllQueryItems(self, *args): pass
    def removeQueryItem(self, *args): pass
    def setAuthority(self, *args): pass
    def setDirectory(self, *args): pass
    def setFileName(self, *args): pass
    def setFragment(self, *args): pass
    def setHost(self, *args): pass
    def setPassword(self, *args): pass
    def setPath(self, *args): pass
    def setPort(self, *args): pass
    def setQueryDelimiters(self, *args): pass
    def setScheme(self, *args): pass
    def setURI(self, *args): pass
    def setUserInfo(self, *args): pass
    def setUserName(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def isValidURI(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class charPtr(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def cast(self, *args): pass
    def value(self, *args): pass
    @staticmethod
    def frompointer(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MScriptUtil(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def asBool(self, *args): pass
    def asBoolPtr(self, *args): pass
    def asCharPtr(self, *args): pass
    def asDouble(self, *args): pass
    def asDouble2Ptr(self, *args): pass
    def asDouble3Ptr(self, *args): pass
    def asDouble4Ptr(self, *args): pass
    def asDoublePtr(self, *args): pass
    def asFloat(self, *args): pass
    def asFloat2Ptr(self, *args): pass
    def asFloat3Ptr(self, *args): pass
    def asFloat4Ptr(self, *args): pass
    def asFloatPtr(self, *args): pass
    def asInt(self, *args): pass
    def asInt2Ptr(self, *args): pass
    def asInt3Ptr(self, *args): pass
    def asInt4Ptr(self, *args): pass
    def asIntPtr(self, *args): pass
    def asShort(self, *args): pass
    def asShort2Ptr(self, *args): pass
    def asShort3Ptr(self, *args): pass
    def asShort4Ptr(self, *args): pass
    def asShortPtr(self, *args): pass
    def asUcharPtr(self, *args): pass
    def asUint(self, *args): pass
    def asUint2Ptr(self, *args): pass
    def asUint3Ptr(self, *args): pass
    def asUint4Ptr(self, *args): pass
    def asUintPtr(self, *args): pass
    def asUshortPtr(self, *args): pass
    def createFromDouble(self, *args): pass
    def createFromInt(self, *args): pass
    def createFromList(self, *args): pass
    @staticmethod
    def createFloatArrayFromList(*args, **kwargs): pass
    @staticmethod
    def createFloatMatrixFromList(*args, **kwargs): pass
    @staticmethod
    def createIntArrayFromList(*args, **kwargs): pass
    @staticmethod
    def createMatrixFromList(*args, **kwargs): pass
    @staticmethod
    def getBool(*args, **kwargs): pass
    @staticmethod
    def getBoolArrayItem(*args, **kwargs): pass
    @staticmethod
    def getChar(*args, **kwargs): pass
    @staticmethod
    def getCharArrayItem(*args, **kwargs): pass
    @staticmethod
    def getDouble(*args, **kwargs): pass
    @staticmethod
    def getDouble2ArrayItem(*args, **kwargs): pass
    @staticmethod
    def getDouble3ArrayItem(*args, **kwargs): pass
    @staticmethod
    def getDouble4ArrayItem(*args, **kwargs): pass
    @staticmethod
    def getDoubleArrayItem(*args, **kwargs): pass
    @staticmethod
    def getFloat(*args, **kwargs): pass
    @staticmethod
    def getFloat2ArrayItem(*args, **kwargs): pass
    @staticmethod
    def getFloat3ArrayItem(*args, **kwargs): pass
    @staticmethod
    def getFloat4ArrayItem(*args, **kwargs): pass
    @staticmethod
    def getFloatArrayItem(*args, **kwargs): pass
    @staticmethod
    def getInt(*args, **kwargs): pass
    @staticmethod
    def getInt2ArrayItem(*args, **kwargs): pass
    @staticmethod
    def getInt3ArrayItem(*args, **kwargs): pass
    @staticmethod
    def getInt4ArrayItem(*args, **kwargs): pass
    @staticmethod
    def getIntArrayItem(*args, **kwargs): pass
    @staticmethod
    def getShort(*args, **kwargs): pass
    @staticmethod
    def getShort2ArrayItem(*args, **kwargs): pass
    @staticmethod
    def getShort3ArrayItem(*args, **kwargs): pass
    @staticmethod
    def getShort4ArrayItem(*args, **kwargs): pass
    @staticmethod
    def getShortArrayItem(*args, **kwargs): pass
    @staticmethod
    def getUchar(*args, **kwargs): pass
    @staticmethod
    def getUcharArrayItem(*args, **kwargs): pass
    @staticmethod
    def getUint(*args, **kwargs): pass
    @staticmethod
    def getUint2ArrayItem(*args, **kwargs): pass
    @staticmethod
    def getUint3ArrayItem(*args, **kwargs): pass
    @staticmethod
    def getUint4ArrayItem(*args, **kwargs): pass
    @staticmethod
    def getUintArrayItem(*args, **kwargs): pass
    @staticmethod
    def getUshortArrayItem(*args, **kwargs): pass
    @staticmethod
    def setBool(*args, **kwargs): pass
    @staticmethod
    def setBoolArray(*args, **kwargs): pass
    @staticmethod
    def setChar(*args, **kwargs): pass
    @staticmethod
    def setCharArray(*args, **kwargs): pass
    @staticmethod
    def setDouble(*args, **kwargs): pass
    @staticmethod
    def setDouble2ArrayItem(*args, **kwargs): pass
    @staticmethod
    def setDouble3ArrayItem(*args, **kwargs): pass
    @staticmethod
    def setDouble4ArrayItem(*args, **kwargs): pass
    @staticmethod
    def setDoubleArray(*args, **kwargs): pass
    @staticmethod
    def setFloat(*args, **kwargs): pass
    @staticmethod
    def setFloat2ArrayItem(*args, **kwargs): pass
    @staticmethod
    def setFloat3ArrayItem(*args, **kwargs): pass
    @staticmethod
    def setFloat4ArrayItem(*args, **kwargs): pass
    @staticmethod
    def setFloatArray(*args, **kwargs): pass
    @staticmethod
    def setInt(*args, **kwargs): pass
    @staticmethod
    def setInt2ArrayItem(*args, **kwargs): pass
    @staticmethod
    def setInt3ArrayItem(*args, **kwargs): pass
    @staticmethod
    def setInt4ArrayItem(*args, **kwargs): pass
    @staticmethod
    def setIntArray(*args, **kwargs): pass
    @staticmethod
    def setShort(*args, **kwargs): pass
    @staticmethod
    def setShort2ArrayItem(*args, **kwargs): pass
    @staticmethod
    def setShort3ArrayItem(*args, **kwargs): pass
    @staticmethod
    def setShort4ArrayItem(*args, **kwargs): pass
    @staticmethod
    def setShortArray(*args, **kwargs): pass
    @staticmethod
    def setUchar(*args, **kwargs): pass
    @staticmethod
    def setUcharArray(*args, **kwargs): pass
    @staticmethod
    def setUint(*args, **kwargs): pass
    @staticmethod
    def setUint2ArrayItem(*args, **kwargs): pass
    @staticmethod
    def setUint3ArrayItem(*args, **kwargs): pass
    @staticmethod
    def setUint4ArrayItem(*args, **kwargs): pass
    @staticmethod
    def setUintArray(*args, **kwargs): pass
    @staticmethod
    def setUshortArray(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MSelectionList(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def add(self, *args): pass
    def assign(self, *args): pass
    def clear(self, *args): pass
    def getDagPath(self, *args): pass
    def getDependNode(self, *args): pass
    def getPlug(self, *args): pass
    def getSelectionStrings(self, *args): pass
    def hasItem(self, *args): pass
    def hasItemPartly(self, *args): pass
    def intersect(self, *args): pass
    def isEmpty(self, *args): pass
    def length(self, *args): pass
    def merge(self, *args): pass
    def remove(self, *args): pass
    def replace(self, *args): pass
    def toggle(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kMergeNormal = 0
    
    
    kRemoveFromList = 2
    
    
    kXORWithList = 1


class MItInstancer(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def instancer(self, *args): pass
    def instancerId(self, *args): pass
    def instancerPath(self, *args): pass
    def isDone(self, *args): pass
    def matrix(self, *args): pass
    def next(self, *args): pass
    def nextInstancer(self, *args): pass
    def nextParticle(self, *args): pass
    def particleId(self, *args): pass
    def path(self, *args): pass
    def pathId(self, *args): pass
    def reset(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MComputation(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def beginComputation(self, *args): pass
    def endComputation(self, *args): pass
    def isInterruptRequested(self, *args): pass
    def progress(self, *args): pass
    def progressMax(self, *args): pass
    def progressMin(self, *args): pass
    def setProgress(self, *args): pass
    def setProgressRange(self, *args): pass
    def setProgressStatus(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MCurveAttribute(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addEntries(self, *args): pass
    def assign(self, *args): pass
    def deleteEntries(self, *args): pass
    def getEntries(self, *args): pass
    def getNumEntries(self, *args): pass
    def getValueAtPosition(self, *args): pass
    def getValuesAtPositions(self, *args): pass
    def hasIndex(self, *args): pass
    def pack(self, *args): pass
    def sampleValueCurve(self, *args): pass
    def setCurve(self, *args): pass
    def setPositionAtIndex(self, *args): pass
    def setValueAtIndex(self, *args): pass
    def sort(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def createCurve(*args, **kwargs): pass
    @staticmethod
    def createCurveAttr(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MFnBase(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args, **kwargs): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def hasObj(self, *args): pass
    def object(self, *args): pass
    def setObject(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MIffFile(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def beginGet(self, *args): pass
    def beginReadGroup(self, *args): pass
    def close(self, *args): pass
    def endGet(self, *args): pass
    def endReadGroup(self, *args): pass
    def get(self, *args): pass
    def getChunk(self, *args): pass
    def iffGetFloat(self, *args): pass
    def iffGetInt(self, *args): pass
    def iffGetShort(self, *args): pass
    def isActive(self, *args): pass
    def open(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MArrayDataHandle(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def builder(self, *args): pass
    def elementCount(self, *args): pass
    def elementIndex(self, *args): pass
    def inputArrayValue(self, *args): pass
    def inputValue(self, *args): pass
    def jumpToArrayElement(self, *args): pass
    def jumpToElement(self, *args): pass
    def next(self, *args): pass
    def outputArrayValue(self, *args): pass
    def outputValue(self, *args): pass
    def set(self, *args): pass
    def setAllClean(self, *args): pass
    def setClean(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MCallbackIdArray(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def append(self, *args): pass
    def assign(self, *args): pass
    def clear(self, *args): pass
    def copy(self, *args): pass
    def insert(self, *args): pass
    def length(self, *args): pass
    def remove(self, *args): pass
    def set(self, *args): pass
    def setLength(self, *args): pass
    def setSizeIncrement(self, *args): pass
    def sizeIncrement(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MQuaternion(_object):
    def __add__(self, *args): pass
    def __del__(self): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __imul__(self, *args): pass
    def __init__(self, *args): pass
    def __iter__(self):
        """
        Iterates on all components of a Maya api Quaternion
        """
        pass
    def __len__(self):
        """
        Number of components in the Maya api Quaternion, ie 4
        """
        pass
    def __mul__(self, *args): pass
    def __ne__(self, *args): pass
    def __neg__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def __sub__(self, *args): pass
    def asEulerRotation(self, *args): pass
    def asMatrix(self, *args): pass
    def assign(self, *args): pass
    def conjugate(self, *args): pass
    def conjugateIt(self, *args): pass
    def exp(self, *args): pass
    def get(self, *args): pass
    def getAxisAngle(self, *args): pass
    def inverse(self, *args): pass
    def invertIt(self, *args): pass
    def isEquivalent(self, *args): pass
    def log(self, *args): pass
    def negateIt(self, *args): pass
    def normal(self, *args): pass
    def normalizeIt(self, *args): pass
    def scaleIt(self, *args): pass
    def setAxisAngle(self, *args): pass
    def setToXAxis(self, *args): pass
    def setToYAxis(self, *args): pass
    def setToZAxis(self, *args): pass
    @property
    def w(self): pass
    @property
    def x(self): pass
    @property
    def y(self): pass
    @property
    def z(self): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    identity = None


class MItGeometry(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def allPositions(self, *args): pass
    def component(self, *args): pass
    def count(self, *args): pass
    def currentItem(self, *args): pass
    def exactCount(self, *args): pass
    def index(self, *args): pass
    def isDone(self, *args): pass
    def next(self, *args): pass
    def normal(self, *args): pass
    def position(self, *args): pass
    def reset(self, *args): pass
    def setAllPositions(self, *args): pass
    def setPosition(self, *args): pass
    def weight(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MFloatArray(_object):
    def __add__(self, *args): pass
    def __del__(self): pass
    def __delitem__(self, *args): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __iadd__(self, *args): pass
    def __init__(self, *args): pass
    def __len__(self, *args): pass
    def __ne__(self, *args): pass
    def __radd__(self, *args): pass
    def __repr__(self, *args): pass
    def __setattr__(self, name, value): pass
    def __setitem__(self, *args): pass
    def append(self, *args): pass
    def assign(self, *args): pass
    def clear(self, *args): pass
    def copy(self, *args): pass
    def get(self, *args): pass
    def insert(self, *args): pass
    def length(self, *args): pass
    def remove(self, *args): pass
    def set(self, *args): pass
    def setLength(self, *args): pass
    def setSizeIncrement(self, *args): pass
    def sizeIncrement(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MDistance(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def asCentimeters(self, *args): pass
    def asFeet(self, *args): pass
    def asInches(self, *args): pass
    def asKilometers(self, *args): pass
    def asMeters(self, *args): pass
    def asMiles(self, *args): pass
    def asMillimeters(self, *args): pass
    def asUnits(self, *args): pass
    def asYards(self, *args): pass
    def assign(self, *args): pass
    def setUnit(self, *args): pass
    def setValue(self, *args): pass
    def unit(self, *args): pass
    def value(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def internalToUI(*args, **kwargs): pass
    @staticmethod
    def internalUnit(*args, **kwargs): pass
    @staticmethod
    def setInternalUnit(*args, **kwargs): pass
    @staticmethod
    def setUIUnit(*args, **kwargs): pass
    @staticmethod
    def uiToInternal(*args, **kwargs): pass
    @staticmethod
    def uiUnit(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kCentimeters = 6
    
    
    kFeet = 2
    
    
    kInches = 1
    
    
    kInvalid = 0
    
    
    kKilometers = 7
    
    
    kLast = 9
    
    
    kMeters = 8
    
    
    kMiles = 4
    
    
    kMillimeters = 5
    
    
    kYards = 3


class MCacheFormatDescription(_object):
    def __getattr__(self, name): pass
    def __init__(self, *args, **kwargs): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addChannel(self, *args): pass
    def addDescriptionInfo(self, *args): pass
    def getChannelDataType(self, *args): pass
    def getChannelEndTime(self, *args): pass
    def getChannelInterpretation(self, *args): pass
    def getChannelName(self, *args): pass
    def getChannelSamplingRate(self, *args): pass
    def getChannelSamplingType(self, *args): pass
    def getChannelStartTime(self, *args): pass
    def getDescriptionInfo(self, *args): pass
    def getDistribution(self, *args): pass
    def getNumChannels(self, *args): pass
    def getStartAndEndTimes(self, *args): pass
    def getTimePerFrame(self, *args): pass
    def setDistribution(self, *args): pass
    def setTimePerFrame(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kDouble = 1
    
    
    kDoubleArray = 2
    
    
    kDoubleVectorArray = 3
    
    
    kFloatArray = 5
    
    
    kFloatVectorArray = 6
    
    
    kInt32Array = 4
    
    
    kIrregular = 1
    
    
    kNoFile = 0
    
    
    kOneFile = 1
    
    
    kOneFilePerFrame = 2
    
    
    kRegular = 0
    
    
    kUnknownData = 0


class MDoubleArray(_object):
    def __add__(self, *args): pass
    def __del__(self): pass
    def __delitem__(self, *args): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __iadd__(self, *args): pass
    def __init__(self, *args): pass
    def __len__(self, *args): pass
    def __ne__(self, *args): pass
    def __radd__(self, *args): pass
    def __repr__(self, *args): pass
    def __setattr__(self, name, value): pass
    def __setitem__(self, *args): pass
    def append(self, *args): pass
    def assign(self, *args): pass
    def clear(self, *args): pass
    def copy(self, *args): pass
    def get(self, *args): pass
    def insert(self, *args): pass
    def length(self, *args): pass
    def remove(self, *args): pass
    def set(self, *args): pass
    def setLength(self, *args): pass
    def setSizeIncrement(self, *args): pass
    def sizeIncrement(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MMeshSmoothOptions(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def boundaryRule(self, *args): pass
    def divisions(self, *args): pass
    def keepBorderEdge(self, *args): pass
    def keepHardEdge(self, *args): pass
    def openSubdivCreaseMethod(self, *args): pass
    def openSubdivFaceVaryingBoundary(self, *args): pass
    def openSubdivSmoothTriangles(self, *args): pass
    def openSubdivVertexBoundary(self, *args): pass
    def propEdgeHardness(self, *args): pass
    def setBoundaryRule(self, *args): pass
    def setDivisions(self, *args): pass
    def setKeepBorderEdge(self, *args): pass
    def setKeepHardEdge(self, *args): pass
    def setOpenSubdivCreaseMethod(self, *args): pass
    def setOpenSubdivFaceVaryingBoundary(self, *args): pass
    def setOpenSubdivSmoothTriangles(self, *args): pass
    def setOpenSubdivVertexBoundary(self, *args): pass
    def setPropEdgeHardness(self, *args): pass
    def setSmoothUVs(self, *args): pass
    def setSmoothness(self, *args): pass
    def setSubdivisionType(self, *args): pass
    def smoothUVs(self, *args): pass
    def smoothness(self, *args): pass
    def subdivisionType(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kAlwaysSharp = 3
    
    
    kCatmullClark = 0
    
    
    kChaikin = 1
    
    
    kCreaseAll = 1
    
    
    kCreaseEdge = 2
    
    
    kInvalid = -1
    
    
    kInvalidBoundary = -1
    
    
    kInvalidCreaseMethod = -1
    
    
    kInvalidSubdivision = -1
    
    
    kLast = 3
    
    
    kLastBoundary = 4
    
    
    kLastCreaseMethod = 2
    
    
    kLastSubdivision = 4
    
    
    kLegacy = 0
    
    
    kNone = 0
    
    
    kNormal = 0
    
    
    kOpenSubdivCatmullClarkAdaptive = 3
    
    
    kOpenSubdivCatmullClarkUniform = 2
    
    
    kSharpEdges = 2
    
    
    kSharpEdgesAndCorners = 1


class MDataHandle(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def acceptedTypeIds(self, *args): pass
    def asAddr(self, *args): pass
    def asAngle(self, *args): pass
    def asBool(self, *args): pass
    def asChar(self, *args): pass
    def asDistance(self, *args): pass
    def asDouble(self, *args): pass
    def asDouble2(self, *args): pass
    def asDouble3(self, *args): pass
    def asDouble4(self, *args): pass
    def asFloat(self, *args): pass
    def asFloat2(self, *args): pass
    def asFloat3(self, *args): pass
    def asFloatMatrix(self, *args): pass
    def asFloatVector(self, *args): pass
    def asGenericBool(self, *args): pass
    def asGenericChar(self, *args): pass
    def asGenericDouble(self, *args): pass
    def asGenericFloat(self, *args): pass
    def asGenericInt(self, *args): pass
    def asGenericInt64(self, *args): pass
    def asGenericShort(self, *args): pass
    def asInt(self, *args): pass
    def asInt2(self, *args): pass
    def asInt3(self, *args): pass
    def asInt64(self, *args): pass
    def asLong(self, *args): pass
    def asLong2(self, *args): pass
    def asLong3(self, *args): pass
    def asMatrix(self, *args): pass
    def asMesh(self, *args): pass
    def asMeshTransformed(self, *args): pass
    def asNurbsCurve(self, *args): pass
    def asNurbsCurveTransformed(self, *args): pass
    def asNurbsSurface(self, *args): pass
    def asNurbsSurfaceTransformed(self, *args): pass
    def asPluginData(self, *args): pass
    def asShort(self, *args): pass
    def asShort2(self, *args): pass
    def asShort3(self, *args): pass
    def asString(self, *args): pass
    def asSubdSurface(self, *args): pass
    def asSubdSurfaceTransformed(self, *args): pass
    def asTime(self, *args): pass
    def asUChar(self, *args): pass
    def asVector(self, *args): pass
    def assign(self, *args): pass
    def child(self, *args): pass
    def copy(self, *args): pass
    def copyWritable(self, *args): pass
    def data(self, *args): pass
    def datablock(self, *args): pass
    def geometryTransformMatrix(self, *args): pass
    def isGeneric(self, *args): pass
    def isNumeric(self, *args): pass
    def numericType(self, *args): pass
    def set2Double(self, *args): pass
    def set2Float(self, *args): pass
    def set2Int(self, *args): pass
    def set2Short(self, *args): pass
    def set3Double(self, *args): pass
    def set3Float(self, *args): pass
    def set3Int(self, *args): pass
    def set3Short(self, *args): pass
    def set4Double(self, *args): pass
    def setBool(self, *args): pass
    def setChar(self, *args): pass
    def setClean(self, *args): pass
    def setDouble(self, *args): pass
    def setFloat(self, *args): pass
    def setGenericBool(self, *args): pass
    def setGenericChar(self, *args): pass
    def setGenericDouble(self, *args): pass
    def setGenericFloat(self, *args): pass
    def setGenericInt(self, *args): pass
    def setGenericInt64(self, *args): pass
    def setGenericShort(self, *args): pass
    def setInt(self, *args): pass
    def setInt64(self, *args): pass
    def setMAngle(self, *args): pass
    def setMDistance(self, *args): pass
    def setMFloatMatrix(self, *args): pass
    def setMFloatVector(self, *args): pass
    def setMMatrix(self, *args): pass
    def setMObject(self, *args): pass
    def setMPxData(self, *args): pass
    def setMTime(self, *args): pass
    def setMVector(self, *args): pass
    def setShort(self, *args): pass
    def setString(self, *args): pass
    def type(self, *args): pass
    def typeId(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MObjectArray(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __getitem__(*args): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def append(self, *args): pass
    def assign(self, *args): pass
    def clear(self, *args): pass
    def copy(self, *args): pass
    def insert(self, *args): pass
    def length(self, *args): pass
    def remove(self, *args): pass
    def set(self, *args): pass
    def setLength(self, *args): pass
    def setSizeIncrement(self, *args): pass
    def sizeIncrement(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MEulerRotation(_object):
    def __add__(self, *args): pass
    def __del__(self): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __iadd__(self, *args): pass
    def __imul__(self, *args): pass
    def __init__(self, *args): pass
    def __isub__(self, *args): pass
    def __iter__(self):
        """
        Iterates on all components of a Maya api EulerRotation
        """
        pass
    def __len__(self):
        """
        Number of components in the Maya api EulerRotation, ie 3
        """
        pass
    def __mul__(self, *args): pass
    def __ne__(self, *args): pass
    def __neg__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def __sub__(self, *args): pass
    def alternateSolution(self, *args): pass
    def asMatrix(self, *args): pass
    def asQuaternion(self, *args): pass
    def asVector(self, *args): pass
    def assign(self, *args): pass
    def bound(self, *args): pass
    def boundIt(self, *args): pass
    def closestCut(self, *args): pass
    def closestSolution(self, *args): pass
    def incrementalRotateBy(self, *args): pass
    def inverse(self, *args): pass
    def invertIt(self, *args): pass
    def isEquivalent(self, *args): pass
    def isZero(self, *args): pass
    def reorder(self, *args): pass
    def reorderIt(self, *args): pass
    def setToAlternateSolution(self, *args): pass
    def setToClosestCut(self, *args): pass
    def setToClosestSolution(self, *args): pass
    def setValue(self, *args): pass
    @staticmethod
    def decompose(*args, **kwargs): pass
    @property
    def order(self): pass
    @property
    def x(self): pass
    @property
    def y(self): pass
    @property
    def z(self): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    identity = None
    
    
    kXYZ = 0
    
    
    kXZY = 3
    
    
    kYXZ = 4
    
    
    kYZX = 1
    
    
    kZXY = 2
    
    
    kZYX = 5


class array3dInt(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def get(self, *args): pass
    def getptr(self, *args): pass
    def set(self, *args): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MFileObject(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def exists(self, *args): pass
    def expandedFullName(self, *args): pass
    def expandedPath(self, *args): pass
    def fullName(self, *args): pass
    def isSet(self, *args): pass
    def ithFullName(self, *args): pass
    def ithPath(self, *args): pass
    def name(self, *args): pass
    def overrideResolvedFullName(self, *args): pass
    def path(self, *args): pass
    def pathCount(self, *args): pass
    def rawFullName(self, *args): pass
    def rawName(self, *args): pass
    def rawPath(self, *args): pass
    def rawURI(self, *args): pass
    def resolveMethod(self, *args): pass
    def resolvedFullName(self, *args): pass
    def resolvedName(self, *args): pass
    def resolvedPath(self, *args): pass
    def setFullName(self, *args): pass
    def setName(self, *args): pass
    def setRawFullName(self, *args): pass
    def setRawName(self, *args): pass
    def setRawPath(self, *args): pass
    def setRawURI(self, *args): pass
    def setResolveMethod(self, *args): pass
    @staticmethod
    def getResolvedFullName(*args, **kwargs): pass
    @staticmethod
    def isAbsolutePath(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kBaseName = 32
    
    
    kDirMap = 4
    
    
    kExact = 2
    
    
    kInputFile = 54
    
    
    kInputReference = 62
    
    
    kNone = 1
    
    
    kReferenceMappings = 8
    
    
    kRelative = 16
    
    
    kStrict = 6


class MSpace(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kInvalid = 0
    
    
    kLast = 5
    
    
    kObject = 2
    
    
    kPostTransform = 3
    
    
    kPreTransform = 2
    
    
    kTransform = 1
    
    
    kWorld = 4


class MStreamUtils(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def readChar(*args, **kwargs): pass
    @staticmethod
    def readCharBuffer(*args, **kwargs): pass
    @staticmethod
    def readDouble(*args, **kwargs): pass
    @staticmethod
    def readFloat(*args, **kwargs): pass
    @staticmethod
    def readInt(*args, **kwargs): pass
    @staticmethod
    def stdErrorStream(*args, **kwargs): pass
    @staticmethod
    def stdOutStream(*args, **kwargs): pass
    @staticmethod
    def writeChar(*args, **kwargs): pass
    @staticmethod
    def writeCharBuffer(*args, **kwargs): pass
    @staticmethod
    def writeDouble(*args, **kwargs): pass
    @staticmethod
    def writeFloat(*args, **kwargs): pass
    @staticmethod
    def writeInt(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MItDag(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def currentItem(self, *args): pass
    def depth(self, *args): pass
    def fullPathName(self, *args): pass
    def getAllPaths(self, *args): pass
    def getPath(self, *args): pass
    def getType(self, *args): pass
    def instanceCount(self, *args): pass
    def isDone(self, *args): pass
    def isInstanced(self, *args): pass
    def item(self, *args): pass
    def next(self, *args): pass
    def partialPathName(self, *args): pass
    def prune(self, *args): pass
    def reset(self, *args): pass
    def root(self, *args): pass
    def traverseUnderWorld(self, *args): pass
    def willTraverseUnderWorld(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kBreadthFirst = 2
    
    
    kDepthFirst = 1
    
    
    kInvalidType = 0


class MFnSubdNames(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def base(*args, **kwargs): pass
    @staticmethod
    def baseFaceId(*args, **kwargs): pass
    @staticmethod
    def baseFaceIdFromIndex(*args, **kwargs): pass
    @staticmethod
    def baseFaceIdFromLong(*args, **kwargs): pass
    @staticmethod
    def baseFaceIndex(*args, **kwargs): pass
    @staticmethod
    def baseFaceIndexFromId(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def corner(*args, **kwargs): pass
    @staticmethod
    def first(*args, **kwargs): pass
    @staticmethod
    def fromMUint64(*args, **kwargs): pass
    @staticmethod
    def fromSelectionIndices(*args, **kwargs): pass
    @staticmethod
    def level(*args, **kwargs): pass
    @staticmethod
    def levelOneFaceAsLong(*args, **kwargs): pass
    @staticmethod
    def levelOneFaceId(*args, **kwargs): pass
    @staticmethod
    def levelOneFaceIdFromIndex(*args, **kwargs): pass
    @staticmethod
    def levelOneFaceIdFromLong(*args, **kwargs): pass
    @staticmethod
    def levelOneFaceIndexFromId(*args, **kwargs): pass
    @staticmethod
    def nonBaseFaceEdges(*args, **kwargs): pass
    @staticmethod
    def nonBaseFaceVertices(*args, **kwargs): pass
    @staticmethod
    def parentFaceId(*args, **kwargs): pass
    @staticmethod
    def path(*args, **kwargs): pass
    @staticmethod
    def toMUint64(*args, **kwargs): pass
    @staticmethod
    def toSelectionIndices(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class doublePtr(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def cast(self, *args): pass
    def value(self, *args): pass
    @staticmethod
    def frompointer(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MSyntax(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addArg(self, *args): pass
    def addFlag(self, *args): pass
    def assign(self, *args): pass
    def canEdit(self, *args): pass
    def canQuery(self, *args): pass
    def enableEdit(self, *args): pass
    def enableQuery(self, *args): pass
    def makeFlagMultiUse(self, *args): pass
    def makeFlagQueryWithFullArgs(self, *args): pass
    def maxObjects(self, *args): pass
    def minObjects(self, *args): pass
    def setMaxObjects(self, *args): pass
    def setMinObjects(self, *args): pass
    def setObjectType(self, *args): pass
    def useSelectionAsDefault(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kAngle = 8
    
    
    kBoolean = 2
    
    
    kDistance = 7
    
    
    kDouble = 4
    
    
    kInvalidArgType = 0
    
    
    kInvalidObjectFormat = 0
    
    
    kLastArgType = 11
    
    
    kLastObjectFormat = 4
    
    
    kLong = 3
    
    
    kNoArg = 1
    
    
    kNone = 1
    
    
    kSelectionItem = 10
    
    
    kSelectionList = 3
    
    
    kString = 5
    
    
    kStringObjects = 2
    
    
    kTime = 9
    
    
    kUnsigned = 6


class MPointOnNurbs(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def getPoint(self, *args): pass
    def getUV(self, *args): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MUintArray(_object):
    def __add__(self, *args): pass
    def __del__(self): pass
    def __delitem__(self, *args): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __iadd__(self, *args): pass
    def __init__(self, *args): pass
    def __len__(self, *args): pass
    def __ne__(self, *args): pass
    def __radd__(self, *args): pass
    def __repr__(self, *args): pass
    def __setattr__(self, name, value): pass
    def __setitem__(self, *args): pass
    def append(self, *args): pass
    def assign(self, *args): pass
    def clear(self, *args): pass
    def copy(self, *args): pass
    def get(self, *args): pass
    def insert(self, *args): pass
    def length(self, *args): pass
    def remove(self, *args): pass
    def set(self, *args): pass
    def setLength(self, *args): pass
    def setSizeIncrement(self, *args): pass
    def sizeIncrement(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MItEdits(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addRemoveAttrEdit(self, *args): pass
    def connectDisconnectEdit(self, *args): pass
    def currentEditString(self, *args): pass
    def currentEditType(self, *args): pass
    def edit(self, *args): pass
    def fcurveEdit(self, *args): pass
    def isDone(self, *args): pass
    def isReverse(self, *args): pass
    def next(self, *args): pass
    def parentingEdit(self, *args): pass
    def removeCurrentEdit(self, *args): pass
    def reset(self, *args): pass
    def setAttrEdit(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    ALL_EDITS = 1
    
    
    SUCCESSFUL_EDITS = 0
    
    
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kForward = 0
    
    
    kReverse = 1


class MFn(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @property
    def nodeType(self): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kAISEnvFacade = 972
    
    
    kAddDoubleLinear = 5
    
    
    kAdskMaterial = 1062
    
    
    kAffect = 6
    
    
    kAimConstraint = 111
    
    
    kAir = 257
    
    
    kAlignCurve = 41
    
    
    kAlignManip = 907
    
    
    kAlignSurface = 42
    
    
    kAmbientLight = 303
    
    
    kAngle = 270
    
    
    kAngleBetween = 21
    
    
    kAnimBlend = 789
    
    
    kAnimBlendInOut = 790
    
    
    kAnimCurve = 7
    
    
    kAnimCurveTimeToAngular = 8
    
    
    kAnimCurveTimeToDistance = 9
    
    
    kAnimCurveTimeToTime = 10
    
    
    kAnimCurveTimeToUnitless = 11
    
    
    kAnimCurveUnitlessToAngular = 12
    
    
    kAnimCurveUnitlessToDistance = 13
    
    
    kAnimCurveUnitlessToTime = 14
    
    
    kAnimCurveUnitlessToUnitless = 15
    
    
    kAnimLayer = 1015
    
    
    kAnisotropy = 617
    
    
    kAnnotation = 271
    
    
    kAnyGeometryVarGroup = 115
    
    
    kArcLength = 273
    
    
    kAreaLight = 305
    
    
    kArrayMapper = 524
    
    
    kArrowManip = 123
    
    
    kArubaTesselate = 1127
    
    
    kAssembly = 1076
    
    
    kAsset = 1013
    
    
    kAttachCurve = 43
    
    
    kAttachSurface = 44
    
    
    kAttribute = 561
    
    
    kAttribute2Double = 742
    
    
    kAttribute2Float = 743
    
    
    kAttribute2Int = 745
    
    
    kAttribute2Long = 745
    
    
    kAttribute2Short = 744
    
    
    kAttribute3Double = 746
    
    
    kAttribute3Float = 747
    
    
    kAttribute3Int = 749
    
    
    kAttribute3Long = 749
    
    
    kAttribute3Short = 748
    
    
    kAttribute4Double = 875
    
    
    kAudio = 22
    
    
    kAverageCurveManip = 149
    
    
    kAvgCurves = 45
    
    
    kAvgNurbsSurfacePoints = 47
    
    
    kAvgSurfacePoints = 46
    
    
    kAxesActionManip = 124
    
    
    kBackground = 23
    
    
    kBallProjectionManip = 125
    
    
    kBarnDoorManip = 150
    
    
    kBase = 1
    
    
    kBaseLattice = 249
    
    
    kBendLattice = 335
    
    
    kBevel = 48
    
    
    kBevelManip = 151
    
    
    kBevelPlus = 894
    
    
    kBezierCurve = 1049
    
    
    kBezierCurveData = 1050
    
    
    kBezierCurveToNurbs = 1052
    
    
    kBinaryData = 741
    
    
    kBirailSrf = 49
    
    
    kBlend = 27
    
    
    kBlendColorSet = 734
    
    
    kBlendColors = 31
    
    
    kBlendDevice = 30
    
    
    kBlendManip = 152
    
    
    kBlendNodeAdditiveRotation = 1028
    
    
    kBlendNodeAdditiveScale = 1027
    
    
    kBlendNodeBase = 1016
    
    
    kBlendNodeBoolean = 1017
    
    
    kBlendNodeDouble = 1018
    
    
    kBlendNodeDoubleAngle = 1019
    
    
    kBlendNodeDoubleLinear = 1020
    
    
    kBlendNodeEnum = 1021
    
    
    kBlendNodeFloat = 1022
    
    
    kBlendNodeFloatAngle = 1023
    
    
    kBlendNodeFloatLinear = 1024
    
    
    kBlendNodeInt16 = 1025
    
    
    kBlendNodeInt32 = 1026
    
    
    kBlendNodeTime = 1047
    
    
    kBlendShape = 336
    
    
    kBlendTwoAttr = 28
    
    
    kBlendWeighted = 29
    
    
    kBlindData = 751
    
    
    kBlindDataTemplate = 752
    
    
    kBlinn = 371
    
    
    kBlinnMaterial = 386
    
    
    kBoundary = 53
    
    
    kBox = 862
    
    
    kBoxData = 861
    
    
    kBrownian = 504
    
    
    kBrush = 760
    
    
    kBulge = 493
    
    
    kBulgeLattice = 338
    
    
    kBump = 32
    
    
    kBump3d = 33
    
    
    kButtonManip = 153
    
    
    kCacheBase = 994
    
    
    kCacheBlend = 995
    
    
    kCacheFile = 982
    
    
    kCacheTrack = 996
    
    
    kCacheableNode = 991
    
    
    kCaddyManipBase = 1105
    
    
    kCamera = 250
    
    
    kCameraManip = 154
    
    
    kCameraPlaneManip = 143
    
    
    kCameraSet = 1006
    
    
    kCameraView = 34
    
    
    kCenterManip = 134
    
    
    kChainToSpline = 35
    
    
    kCharacter = 683
    
    
    kCharacterMap = 798
    
    
    kCharacterMappingData = 737
    
    
    kCharacterOffset = 684
    
    
    kChecker = 494
    
    
    kChoice = 36
    
    
    kChooser = 767
    
    
    kCircle = 54
    
    
    kCircleManip = 126
    
    
    kCirclePointManip = 231
    
    
    kCircleSweepManip = 128
    
    
    kClampColor = 39
    
    
    kClientDevice = 1072
    
    
    kClip = 804
    
    
    kClipGhostShape = 1077
    
    
    kClipLibrary = 775
    
    
    kClipScheduler = 774
    
    
    kClipToGhostData = 1078
    
    
    kCloseCurve = 55
    
    
    kCloseSurface = 57
    
    
    kClosestPointOnMesh = 984
    
    
    kClosestPointOnSurface = 56
    
    
    kCloth = 495
    
    
    kCloud = 505
    
    
    kCluster = 251
    
    
    kClusterFilter = 347
    
    
    kClusterFlexor = 300
    
    
    kCoiManip = 155
    
    
    kCollision = 253
    
    
    kColorBackground = 24
    
    
    kColorMgtGlobals = 1096
    
    
    kColorProfile = 1061
    
    
    kCombinationShape = 337
    
    
    kCommCornerManip = 608
    
    
    kCommCornerOperManip = 609
    
    
    kCommEdgeOperManip = 606
    
    
    kCommEdgePtManip = 605
    
    
    kCommEdgeSegmentManip = 607
    
    
    kComponent = 531
    
    
    kComponentListData = 579
    
    
    kComponentManip = 669
    
    
    kCompoundAttribute = 571
    
    
    kConcentricProjectionManip = 129
    
    
    kCondition = 37
    
    
    kCone = 96
    
    
    kConstraint = 927
    
    
    kContainer = 1008
    
    
    kContainerBase = 1063
    
    
    kContourProjectionManip = 1110
    
    
    kContrast = 38
    
    
    kControl = 482
    
    
    kControllerTag = 1123
    
    
    kCopyColorSet = 733
    
    
    kCopyUVSet = 802
    
    
    kCpManip = 156
    
    
    kCrater = 506
    
    
    kCreaseSet = 1085
    
    
    kCreate = 40
    
    
    kCreateBPManip = 832
    
    
    kCreateBezierManip = 1048
    
    
    kCreateCVManip = 157
    
    
    kCreateColorSet = 731
    
    
    kCreateEPManip = 158
    
    
    kCreateSectionManip = 819
    
    
    kCreateUVSet = 803
    
    
    kCrossSectionEditManip = 820
    
    
    kCrossSectionManager = 818
    
    
    kCubicProjectionManip = 130
    
    
    kCurve = 266
    
    
    kCurveCVComponent = 532
    
    
    kCurveCurveIntersect = 636
    
    
    kCurveEPComponent = 533
    
    
    kCurveEdManip = 159
    
    
    kCurveFromMeshCoM = 929
    
    
    kCurveFromMeshEdge = 635
    
    
    kCurveFromSubdivEdge = 831
    
    
    kCurveFromSubdivFace = 837
    
    
    kCurveFromSurface = 58
    
    
    kCurveFromSurfaceBnd = 59
    
    
    kCurveFromSurfaceCoS = 60
    
    
    kCurveFromSurfaceIso = 61
    
    
    kCurveInfo = 62
    
    
    kCurveKnotComponent = 534
    
    
    kCurveNormalizerAngle = 998
    
    
    kCurveNormalizerLinear = 999
    
    
    kCurveParamComponent = 535
    
    
    kCurveSegmentManip = 160
    
    
    kCurveVarGroup = 116
    
    
    kCustomEvaluatorClusterNode = 1125
    
    
    kCylinder = 98
    
    
    kCylindricalProjectionManip = 131
    
    
    kDOF = 323
    
    
    kDPbirailSrf = 50
    
    
    kDagContainer = 1064
    
    
    kDagNode = 107
    
    
    kDagPose = 685
    
    
    kDagSelectionItem = 558
    
    
    kData = 578
    
    
    kData2Double = 588
    
    
    kData2Float = 589
    
    
    kData2Int = 590
    
    
    kData2Long = 590
    
    
    kData2Short = 591
    
    
    kData3Double = 592
    
    
    kData3Float = 593
    
    
    kData3Int = 594
    
    
    kData3Long = 594
    
    
    kData3Short = 595
    
    
    kData4Double = 876
    
    
    kDblTrsManip = 190
    
    
    kDecayRegionCapComponent = 544
    
    
    kDecayRegionComponent = 545
    
    
    kDefaultLightList = 317
    
    
    kDeformBend = 620
    
    
    kDeformBendManip = 626
    
    
    kDeformFlare = 623
    
    
    kDeformFlareManip = 629
    
    
    kDeformFunc = 619
    
    
    kDeformSine = 624
    
    
    kDeformSineManip = 630
    
    
    kDeformSquash = 622
    
    
    kDeformSquashManip = 628
    
    
    kDeformTwist = 621
    
    
    kDeformTwistManip = 627
    
    
    kDeformWave = 625
    
    
    kDeformWaveManip = 631
    
    
    kDeleteColorSet = 732
    
    
    kDeleteComponent = 318
    
    
    kDeleteUVSet = 795
    
    
    kDeltaMush = 350
    
    
    kDependencyNode = 4
    
    
    kDetachCurve = 63
    
    
    kDetachSurface = 64
    
    
    kDiffuseMaterial = 384
    
    
    kDimension = 269
    
    
    kDimensionManip = 232
    
    
    kDirectedDisc = 276
    
    
    kDirectionManip = 161
    
    
    kDirectionalLight = 308
    
    
    kDiscManip = 132
    
    
    kDiskCache = 858
    
    
    kDispatchCompute = 319
    
    
    kDisplacementShader = 321
    
    
    kDisplayLayer = 728
    
    
    kDisplayLayerManager = 729
    
    
    kDistance = 272
    
    
    kDistanceBetween = 322
    
    
    kDistanceManip = 633
    
    
    kDofManip = 162
    
    
    kDoubleAngleAttribute = 563
    
    
    kDoubleArrayData = 580
    
    
    kDoubleIndexedComponent = 709
    
    
    kDoubleLinearAttribute = 565
    
    
    kDoubleShadingSwitch = 614
    
    
    kDrag = 258
    
    
    kDropOffFunction = 821
    
    
    kDropoffLocator = 282
    
    
    kDropoffManip = 163
    
    
    kDummy = 254
    
    
    kDummyConnectable = 324
    
    
    kDynAirManip = 719
    
    
    kDynArrayAttrsData = 724
    
    
    kDynAttenuationManip = 723
    
    
    kDynBase = 715
    
    
    kDynBaseFieldManip = 718
    
    
    kDynEmitterManip = 716
    
    
    kDynFieldsManip = 717
    
    
    kDynGlobals = 764
    
    
    kDynNewtonManip = 720
    
    
    kDynParticleSetComponent = 556
    
    
    kDynSpreadManip = 722
    
    
    kDynSweptGeometryData = 738
    
    
    kDynTurbulenceManip = 721
    
    
    kDynamicConstraint = 988
    
    
    kDynamicsController = 325
    
    
    kEdgeComponent = 541
    
    
    kEditCurve = 816
    
    
    kEditCurveManip = 817
    
    
    kEditMetadata = 1084
    
    
    kEditsManager = 1092
    
    
    kEmitter = 255
    
    
    kEnableManip = 136
    
    
    kEnumAttribute = 568
    
    
    kEnvBall = 487
    
    
    kEnvChrome = 489
    
    
    kEnvCube = 488
    
    
    kEnvFacade = 971
    
    
    kEnvFogMaterial = 378
    
    
    kEnvFogShape = 278
    
    
    kEnvSky = 490
    
    
    kEnvSphere = 491
    
    
    kExplodeNurbsShell = 687
    
    
    kExpression = 327
    
    
    kExtendCurve = 65
    
    
    kExtendCurveDistanceManip = 164
    
    
    kExtendSurface = 66
    
    
    kExtendSurfaceDistanceManip = 711
    
    
    kExtract = 328
    
    
    kExtrude = 67
    
    
    kExtrudeManip = 165
    
    
    kFFD = 339
    
    
    kFFblendSrf = 68
    
    
    kFFfilletSrf = 69
    
    
    kFacade = 969
    
    
    kFfdDualBase = 340
    
    
    kField = 256
    
    
    kFileBackground = 25
    
    
    kFileTexture = 496
    
    
    kFilletCurve = 70
    
    
    kFilter = 329
    
    
    kFilterClosestSample = 330
    
    
    kFilterEuler = 331
    
    
    kFilterSimplify = 332
    
    
    kFitBspline = 71
    
    
    kFixedLineManip = 233
    
    
    kFlexor = 299
    
    
    kFloatAngleAttribute = 564
    
    
    kFloatArrayData = 1032
    
    
    kFloatLinearAttribute = 566
    
    
    kFloatMatrixAttribute = 575
    
    
    kFloatVectorArrayData = 1009
    
    
    kFlow = 72
    
    
    kFluid = 909
    
    
    kFluidData = 911
    
    
    kFluidEmitter = 915
    
    
    kFluidGeom = 910
    
    
    kFluidTexture2D = 904
    
    
    kFluidTexture3D = 903
    
    
    kFollicle = 930
    
    
    kForceUpdateManip = 690
    
    
    kFosterParent = 1087
    
    
    kFourByFourMatrix = 770
    
    
    kFractal = 497
    
    
    kFreePointManip = 133
    
    
    kFreePointTriadManip = 137
    
    
    kGammaCorrect = 333
    
    
    kGenericAttribute = 572
    
    
    kGeoConnectable = 326
    
    
    kGeoConnector = 917
    
    
    kGeomBind = 1095
    
    
    kGeometric = 265
    
    
    kGeometryConstraint = 113
    
    
    kGeometryData = 707
    
    
    kGeometryFilt = 334
    
    
    kGeometryOnLineManip = 142
    
    
    kGeometryVarGroup = 114
    
    
    kGlobalCacheControls = 857
    
    
    kGlobalStitch = 696
    
    
    kGranite = 507
    
    
    kGravity = 259
    
    
    kGreasePencilSequence = 1083
    
    
    kGreasePlane = 1081
    
    
    kGreasePlaneRenderShape = 1082
    
    
    kGrid = 498
    
    
    kGroundPlane = 290
    
    
    kGroupId = 354
    
    
    kGroupParts = 355
    
    
    kGuide = 356
    
    
    kGuideLine = 301
    
    
    kHairConstraint = 935
    
    
    kHairSystem = 931
    
    
    kHairTubeShader = 942
    
    
    kHandleRotateManip = 216
    
    
    kHardenPointCurve = 73
    
    
    kHardwareReflectionMap = 881
    
    
    kHardwareRenderGlobals = 523
    
    
    kHardwareRenderingGlobals = 1066
    
    
    kHeightField = 916
    
    
    kHikEffector = 956
    
    
    kHikFKJoint = 958
    
    
    kHikFloorContactMarker = 978
    
    
    kHikGroundPlane = 979
    
    
    kHikHandle = 960
    
    
    kHikIKEffector = 957
    
    
    kHikSolver = 959
    
    
    kHistorySwitch = 983
    
    
    kHsvToRgb = 357
    
    
    kHwShaderNode = 884
    
    
    kHyperGraphInfo = 358
    
    
    kHyperLayout = 359
    
    
    kHyperLayoutDG = 1000
    
    
    kHyperView = 360
    
    
    kIkEffector = 119
    
    
    kIkHandle = 120
    
    
    kIkRPManip = 167
    
    
    kIkSolver = 361
    
    
    kIkSplineManip = 166
    
    
    kIkSystem = 367
    
    
    kIllustratorCurve = 74
    
    
    kImageAdd = 654
    
    
    kImageBlur = 660
    
    
    kImageColorCorrect = 659
    
    
    kImageData = 648
    
    
    kImageDepth = 662
    
    
    kImageDiff = 655
    
    
    kImageDisplay = 663
    
    
    kImageFilter = 661
    
    
    kImageLoad = 649
    
    
    kImageMotionBlur = 665
    
    
    kImageMultiply = 656
    
    
    kImageNetDest = 652
    
    
    kImageNetSrc = 651
    
    
    kImageOver = 657
    
    
    kImagePlane = 368
    
    
    kImageRender = 653
    
    
    kImageSave = 650
    
    
    kImageSource = 786
    
    
    kImageUnder = 658
    
    
    kImageView = 664
    
    
    kImplicitCone = 889
    
    
    kImplicitSphere = 890
    
    
    kInsertKnotCrv = 75
    
    
    kInsertKnotSrf = 76
    
    
    kInstancer = 757
    
    
    kInt64ArrayData = 809
    
    
    kIntArrayData = 581
    
    
    kIntersectSurface = 77
    
    
    kInvalid = 0
    
    
    kIsoparmComponent = 536
    
    
    kIsoparmManip = 146
    
    
    kItemList = 560
    
    
    kJiggleDeformer = 856
    
    
    kJoint = 121
    
    
    kJointCluster = 349
    
    
    kJointClusterManip = 168
    
    
    kJointTranslateManip = 229
    
    
    kKeyframeDelta = 944
    
    
    kKeyframeDeltaAddRemove = 947
    
    
    kKeyframeDeltaBlockAddRemove = 948
    
    
    kKeyframeDeltaBreakdown = 952
    
    
    kKeyframeDeltaInfType = 949
    
    
    kKeyframeDeltaMove = 945
    
    
    kKeyframeDeltaScale = 946
    
    
    kKeyframeDeltaTangent = 950
    
    
    kKeyframeDeltaWeighted = 951
    
    
    kKeyframeRegionManip = 997
    
    
    kKeyingGroup = 682
    
    
    kLambert = 369
    
    
    kLambertMaterial = 385
    
    
    kLast = 1130
    
    
    kLattice = 279
    
    
    kLatticeComponent = 542
    
    
    kLatticeData = 582
    
    
    kLatticeGeom = 280
    
    
    kLayeredShader = 374
    
    
    kLayeredTexture = 799
    
    
    kLeastSquares = 376
    
    
    kLeather = 508
    
    
    kLight = 302
    
    
    kLightDataAttribute = 573
    
    
    kLightFogMaterial = 377
    
    
    kLightInfo = 375
    
    
    kLightLink = 763
    
    
    kLightList = 379
    
    
    kLightManip = 169
    
    
    kLightProjectionGeometry = 234
    
    
    kLightSource = 380
    
    
    kLightSourceMaterial = 388
    
    
    kLimitManip = 135
    
    
    kLineArrowManip = 235
    
    
    kLineManip = 147
    
    
    kLineModifier = 973
    
    
    kLinearLight = 306
    
    
    kLocator = 281
    
    
    kLodGroup = 768
    
    
    kLodThresholds = 766
    
    
    kLookAt = 112
    
    
    kLuminance = 381
    
    
    kMCsolver = 362
    
    
    kMPbirailSrf = 51
    
    
    kMakeGroup = 382
    
    
    kMandelbrot = 1079
    
    
    kMandelbrot3D = 1080
    
    
    kManip2DContainer = 192
    
    
    kManipContainer = 148
    
    
    kManipulator = 230
    
    
    kManipulator2D = 205
    
    
    kManipulator3D = 122
    
    
    kMarble = 509
    
    
    kMarker = 283
    
    
    kMarkerManip = 210
    
    
    kMaterial = 383
    
    
    kMaterialFacade = 970
    
    
    kMaterialInfo = 389
    
    
    kMatrixAdd = 390
    
    
    kMatrixArrayData = 598
    
    
    kMatrixAttribute = 574
    
    
    kMatrixData = 583
    
    
    kMatrixFloatData = 667
    
    
    kMatrixHold = 391
    
    
    kMatrixMult = 392
    
    
    kMatrixPass = 393
    
    
    kMatrixWtAdd = 394
    
    
    kMembrane = 1033
    
    
    kMentalRayTexture = 937
    
    
    kMergeVertsToolManip = 1034
    
    
    kMesh = 296
    
    
    kMeshComponent = 546
    
    
    kMeshData = 584
    
    
    kMeshEdgeComponent = 547
    
    
    kMeshFaceVertComponent = 551
    
    
    kMeshFrEdgeComponent = 549
    
    
    kMeshGeom = 297
    
    
    kMeshMapComponent = 812
    
    
    kMeshPolygonComponent = 548
    
    
    kMeshVarGroup = 117
    
    
    kMeshVertComponent = 550
    
    
    kMeshVtxFaceComponent = 740
    
    
    kMessageAttribute = 576
    
    
    kMidModifier = 395
    
    
    kMidModifierWithMatrix = 396
    
    
    kModel = 3
    
    
    kModifyEdgeBaseManip = 833
    
    
    kModifyEdgeCrvManip = 824
    
    
    kModifyEdgeManip = 825
    
    
    kMotionPath = 441
    
    
    kMotionPathManip = 170
    
    
    kMountain = 499
    
    
    kMoveUVShellManip2D = 705
    
    
    kMoveVertexManip = 758
    
    
    kMultDoubleLinear = 769
    
    
    kMultiSubVertexComponent = 554
    
    
    kMultilisterLight = 443
    
    
    kMultiplyDivide = 444
    
    
    kMute = 926
    
    
    kNBase = 993
    
    
    kNCloth = 1002
    
    
    kNComponent = 989
    
    
    kNId = 1031
    
    
    kNIdData = 1030
    
    
    kNLE = 1090
    
    
    kNObject = 1011
    
    
    kNObjectData = 1010
    
    
    kNParticle = 1003
    
    
    kNRigid = 1004
    
    
    kNamedObject = 2
    
    
    kNearestPointOnCurve = 1060
    
    
    kNewton = 260
    
    
    kNodeGraphEditorBookmarkInfo = 1113
    
    
    kNodeGraphEditorBookmarks = 1112
    
    
    kNodeGraphEditorInfo = 1111
    
    
    kNoise = 874
    
    
    kNonAmbientLight = 304
    
    
    kNonDagSelectionItem = 559
    
    
    kNonExtendedLight = 307
    
    
    kNonLinear = 618
    
    
    kNormalConstraint = 238
    
    
    kNucleus = 992
    
    
    kNumericAttribute = 562
    
    
    kNumericData = 587
    
    
    kNurbsBoolean = 688
    
    
    kNurbsCircular2PtArc = 638
    
    
    kNurbsCircular3PtArc = 637
    
    
    kNurbsCube = 80
    
    
    kNurbsCurve = 267
    
    
    kNurbsCurveData = 586
    
    
    kNurbsCurveGeom = 268
    
    
    kNurbsCurveToBezier = 1051
    
    
    kNurbsPlane = 79
    
    
    kNurbsSquare = 616
    
    
    kNurbsSurface = 294
    
    
    kNurbsSurfaceData = 585
    
    
    kNurbsSurfaceGeom = 295
    
    
    kNurbsTesselate = 78
    
    
    kNurbsToSubdiv = 755
    
    
    kObjectAttrFilter = 675
    
    
    kObjectBinFilter = 938
    
    
    kObjectFilter = 671
    
    
    kObjectMultiFilter = 672
    
    
    kObjectNameFilter = 673
    
    
    kObjectRenderFilter = 676
    
    
    kObjectScriptFilter = 677
    
    
    kObjectTypeFilter = 674
    
    
    kOcean = 870
    
    
    kOceanDeformer = 1121
    
    
    kOceanShader = 893
    
    
    kOffsetCos = 81
    
    
    kOffsetCosManip = 171
    
    
    kOffsetCurve = 82
    
    
    kOffsetCurveManip = 172
    
    
    kOffsetSurface = 639
    
    
    kOffsetSurfaceManip = 647
    
    
    kOldGeometryConstraint = 445
    
    
    kOpticalFX = 446
    
    
    kOrientConstraint = 239
    
    
    kOrientationComponent = 552
    
    
    kOrientationLocator = 286
    
    
    kOrientationMarker = 284
    
    
    kOrthoGrid = 291
    
    
    kPASolver = 363
    
    
    kPairBlend = 922
    
    
    kParamDimension = 275
    
    
    kParentConstraint = 242
    
    
    kParticle = 311
    
    
    kParticleAgeMapper = 447
    
    
    kParticleCloud = 448
    
    
    kParticleColorMapper = 449
    
    
    kParticleIncandecenceMapper = 450
    
    
    kParticleSamplerInfo = 801
    
    
    kParticleTransparencyMapper = 451
    
    
    kPartition = 452
    
    
    kPassContributionMap = 782
    
    
    kPfxGeometry = 940
    
    
    kPfxHair = 941
    
    
    kPfxToon = 966
    
    
    kPhong = 372
    
    
    kPhongExplorer = 373
    
    
    kPhongMaterial = 387
    
    
    kPinToGeometryProx = 986
    
    
    kPinToGeometryUV = 985
    
    
    kPivotComponent = 537
    
    
    kPivotManip2D = 191
    
    
    kPlace2dTexture = 453
    
    
    kPlace3dTexture = 454
    
    
    kPlanarProjectionManip = 207
    
    
    kPlanarTrimSrf = 83
    
    
    kPlane = 288
    
    
    kPlugin = 577
    
    
    kPluginBlendShape = 1116
    
    
    kPluginCameraSet = 1007
    
    
    kPluginClientDevice = 1073
    
    
    kPluginConstraintNode = 1012
    
    
    kPluginData = 596
    
    
    kPluginDeformerNode = 610
    
    
    kPluginDependNode = 455
    
    
    kPluginEmitterNode = 726
    
    
    kPluginFieldNode = 725
    
    
    kPluginGeometryData = 762
    
    
    kPluginGeometryFilter = 1115
    
    
    kPluginHardwareShader = 885
    
    
    kPluginHwShaderNode = 886
    
    
    kPluginIkSolver = 756
    
    
    kPluginImagePlaneNode = 1001
    
    
    kPluginLocatorNode = 456
    
    
    kPluginManipContainer = 691
    
    
    kPluginManipulatorNode = 1029
    
    
    kPluginMotionPathNode = 442
    
    
    kPluginObjectSet = 919
    
    
    kPluginParticleAttributeMapperNode = 1005
    
    
    kPluginShape = 706
    
    
    kPluginSkinCluster = 1114
    
    
    kPluginSpringNode = 727
    
    
    kPluginThreadedDevice = 1074
    
    
    kPluginTransformNode = 908
    
    
    kPlusMinusAverage = 457
    
    
    kPointArrayData = 597
    
    
    kPointConstraint = 240
    
    
    kPointLight = 309
    
    
    kPointManip = 236
    
    
    kPointMatrixMult = 458
    
    
    kPointOnCurveInfo = 84
    
    
    kPointOnCurveManip = 208
    
    
    kPointOnLineManip = 211
    
    
    kPointOnPolyConstraint = 1055
    
    
    kPointOnSurfaceInfo = 85
    
    
    kPointOnSurfaceManip = 212
    
    
    kPoleVectorConstraint = 243
    
    
    kPolyAppend = 399
    
    
    kPolyAppendVertex = 791
    
    
    kPolyArrow = 974
    
    
    kPolyAutoProj = 846
    
    
    kPolyAutoProjManip = 962
    
    
    kPolyAverageVertex = 845
    
    
    kPolyBevel = 397
    
    
    kPolyBevel2 = 1093
    
    
    kPolyBevel3 = 1097
    
    
    kPolyBlindData = 753
    
    
    kPolyBoolOp = 612
    
    
    kPolyBridgeEdge = 990
    
    
    kPolyCBoolOp = 1094
    
    
    kPolyCaddyManip = 1106
    
    
    kPolyChipOff = 400
    
    
    kPolyCircularize = 1126
    
    
    kPolyClean = 1119
    
    
    kPolyCloseBorder = 401
    
    
    kPolyCollapseEdge = 402
    
    
    kPolyCollapseF = 403
    
    
    kPolyColorDel = 736
    
    
    kPolyColorMod = 735
    
    
    kPolyColorPerVertex = 730
    
    
    kPolyComponentData = 980
    
    
    kPolyCone = 433
    
    
    kPolyConnectComponents = 1056
    
    
    kPolyContourProj = 1109
    
    
    kPolyCreaseEdge = 954
    
    
    kPolyCreateFacet = 439
    
    
    kPolyCreateToolManip = 140
    
    
    kPolyCreator = 431
    
    
    kPolyCube = 434
    
    
    kPolyCut = 896
    
    
    kPolyCutManip = 900
    
    
    kPolyCutManipContainer = 899
    
    
    kPolyCylProj = 404
    
    
    kPolyCylinder = 435
    
    
    kPolyDelEdge = 405
    
    
    kPolyDelFacet = 406
    
    
    kPolyDelVertex = 407
    
    
    kPolyDuplicateEdge = 968
    
    
    kPolyEdgeToCurve = 1014
    
    
    kPolyEditEdgeFlow = 1086
    
    
    kPolyExtrudeEdge = 788
    
    
    kPolyExtrudeFacet = 408
    
    
    kPolyExtrudeManip = 1069
    
    
    kPolyExtrudeManipContainer = 1070
    
    
    kPolyExtrudeVertex = 921
    
    
    kPolyFlipEdge = 787
    
    
    kPolyFlipUV = 883
    
    
    kPolyHelix = 981
    
    
    kPolyHoleFace = 1054
    
    
    kPolyLayoutUV = 847
    
    
    kPolyMapCut = 409
    
    
    kPolyMapDel = 410
    
    
    kPolyMapSew = 411
    
    
    kPolyMapSewMove = 848
    
    
    kPolyMappingManip = 194
    
    
    kPolyMergeEdge = 412
    
    
    kPolyMergeFacet = 413
    
    
    kPolyMergeUV = 905
    
    
    kPolyMergeVert = 693
    
    
    kPolyMesh = 436
    
    
    kPolyMirror = 953
    
    
    kPolyMirrorManipContainer = 901
    
    
    kPolyModifierManip = 195
    
    
    kPolyModifierManipContainer = 1107
    
    
    kPolyMoveEdge = 414
    
    
    kPolyMoveFacet = 415
    
    
    kPolyMoveFacetUV = 416
    
    
    kPolyMoveUV = 417
    
    
    kPolyMoveUVManip = 193
    
    
    kPolyMoveVertex = 418
    
    
    kPolyMoveVertexManip = 196
    
    
    kPolyMoveVertexUV = 419
    
    
    kPolyNormal = 420
    
    
    kPolyNormalPerVertex = 754
    
    
    kPolyNormalizeUV = 882
    
    
    kPolyPassThru = 1117
    
    
    kPolyPinUV = 955
    
    
    kPolyPipe = 977
    
    
    kPolyPlanProj = 421
    
    
    kPolyPlatonicSolid = 976
    
    
    kPolyPoke = 897
    
    
    kPolyPokeManip = 902
    
    
    kPolyPrimitive = 432
    
    
    kPolyPrimitiveMisc = 975
    
    
    kPolyPrism = 963
    
    
    kPolyProj = 422
    
    
    kPolyProjectCurve = 1067
    
    
    kPolyProjectionManip = 174
    
    
    kPolyPyramid = 964
    
    
    kPolyQuad = 423
    
    
    kPolyReduce = 765
    
    
    kPolyRemesh = 1108
    
    
    kPolySelectEditFeedbackManip = 1037
    
    
    kPolySeparate = 459
    
    
    kPolySewEdge = 692
    
    
    kPolySmooth = 424
    
    
    kPolySmoothFacet = 694
    
    
    kPolySmoothProxy = 939
    
    
    kPolySoftEdge = 425
    
    
    kPolySphProj = 426
    
    
    kPolySphere = 437
    
    
    kPolySpinEdge = 1053
    
    
    kPolySplit = 427
    
    
    kPolySplitEdge = 810
    
    
    kPolySplitRing = 965
    
    
    kPolySplitToolManip = 141
    
    
    kPolySplitVert = 805
    
    
    kPolyStraightenUVBorder = 906
    
    
    kPolySubdEdge = 428
    
    
    kPolySubdFacet = 429
    
    
    kPolyToSubdiv = 680
    
    
    kPolyToolFeedbackManip = 1036
    
    
    kPolyToolFeedbackShape = 312
    
    
    kPolyTorus = 438
    
    
    kPolyTransfer = 844
    
    
    kPolyTriangulate = 430
    
    
    kPolyTweak = 398
    
    
    kPolyTweakUV = 704
    
    
    kPolyUVRectangle = 1065
    
    
    kPolyUnite = 440
    
    
    kPolyVertexNormalManip = 197
    
    
    kPolyWedgeFace = 898
    
    
    kPoseInterpolatorManager = 1122
    
    
    kPositionMarker = 285
    
    
    kPostProcessList = 460
    
    
    kPrecompExport = 783
    
    
    kPrimitive = 86
    
    
    kProjectCurve = 87
    
    
    kProjectTangent = 88
    
    
    kProjectTangentManip = 177
    
    
    kProjection = 461
    
    
    kProjectionManip = 173
    
    
    kProjectionMultiManip = 176
    
    
    kProjectionUVManip = 175
    
    
    kPropModManip = 178
    
    
    kPropMoveTriadManip = 138
    
    
    kProxWrap = 352
    
    
    kProxy = 108
    
    
    kProxyManager = 961
    
    
    kPsdFileTexture = 943
    
    
    kQuadPtOnLineManip = 179
    
    
    kQuadShadingSwitch = 920
    
    
    kRBFsurface = 89
    
    
    kRPsolver = 365
    
    
    kRadial = 261
    
    
    kRadius = 274
    
    
    kRamp = 500
    
    
    kRampBackground = 26
    
    
    kRampShader = 891
    
    
    kRbfSrfManip = 180
    
    
    kReForm = 1124
    
    
    kRebuildCurve = 90
    
    
    kRebuildSurface = 91
    
    
    kRecord = 462
    
    
    kReference = 750
    
    
    kReflect = 370
    
    
    kRemapColor = 933
    
    
    kRemapHsv = 934
    
    
    kRemapValue = 932
    
    
    kRenderBox = 863
    
    
    kRenderCone = 97
    
    
    kRenderGlobals = 519
    
    
    kRenderGlobalsList = 520
    
    
    kRenderLayer = 780
    
    
    kRenderLayerManager = 781
    
    
    kRenderPass = 778
    
    
    kRenderPassSet = 779
    
    
    kRenderQuality = 521
    
    
    kRenderRect = 277
    
    
    kRenderSetup = 518
    
    
    kRenderSphere = 298
    
    
    kRenderTarget = 784
    
    
    kRenderUtilityList = 463
    
    
    kRenderedImageSource = 785
    
    
    kRenderingList = 1068
    
    
    kReorderUVSet = 1128
    
    
    kResolution = 522
    
    
    kResultCurve = 16
    
    
    kResultCurveTimeToAngular = 17
    
    
    kResultCurveTimeToDistance = 18
    
    
    kResultCurveTimeToTime = 19
    
    
    kResultCurveTimeToUnitless = 20
    
    
    kReverse = 464
    
    
    kReverseCrvManip = 182
    
    
    kReverseCurve = 92
    
    
    kReverseCurveManip = 181
    
    
    kReverseSurface = 93
    
    
    kReverseSurfaceManip = 183
    
    
    kRevolve = 94
    
    
    kRevolveManip = 184
    
    
    kRevolvedPrimitive = 95
    
    
    kRevolvedPrimitiveManip = 185
    
    
    kRgbToHsv = 465
    
    
    kRigid = 314
    
    
    kRigidConstraint = 313
    
    
    kRigidDeform = 341
    
    
    kRigidSolver = 466
    
    
    kRock = 510
    
    
    kRotateBoxManip = 214
    
    
    kRotateLimitsManip = 217
    
    
    kRotateManip = 215
    
    
    kRotateUVManip2D = 702
    
    
    kRoundConstantRadius = 640
    
    
    kRoundConstantRadiusManip = 643
    
    
    kRoundRadiusCrvManip = 642
    
    
    kRoundRadiusManip = 641
    
    
    kSCsolver = 364
    
    
    kSPbirailSrf = 52
    
    
    kSamplerInfo = 474
    
    
    kScaleConstraint = 244
    
    
    kScaleLimitsManip = 218
    
    
    kScaleManip = 219
    
    
    kScalePointManip = 826
    
    
    kScaleUVManip2D = 703
    
    
    kScalingBoxManip = 220
    
    
    kScreenAlignedCircleManip = 127
    
    
    kScript = 634
    
    
    kScriptManip = 221
    
    
    kSculpt = 342
    
    
    kSectionManip = 813
    
    
    kSelectionItem = 557
    
    
    kSelectionList = 603
    
    
    kSelectionListData = 670
    
    
    kSelectionListOperator = 678
    
    
    kSequenceManager = 1044
    
    
    kSequencer = 1045
    
    
    kSet = 467
    
    
    kSetGroupComponent = 555
    
    
    kSetRange = 470
    
    
    kSfRevolveManip = 836
    
    
    kShaderGlow = 471
    
    
    kShaderList = 472
    
    
    kShadingEngine = 320
    
    
    kShadingMap = 473
    
    
    kShape = 248
    
    
    kShapeEditorManager = 1120
    
    
    kShapeFragment = 475
    
    
    kShot = 1046
    
    
    kShrinkWrapFilter = 1091
    
    
    kSimpleVolumeShader = 476
    
    
    kSingleIndexedComponent = 708
    
    
    kSingleShadingSwitch = 613
    
    
    kSketchPlane = 289
    
    
    kSkin = 100
    
    
    kSkinBinding = 1057
    
    
    kSkinClusterFilter = 681
    
    
    kSkinShader = 668
    
    
    kSl60 = 477
    
    
    kSmear = 912
    
    
    kSmoothCurve = 695
    
    
    kSmoothTangentSrf = 777
    
    
    kSnapUVManip2D = 1088
    
    
    kSnapshot = 478
    
    
    kSnapshotPath = 918
    
    
    kSnapshotShape = 854
    
    
    kSnow = 511
    
    
    kSoftMod = 252
    
    
    kSoftModFilter = 348
    
    
    kSoftModManip = 632
    
    
    kSolidFractal = 512
    
    
    kSphere = 99
    
    
    kSphereData = 599
    
    
    kSphericalProjectionManip = 222
    
    
    kSplineSolver = 366
    
    
    kSpotCylinderManip = 187
    
    
    kSpotLight = 310
    
    
    kSpotManip = 186
    
    
    kSpring = 315
    
    
    kSprite = 292
    
    
    kSquareSrf = 712
    
    
    kSquareSrfManip = 713
    
    
    kStateManip = 145
    
    
    kStencil = 501
    
    
    kStereoCameraMaster = 1043
    
    
    kStitchAsNurbsShell = 686
    
    
    kStitchSrf = 101
    
    
    kStitchSrfManip = 689
    
    
    kStoryBoard = 479
    
    
    kStringArrayData = 601
    
    
    kStringData = 600
    
    
    kStringShadingSwitch = 913
    
    
    kStroke = 759
    
    
    kStrokeGlobals = 761
    
    
    kStucco = 513
    
    
    kStudioClearCoat = 914
    
    
    kStyleCurve = 895
    
    
    kSubCurve = 102
    
    
    kSubSurface = 776
    
    
    kSubVertexComponent = 553
    
    
    kSubdAddTopology = 887
    
    
    kSubdAutoProj = 872
    
    
    kSubdBlindData = 797
    
    
    kSubdBoolean = 822
    
    
    kSubdCleanTopology = 888
    
    
    kSubdCloseBorder = 859
    
    
    kSubdDelFace = 853
    
    
    kSubdExtrudeFace = 834
    
    
    kSubdHierBlind = 796
    
    
    kSubdLayoutUV = 868
    
    
    kSubdMapCut = 867
    
    
    kSubdMapSewMove = 869
    
    
    kSubdMappingManip = 880
    
    
    kSubdMergeVert = 860
    
    
    kSubdModifier = 849
    
    
    kSubdModifyEdge = 823
    
    
    kSubdMoveEdge = 851
    
    
    kSubdMoveFace = 852
    
    
    kSubdMoveVertex = 850
    
    
    kSubdPlanProj = 877
    
    
    kSubdProjectionManip = 879
    
    
    kSubdSplitFace = 864
    
    
    kSubdSubdivideFace = 873
    
    
    kSubdTweak = 878
    
    
    kSubdTweakUV = 866
    
    
    kSubdiv = 679
    
    
    kSubdivCVComponent = 697
    
    
    kSubdivCollapse = 800
    
    
    kSubdivCompId = 793
    
    
    kSubdivData = 806
    
    
    kSubdivEdgeComponent = 698
    
    
    kSubdivFaceComponent = 699
    
    
    kSubdivGeom = 807
    
    
    kSubdivMapComponent = 855
    
    
    kSubdivReverseFaces = 811
    
    
    kSubdivSurfaceVarGroup = 835
    
    
    kSubdivToNurbs = 815
    
    
    kSubdivToPoly = 714
    
    
    kSummaryObject = 480
    
    
    kSuper = 481
    
    
    kSurface = 293
    
    
    kSurfaceCVComponent = 538
    
    
    kSurfaceEPComponent = 539
    
    
    kSurfaceEdManip = 772
    
    
    kSurfaceFaceComponent = 773
    
    
    kSurfaceInfo = 103
    
    
    kSurfaceKnotComponent = 540
    
    
    kSurfaceLuminance = 483
    
    
    kSurfaceRangeComponent = 543
    
    
    kSurfaceShader = 484
    
    
    kSurfaceVarGroup = 118
    
    
    kSymmetryConstraint = 241
    
    
    kSymmetryLocator = 828
    
    
    kSymmetryMapCurve = 830
    
    
    kSymmetryMapVector = 829
    
    
    kTangentConstraint = 245
    
    
    kTension = 351
    
    
    kTexLattice = 200
    
    
    kTexLatticeDeformManip = 199
    
    
    kTexSmoothManip = 201
    
    
    kTexSmudgeUVManip = 198
    
    
    kTextButtonManip = 646
    
    
    kTextCurves = 104
    
    
    kTextManip = 923
    
    
    kTexture2d = 492
    
    
    kTexture3d = 503
    
    
    kTextureBakeSet = 468
    
    
    kTextureDeformer = 343
    
    
    kTextureDeformerHandle = 344
    
    
    kTextureEnv = 486
    
    
    kTextureList = 485
    
    
    kTextureManip3D = 223
    
    
    kThreadedDevice = 1071
    
    
    kThreePointArcManip = 644
    
    
    kTime = 516
    
    
    kTimeAttribute = 567
    
    
    kTimeEditor = 1101
    
    
    kTimeEditorAnimSource = 1104
    
    
    kTimeEditorClip = 1100
    
    
    kTimeEditorClipBase = 1098
    
    
    kTimeEditorClipEvaluator = 1099
    
    
    kTimeEditorInterpolator = 1103
    
    
    kTimeEditorTracks = 1102
    
    
    kTimeFunction = 936
    
    
    kTimeToUnitConversion = 517
    
    
    kTimeWarp = 1075
    
    
    kToggleManip = 224
    
    
    kToggleOnLineManip = 144
    
    
    kToolContext = 1089
    
    
    kToonLineAttributes = 967
    
    
    kTorus = 611
    
    
    kTowPointManip = 139
    
    
    kTowPointOnCurveManip = 209
    
    
    kTowPointOnSurfaceManip = 771
    
    
    kTrackInfoManager = 1118
    
    
    kTransferAttributes = 987
    
    
    kTransform = 110
    
    
    kTransformBoxManip = 827
    
    
    kTransformGeometry = 604
    
    
    kTranslateBoxManip = 225
    
    
    kTranslateLimitsManip = 226
    
    
    kTranslateManip = 227
    
    
    kTranslateManip2D = 206
    
    
    kTranslateUVManip = 213
    
    
    kTranslateUVManip2D = 701
    
    
    kTriadManip = 237
    
    
    kTrim = 105
    
    
    kTrimLocator = 287
    
    
    kTrimManip = 228
    
    
    kTrimWithBoundaries = 928
    
    
    kTriplanarProjectionManip = 188
    
    
    kTripleIndexedComponent = 710
    
    
    kTripleShadingSwitch = 615
    
    
    kTrsInsertManip = 203
    
    
    kTrsManip = 189
    
    
    kTrsTransManip = 202
    
    
    kTrsXformManip = 204
    
    
    kTurbulence = 262
    
    
    kTweak = 345
    
    
    kTwoPointArcManip = 645
    
    
    kTxSl = 514
    
    
    kTypedAttribute = 570
    
    
    kUInt64ArrayData = 808
    
    
    kUVManip2D = 700
    
    
    kUfeProxyTransform = 1129
    
    
    kUint64SingleIndexedComponent = 1035
    
    
    kUnderWorld = 109
    
    
    kUniform = 263
    
    
    kUnitAttribute = 569
    
    
    kUnitConversion = 525
    
    
    kUnitToTimeConversion = 526
    
    
    kUnknown = 528
    
    
    kUnknownDag = 316
    
    
    kUnknownTransform = 246
    
    
    kUntrim = 106
    
    
    kUnused1 = 838
    
    
    kUnused2 = 839
    
    
    kUnused3 = 840
    
    
    kUnused4 = 841
    
    
    kUnused5 = 842
    
    
    kUnused6 = 843
    
    
    kUseBackground = 527
    
    
    kUvChooser = 792
    
    
    kVectorArrayData = 602
    
    
    kVectorProduct = 529
    
    
    kVertexBakeSet = 469
    
    
    kVertexWeightSet = 1059
    
    
    kViewColorManager = 666
    
    
    kViewManip = 924
    
    
    kVolumeAxis = 794
    
    
    kVolumeBindManip = 1058
    
    
    kVolumeFog = 865
    
    
    kVolumeLight = 892
    
    
    kVolumeNoise = 871
    
    
    kVolumeShader = 530
    
    
    kVortex = 264
    
    
    kWater = 502
    
    
    kWeightGeometryFilt = 346
    
    
    kWire = 353
    
    
    kWood = 515
    
    
    kWorld = 247
    
    
    kWrapFilter = 739
    
    
    kWriteToColorBuffer = 1039
    
    
    kWriteToDepthBuffer = 1041
    
    
    kWriteToFrameBuffer = 1038
    
    
    kWriteToLabelBuffer = 1042
    
    
    kWriteToVectorBuffer = 1040
    
    
    kXformManip = 925
    
    
    kXsectionSubdivEdit = 814


class MGlobal(_object):
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def addToModel(*args, **kwargs): pass
    @staticmethod
    def addToModelAt(*args, **kwargs): pass
    @staticmethod
    def animSelectionMask(*args, **kwargs): pass
    @staticmethod
    def apiVersion(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def clearSelectionList(*args, **kwargs): pass
    @staticmethod
    def closeErrorLog(*args, **kwargs): pass
    @staticmethod
    def componentSelectionMask(*args, **kwargs): pass
    @staticmethod
    def currentToolContext(*args, **kwargs): pass
    @staticmethod
    def customVersion(*args, **kwargs): pass
    @staticmethod
    def defaultErrorLogPathName(*args, **kwargs): pass
    @staticmethod
    def deleteNode(*args, **kwargs): pass
    @staticmethod
    def disableStow(*args, **kwargs): pass
    @staticmethod
    def displayError(*args, **kwargs): pass
    @staticmethod
    def displayInfo(*args, **kwargs): pass
    @staticmethod
    def displayWarning(*args, **kwargs): pass
    @staticmethod
    def doErrorLogEntry(*args, **kwargs): pass
    @staticmethod
    def errorLogPathName(*args, **kwargs): pass
    @staticmethod
    def errorLoggingIsOn(*args, **kwargs): pass
    @staticmethod
    def executeCommand(*args, **kwargs): pass
    @staticmethod
    def executeCommandOnIdle(*args, **kwargs): pass
    @staticmethod
    def executeCommandStringResult(*args, **kwargs): pass
    @staticmethod
    def getAbsolutePathToResources(*args, **kwargs): pass
    @staticmethod
    def getActiveSelectionList(*args, **kwargs): pass
    @staticmethod
    def getAssociatedSets(*args, **kwargs): pass
    @staticmethod
    def getFunctionSetList(*args, **kwargs): pass
    @staticmethod
    def getHiliteList(*args, **kwargs): pass
    @staticmethod
    def getLiveList(*args, **kwargs): pass
    @staticmethod
    def getPreselectionHiliteList(*args, **kwargs): pass
    @staticmethod
    def getRichSelection(*args, **kwargs): pass
    @staticmethod
    def getSelectionListByName(*args, **kwargs): pass
    @staticmethod
    def isRedoing(*args, **kwargs): pass
    @staticmethod
    def isSelected(*args, **kwargs): pass
    @staticmethod
    def isUndoing(*args, **kwargs): pass
    @staticmethod
    def isYAxisUp(*args, **kwargs): pass
    @staticmethod
    def isZAxisUp(*args, **kwargs): pass
    @staticmethod
    def mayaState(*args, **kwargs): pass
    @staticmethod
    def mayaVersion(*args, **kwargs): pass
    @staticmethod
    def miscSelectionMask(*args, **kwargs): pass
    @staticmethod
    def objectSelectionMask(*args, **kwargs): pass
    @staticmethod
    def optionVarDoubleValue(*args, **kwargs): pass
    @staticmethod
    def optionVarExists(*args, **kwargs): pass
    @staticmethod
    def optionVarIntValue(*args, **kwargs): pass
    @staticmethod
    def optionVarStringValue(*args, **kwargs): pass
    @staticmethod
    def removeFromModel(*args, **kwargs): pass
    @staticmethod
    def removeOptionVar(*args, **kwargs): pass
    @staticmethod
    def resetToDefaultErrorLogPathName(*args, **kwargs): pass
    @staticmethod
    def select(*args, **kwargs): pass
    @staticmethod
    def selectByName(*args, **kwargs): pass
    @staticmethod
    def selectCommand(*args, **kwargs): pass
    @staticmethod
    def selectFromScreen(*args, **kwargs): pass
    @staticmethod
    def selectionMethod(*args, **kwargs): pass
    @staticmethod
    def selectionMode(*args, **kwargs): pass
    @staticmethod
    def setActiveSelectionList(*args, **kwargs): pass
    @staticmethod
    def setAnimSelectionMask(*args, **kwargs): pass
    @staticmethod
    def setComponentSelectionMask(*args, **kwargs): pass
    @staticmethod
    def setDisableStow(*args, **kwargs): pass
    @staticmethod
    def setDisplayCVs(*args, **kwargs): pass
    @staticmethod
    def setErrorLogPathName(*args, **kwargs): pass
    @staticmethod
    def setHiliteList(*args, **kwargs): pass
    @staticmethod
    def setMiscSelectionMask(*args, **kwargs): pass
    @staticmethod
    def setObjectSelectionMask(*args, **kwargs): pass
    @staticmethod
    def setOptionVarValue(*args, **kwargs): pass
    @staticmethod
    def setPreselectionHiliteList(*args, **kwargs): pass
    @staticmethod
    def setRichSelection(*args, **kwargs): pass
    @staticmethod
    def setSelectionMode(*args, **kwargs): pass
    @staticmethod
    def setTrackSelectionOrderEnabled(*args, **kwargs): pass
    @staticmethod
    def setYAxisUp(*args, **kwargs): pass
    @staticmethod
    def setZAxisUp(*args, **kwargs): pass
    @staticmethod
    def sourceFile(*args, **kwargs): pass
    @staticmethod
    def startErrorLogging(*args, **kwargs): pass
    @staticmethod
    def stopErrorLogging(*args, **kwargs): pass
    @staticmethod
    def trackSelectionOrderEnabled(*args, **kwargs): pass
    @staticmethod
    def unselect(*args, **kwargs): pass
    @staticmethod
    def unselectByName(*args, **kwargs): pass
    @staticmethod
    def upAxis(*args, **kwargs): pass
    @staticmethod
    def viewFrame(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kAddToHeadOfList = 4
    
    
    kAddToList = 2
    
    
    kBaseUIMode = 3
    
    
    kBatch = 1
    
    
    kInteractive = 0
    
    
    kLibraryApp = 2
    
    
    kRemoveFromList = 3
    
    
    kReplaceList = 0
    
    
    kSelectComponentMode = 1
    
    
    kSelectLeafMode = 3
    
    
    kSelectObjectMode = 0
    
    
    kSelectRootMode = 2
    
    
    kSelectTemplateMode = 4
    
    
    kSurfaceSelectMethod = 0
    
    
    kWireframeSelectMethod = 1
    
    
    kXORWithList = 1


class MAttributeSpec(_object):
    def __del__(self): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def dimensions(self, *args): pass
    def name(self, *args): pass
    def setDimensions(self, *args): pass
    def setName(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MDGModifier(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addAttribute(self, *args): pass
    def addExtensionAttribute(self, *args): pass
    def commandToExecute(self, *args): pass
    def connect(self, *args): pass
    def createNode(self, *args): pass
    def deleteMetadata(self, *args): pass
    def deleteNode(self, *args): pass
    def disconnect(self, *args): pass
    def doIt(self, *args): pass
    def linkExtensionAttributeToPlugin(self, *args): pass
    def newPlugValue(self, *args): pass
    def newPlugValueBool(self, *args): pass
    def newPlugValueChar(self, *args): pass
    def newPlugValueDouble(self, *args): pass
    def newPlugValueFloat(self, *args): pass
    def newPlugValueInt(self, *args): pass
    def newPlugValueInt64(self, *args): pass
    def newPlugValueMAngle(self, *args): pass
    def newPlugValueMDistance(self, *args): pass
    def newPlugValueMTime(self, *args): pass
    def newPlugValueShort(self, *args): pass
    def newPlugValueString(self, *args): pass
    def pythonCommandToExecute(self, *args): pass
    def removeAttribute(self, *args): pass
    def removeExtensionAttribute(self, *args): pass
    def removeExtensionAttributeIfUnset(self, *args): pass
    def removeMultiInstance(self, *args): pass
    def renameAttribute(self, *args): pass
    def renameNode(self, *args): pass
    def setMetadata(self, *args): pass
    def setNodeLockState(self, *args): pass
    def undoIt(self, *args): pass
    def unlinkExtensionAttributeFromPlugin(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MAngle(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def asAngMinutes(self, *args): pass
    def asAngSeconds(self, *args): pass
    def asDegrees(self, *args): pass
    def asRadians(self, *args): pass
    def asUnits(self, *args): pass
    def assign(self, *args): pass
    def setUnit(self, *args): pass
    def setValue(self, *args): pass
    def unit(self, *args): pass
    def value(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def internalToUI(*args, **kwargs): pass
    @staticmethod
    def internalUnit(*args, **kwargs): pass
    @staticmethod
    def setInternalUnit(*args, **kwargs): pass
    @staticmethod
    def setUIUnit(*args, **kwargs): pass
    @staticmethod
    def uiToInternal(*args, **kwargs): pass
    @staticmethod
    def uiUnit(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kAngMinutes = 3
    
    
    kAngSeconds = 4
    
    
    kDegrees = 2
    
    
    kInvalid = 0
    
    
    kLast = 5
    
    
    kRadians = 1


class MProfilingScope(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MItMeshFaceVertex(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def currentItem(self, *args): pass
    def faceId(self, *args): pass
    def faceVertId(self, *args): pass
    def faceVertex(self, *args): pass
    def geomChanged(self, *args): pass
    def getBinormal(self, *args): pass
    def getColor(self, *args): pass
    def getColorIndex(self, *args): pass
    def getNormal(self, *args): pass
    def getTangent(self, *args): pass
    def getUV(self, *args): pass
    def getUVIndex(self, *args): pass
    def hasColor(self, *args): pass
    def hasUVs(self, *args): pass
    def isDone(self, *args): pass
    def next(self, *args): pass
    def normalId(self, *args): pass
    def position(self, *args): pass
    def reset(self, *args): pass
    def setIndex(self, *args): pass
    def tangentId(self, *args): pass
    def updateSurface(self, *args): pass
    def vertId(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MPlug(_object):
    def __del__(self): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __init__(self, *args): pass
    def __ne__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def array(self, *args): pass
    def asBool(self, *args): pass
    def asChar(self, *args): pass
    def asDouble(self, *args): pass
    def asFloat(self, *args): pass
    def asInt(self, *args): pass
    def asInt64(self, *args): pass
    def asMAngle(self, *args): pass
    def asMDataHandle(self, *args): pass
    def asMDistance(self, *args): pass
    def asMObject(self, *args): pass
    def asMTime(self, *args): pass
    def asShort(self, *args): pass
    def asString(self, *args): pass
    def assign(self, *args): pass
    def attribute(self, *args): pass
    def child(self, *args): pass
    def connectedTo(self, *args): pass
    def connectionByPhysicalIndex(self, *args): pass
    def constructHandle(self, *args): pass
    def destinations(self, *args): pass
    def destinationsWithConversions(self, *args): pass
    def destructHandle(self, *args): pass
    def elementByLogicalIndex(self, *args): pass
    def elementByPhysicalIndex(self, *args): pass
    def evaluateNumElements(self, *args): pass
    def getExistingArrayAttributeIndices(self, *args): pass
    def getSetAttrCmds(self, *args): pass
    def info(self, *args): pass
    def isArray(self, *args): pass
    def isCachingFlagSet(self, *args): pass
    def isChannelBoxFlagSet(self, *args): pass
    def isChild(self, *args): pass
    def isCompound(self, *args): pass
    def isConnected(self, *args): pass
    def isDefaultValue(self, *args): pass
    def isDestination(self, *args): pass
    def isDynamic(self, *args): pass
    def isElement(self, *args): pass
    def isFreeToChange(self, *args): pass
    def isFromReferencedFile(self, *args): pass
    def isIgnoredWhenRendering(self, *args): pass
    def isKeyable(self, *args): pass
    def isLocked(self, *args): pass
    def isNetworked(self, *args): pass
    def isNull(self, *args): pass
    def isProcedural(self, *args): pass
    def isSource(self, *args): pass
    def logicalIndex(self, *args): pass
    def name(self, *args): pass
    def node(self, *args): pass
    def numChildren(self, *args): pass
    def numConnectedChildren(self, *args): pass
    def numConnectedElements(self, *args): pass
    def numElements(self, *args): pass
    def parent(self, *args): pass
    def partialName(self, *args): pass
    def selectAncestorLogicalIndex(self, *args): pass
    def setAttribute(self, *args): pass
    def setBool(self, *args): pass
    def setCaching(self, *args): pass
    def setChannelBox(self, *args): pass
    def setChar(self, *args): pass
    def setDouble(self, *args): pass
    def setFloat(self, *args): pass
    def setInt(self, *args): pass
    def setInt64(self, *args): pass
    def setKeyable(self, *args): pass
    def setLocked(self, *args): pass
    def setMAngle(self, *args): pass
    def setMDataHandle(self, *args): pass
    def setMDistance(self, *args): pass
    def setMObject(self, *args): pass
    def setMPxData(self, *args): pass
    def setMTime(self, *args): pass
    def setNumElements(self, *args): pass
    def setShort(self, *args): pass
    def setString(self, *args): pass
    def source(self, *args): pass
    def sourceWithConversion(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kAll = 0
    
    
    kChanged = 2
    
    
    kChildrenNotFreeToChange = 2
    
    
    kFreeToChange = 0
    
    
    kLastAttrSelector = 3
    
    
    kNonDefault = 1
    
    
    kNotFreeToChange = 1


class MColorArray(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def append(self, *args): pass
    def assign(self, *args): pass
    def clear(self, *args): pass
    def copy(self, *args): pass
    def get(self, *args): pass
    def insert(self, *args): pass
    def length(self, *args): pass
    def remove(self, *args): pass
    def set(self, *args): pass
    def setLength(self, *args): pass
    def setSizeIncrement(self, *args): pass
    def sizeIncrement(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MCacheConfigRuleRegistry(_object):
    def __getattr__(self, name): pass
    def __init__(self, *args, **kwargs): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def registerFilter(*args, **kwargs): pass
    @staticmethod
    def registeringCallableScript(*args, **kwargs): pass
    @staticmethod
    def setRegisteringCallableScript(*args, **kwargs): pass
    @staticmethod
    def unregisterFilter(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MFloatPoint(_object):
    def __add__(self, *args): pass
    def __call__(self, *args): pass
    def __del__(self): pass
    def __div__(self, *args): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __iadd__(self, *args): pass
    def __imul__(self, *args): pass
    def __init__(self, *args): pass
    def __isub__(self, *args): pass
    def __iter__(self):
        """
        Iterates on all components of a Maya api FloatPoint
        """
        pass
    def __len__(self):
        """
        Number of components in the Maya api FloatPoint, ie 4
        """
        pass
    def __mul__(self, *args): pass
    def __ne__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def __sub__(self, *args): pass
    def __truediv__(self, *args): pass
    def assign(self, *args): pass
    def cartesianize(self, *args): pass
    def distanceTo(self, *args): pass
    def get(self, *args): pass
    def homogenize(self, *args): pass
    def isEquivalent(self, *args): pass
    def rationalize(self, *args): pass
    def setCast(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @property
    def w(self): pass
    @property
    def x(self): pass
    @property
    def y(self): pass
    @property
    def z(self): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    origin = None


class MTesselationParams(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def set3DDelta(self, *args): pass
    def setBoundingBoxDiagonal(self, *args): pass
    def setChordHeightRatio(self, *args): pass
    def setEdgeSmoothFactor(self, *args): pass
    def setFitTolerance(self, *args): pass
    def setFormatType(self, *args): pass
    def setMaxEdgeLength(self, *args): pass
    def setMaxNumberPolys(self, *args): pass
    def setMaxSubdivisionLevel(self, *args): pass
    def setMaxUVRectangleSize(self, *args): pass
    def setMinEdgeLength(self, *args): pass
    def setMinScreenSize(self, *args): pass
    def setOutputType(self, *args): pass
    def setRelativeFitTolerance(self, *args): pass
    def setStdChordHeightRatio(self, *args): pass
    def setStdFractionalTolerance(self, *args): pass
    def setStdMinEdgeLength(self, *args): pass
    def setSubdivisionFlag(self, *args): pass
    def setTriangleCount(self, *args): pass
    def setUDistanceFraction(self, *args): pass
    def setUIsoparmType(self, *args): pass
    def setUNumber(self, *args): pass
    def setVDistanceFraction(self, *args): pass
    def setVIsoparmType(self, *args): pass
    def setVNumber(self, *args): pass
    def setWorldspaceToScreenTransform(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @property
    def fsDefaultTesselationParams(self): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kGeneralFormat = 2
    
    
    kLastFlag = 11
    
    
    kQuads = 1
    
    
    kSpanEquiSpaced = 3
    
    
    kStandardFitFormat = 1
    
    
    kSurface3DDistance = 0
    
    
    kSurface3DEquiSpaced = 1
    
    
    kSurfaceEquiSpaced = 2
    
    
    kTriangleCountFormat = 0
    
    
    kTriangles = 0
    
    
    kUseChordHeightRatio = 1
    
    
    kUseEdgeSmooth = 10
    
    
    kUseFractionalTolerance = 0
    
    
    kUseMaxEdgeLength = 3
    
    
    kUseMaxNumberPolys = 4
    
    
    kUseMaxSubdivisionLevel = 5
    
    
    kUseMaxUVRectangleSize = 7
    
    
    kUseMinEdgeLength = 2
    
    
    kUseMinScreenSize = 6
    
    
    kUseRelativeTolerance = 9
    
    
    kUseTriangleEdgeSwapping = 8


class MItMeshVertex(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def connectedToEdge(self, *args): pass
    def connectedToFace(self, *args): pass
    def count(self, *args): pass
    def currentItem(self, *args): pass
    def geomChanged(self, *args): pass
    def getColor(self, *args): pass
    def getColorIndices(self, *args): pass
    def getColors(self, *args): pass
    def getConnectedEdges(self, *args): pass
    def getConnectedFaces(self, *args): pass
    def getConnectedVertices(self, *args): pass
    def getNormal(self, *args): pass
    def getNormalIndices(self, *args): pass
    def getNormals(self, *args): pass
    def getOppositeVertex(self, *args): pass
    def getUV(self, *args): pass
    def getUVIndices(self, *args): pass
    def getUVs(self, *args): pass
    def hasColor(self, *args): pass
    def index(self, *args): pass
    def isDone(self, *args): pass
    def next(self, *args): pass
    def numConnectedEdges(self, *args): pass
    def numConnectedFaces(self, *args): pass
    def numUVs(self, *args): pass
    def onBoundary(self, *args): pass
    def position(self, *args): pass
    def reset(self, *args): pass
    def setIndex(self, *args): pass
    def setPosition(self, *args): pass
    def setUV(self, *args): pass
    def setUVs(self, *args): pass
    def translateBy(self, *args): pass
    def updateSurface(self, *args): pass
    def vertex(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MDGContext(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def getTime(self, *args): pass
    def isCurrent(self, *args): pass
    def isNormal(self, *args): pass
    def makeCurrent(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def current(*args, **kwargs): pass
    @property
    def fsNormal(self): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MEvaluationNodeIterator(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def isDone(self, *args): pass
    def next(self, *args): pass
    def plug(self, *args): pass
    def reset(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MTransformationMatrix(_object):
    def __del__(self): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __iter__(self):
        """
        Iterates on all 4 rows of a Maya api TransformationMatrix
        """
        pass
    def __len__(self):
        """
        Number of rows in the Maya api Matrix, ie 4.
        Not to be confused with the number of components (16) given by the size method
        """
        pass
    def __ne__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addRotation(self, *args): pass
    def addRotationQuaternion(self, *args): pass
    def addScale(self, *args): pass
    def addShear(self, *args): pass
    def addTranslation(self, *args): pass
    def asMatrix(self, *args): pass
    def asMatrixInverse(self, *args): pass
    def asRotateMatrix(self, *args): pass
    def asScaleMatrix(self, *args): pass
    def assign(self, *args): pass
    def eulerRotation(self, *args): pass
    def getRotation(self, *args): pass
    def getRotationQuaternion(self, *args): pass
    def getScale(self, *args): pass
    def getShear(self, *args): pass
    def getTranslation(self, *args): pass
    def isEquivalent(self, *args): pass
    def reorderRotation(self, *args): pass
    def rotateBy(self, *args): pass
    def rotatePivot(self, *args): pass
    def rotatePivotTranslation(self, *args): pass
    def rotateTo(self, *args): pass
    def rotation(self, *args): pass
    def rotationOrder(self, *args): pass
    def rotationOrientation(self, *args): pass
    def scalePivot(self, *args): pass
    def scalePivotTranslation(self, *args): pass
    def setRotatePivot(self, *args): pass
    def setRotatePivotTranslation(self, *args): pass
    def setRotation(self, *args): pass
    def setRotationOrientation(self, *args): pass
    def setRotationQuaternion(self, *args): pass
    def setScale(self, *args): pass
    def setScalePivot(self, *args): pass
    def setScalePivotTranslation(self, *args): pass
    def setShear(self, *args): pass
    def setToRotationAxis(self, *args): pass
    def setTranslation(self, *args): pass
    def translation(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    identity = None
    
    
    kInvalid = 0
    
    
    kLast = 7
    
    
    kXYZ = 1
    
    
    kXZY = 4
    
    
    kYXZ = 5
    
    
    kYZX = 2
    
    
    kZXY = 3
    
    
    kZYX = 6


class MMatrixArray(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def append(self, *args): pass
    def assign(self, *args): pass
    def clear(self, *args): pass
    def copy(self, *args): pass
    def insert(self, *args): pass
    def length(self, *args): pass
    def remove(self, *args): pass
    def set(self, *args): pass
    def setLength(self, *args): pass
    def setSizeIncrement(self, *args): pass
    def sizeIncrement(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MAttributeSpecArray(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def append(self, *args): pass
    def assign(self, *args): pass
    def clear(self, *args): pass
    def copy(self, *args): pass
    def insert(self, *args): pass
    def length(self, *args): pass
    def remove(self, *args): pass
    def set(self, *args): pass
    def setLength(self, *args): pass
    def setSizeIncrement(self, *args): pass
    def sizeIncrement(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MItSubdFace(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def index(self, *args): pass
    def isDone(self, *args): pass
    def isValid(self, *args): pass
    def level(self, *args): pass
    def next(self, *args): pass
    def reset(self, *args): pass
    def setLevel(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MFloatVector(_object):
    def __add__(self, *args): pass
    def __call__(self, *args): pass
    def __del__(self): pass
    def __div__(self, *args): pass
    def __eq__(self, *args): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __iadd__(self, *args): pass
    def __idiv__(self, *args): pass
    def __imul__(self, *args): pass
    def __init__(self, *args): pass
    def __isub__(self, *args): pass
    def __iter__(self):
        """
        Iterates on all components of a Maya api FloatVector
        """
        pass
    def __itruediv__(self, *args): pass
    def __len__(self):
        """
        Number of components in the Maya api FloatVector, ie 3
        """
        pass
    def __mul__(self, *args): pass
    def __ne__(self, *args): pass
    def __neg__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def __sub__(self, *args): pass
    def __truediv__(self, *args): pass
    def __xor__(self, *args): pass
    def angle(self, *args): pass
    def assign(self, *args): pass
    def get(self, *args): pass
    def isEquivalent(self, *args): pass
    def isParallel(self, *args): pass
    def length(self, *args): pass
    def normal(self, *args): pass
    def normalize(self, *args): pass
    @property
    def x(self): pass
    @property
    def y(self): pass
    @property
    def z(self): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    one = None
    
    
    xAxis = None
    
    
    xNegAxis = None
    
    
    yAxis = None
    
    
    yNegAxis = None
    
    
    zAxis = None
    
    
    zNegAxis = None
    
    
    zero = None


class MNodeClass(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addExtensionAttribute(self, *args): pass
    def addToClassification(self, *args): pass
    def attribute(self, *args): pass
    def attributeCount(self, *args): pass
    def classification(self, *args): pass
    def getAttributes(self, *args): pass
    def hasAttribute(self, *args): pass
    def pluginName(self, *args): pass
    def removeExtensionAttribute(self, *args): pass
    def removeExtensionAttributeIfUnset(self, *args): pass
    def removeFromClassification(self, *args): pass
    def typeId(self, *args): pass
    def typeName(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class floatPtr(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def cast(self, *args): pass
    def value(self, *args): pass
    @staticmethod
    def frompointer(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MArgParser(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def commandArgumentBool(self, *args): pass
    def commandArgumentDouble(self, *args): pass
    def commandArgumentInt(self, *args): pass
    def commandArgumentMAngle(self, *args): pass
    def commandArgumentMDistance(self, *args): pass
    def commandArgumentMTime(self, *args): pass
    def commandArgumentString(self, *args): pass
    def flagArgumentBool(self, *args): pass
    def flagArgumentDouble(self, *args): pass
    def flagArgumentInt(self, *args): pass
    def flagArgumentMAngle(self, *args): pass
    def flagArgumentMDistance(self, *args): pass
    def flagArgumentMTime(self, *args): pass
    def flagArgumentString(self, *args): pass
    def getFlagArgumentList(self, *args): pass
    def getFlagArgumentPosition(self, *args): pass
    def getObjects(self, *args): pass
    def isEdit(self, *args): pass
    def isFlagSet(self, *args): pass
    def isQuery(self, *args): pass
    def numberOfFlagUses(self, *args): pass
    def numberOfFlagsUsed(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MRenderPassDef(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args, **kwargs): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addDoubleParameter(self, *args): pass
    def addFloatParameter(self, *args): pass
    def addIntParameter(self, *args): pass
    def getAttributeType(self, *args): pass
    def getDescription(self, *args): pass
    def getGroup(self, *args): pass
    def getID(self, *args): pass
    def getImplementation(self, *args): pass
    def getName(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MNamespace(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def addNamespace(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def currentNamespace(*args, **kwargs): pass
    @staticmethod
    def getNamespaceFromName(*args, **kwargs): pass
    @staticmethod
    def getNamespaceObjects(*args, **kwargs): pass
    @staticmethod
    def getNamespaces(*args, **kwargs): pass
    @staticmethod
    def makeNamepathAbsolute(*args, **kwargs): pass
    @staticmethod
    def moveNamespace(*args, **kwargs): pass
    @staticmethod
    def namespaceExists(*args, **kwargs): pass
    @staticmethod
    def parentNamespace(*args, **kwargs): pass
    @staticmethod
    def relativeNames(*args, **kwargs): pass
    @staticmethod
    def removeNamespace(*args, **kwargs): pass
    @staticmethod
    def renameNamespace(*args, **kwargs): pass
    @staticmethod
    def rootNamespace(*args, **kwargs): pass
    @staticmethod
    def setCurrentNamespace(*args, **kwargs): pass
    @staticmethod
    def setRelativeNames(*args, **kwargs): pass
    @staticmethod
    def stripNamespaceFromName(*args, **kwargs): pass
    @staticmethod
    def validateName(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class uCharPtr(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def cast(self, *args): pass
    def value(self, *args): pass
    @staticmethod
    def frompointer(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MPointOnMesh(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def faceIndex(self, *args): pass
    def getBarycentricCoords(self, *args): pass
    def getNormal(self, *args): pass
    def getPoint(self, *args): pass
    def triangleIndex(self, *args): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MImageFileInfo(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def channels(self, *args): pass
    def hardwareType(self, *args): pass
    def hasAlpha(self, *args): pass
    def hasMipMaps(self, *args): pass
    def height(self, *args): pass
    def imageType(self, *args): pass
    def numberOfImages(self, *args): pass
    def pixelType(self, *args): pass
    def width(self, *args): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kHwTexture1D = 1
    
    
    kHwTexture2D = 2
    
    
    kHwTexture3D = 3
    
    
    kHwTextureCubeMap = 5
    
    
    kHwTextureRectangle = 4
    
    
    kHwTextureUnknown = 0
    
    
    kImageTypeBump = 3
    
    
    kImageTypeColor = 1
    
    
    kImageTypeNormal = 2
    
    
    kImageTypeUnknown = 0


class MImage(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def convertPixelFormat(self, *args): pass
    def create(self, *args): pass
    def depth(self, *args): pass
    def depthMap(self, *args): pass
    def filter(self, *args): pass
    def floatPixels(self, *args): pass
    def getDepthMapRange(self, *args): pass
    def getDepthMapSize(self, *args): pass
    def getSize(self, *args): pass
    def haveDepth(self, *args): pass
    def isRGBA(self, *args): pass
    def pixelType(self, *args): pass
    def pixels(self, *args): pass
    def readDepthMap(self, *args): pass
    def readFromFile(self, *args): pass
    def readFromTextureNode(self, *args): pass
    def release(self, *args): pass
    def resize(self, *args): pass
    def setDepthMap(self, *args): pass
    def setFloatPixels(self, *args): pass
    def setPixels(self, *args): pass
    def setRGBA(self, *args): pass
    def verticalFlip(self, *args): pass
    def writeToFile(self, *args): pass
    def writeToFileWithDepth(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def filterExists(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None
    
    
    kByte = 1
    
    
    kFloat = 2
    
    
    kHeightFieldBumpFormat = 1
    
    
    kNoFormat = 0
    
    
    kNormalMapBumpFormat = 2
    
    
    kUnknown = 0
    
    
    kUnknownFormat = 3


class MItSurfaceCV(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def currentItem(self, *args): pass
    def cv(self, *args): pass
    def getIndex(self, *args): pass
    def hasHistoryOnCreate(self, *args): pass
    def index(self, *args): pass
    def isDone(self, *args): pass
    def isRowDone(self, *args): pass
    def next(self, *args): pass
    def nextRow(self, *args): pass
    def position(self, *args): pass
    def reset(self, *args): pass
    def setPosition(self, *args): pass
    def translateBy(self, *args): pass
    def updateSurface(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class array2dFloat(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def get(self, *args): pass
    def getptr(self, *args): pass
    def set(self, *args): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class boolPtr(_object):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def assign(self, *args): pass
    def cast(self, *args): pass
    def value(self, *args): pass
    @staticmethod
    def frompointer(*args, **kwargs): pass
    __dict__ = None
    
    
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    __weakref__ = None


class MConnectDisconnectAttrEdit(MEdit):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args, **kwargs): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def dstPlug(self, *args): pass
    def dstPlugName(self, *args): pass
    def editType(self, *args): pass
    def isConnection(self, *args): pass
    def srcPlug(self, *args): pass
    def srcPlugName(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MModelMessage(MMessage):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def addAfterDuplicateCallback(*args, **kwargs): pass
    @staticmethod
    def addBeforeDuplicateCallback(*args, **kwargs): pass
    @staticmethod
    def addCallback(*args, **kwargs): pass
    @staticmethod
    def addNodeAddedToModelCallback(*args, **kwargs): pass
    @staticmethod
    def addNodeRemovedFromModelCallback(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kActiveListModified = 0


class MCommandMessage(MMessage):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def addCommandCallback(*args, **kwargs): pass
    @staticmethod
    def addCommandOutputCallback(*args, **kwargs): pass
    @staticmethod
    def addCommandOutputFilterCallback(*args, **kwargs): pass
    @staticmethod
    def addProcCallback(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kDisplay = 1
    
    
    kError = 4
    
    
    kHistory = 0
    
    
    kInfo = 2
    
    
    kMELCommand = 1
    
    
    kMELProc = 0
    
    
    kResult = 5
    
    
    kStackTrace = 6
    
    
    kWarning = 3


class MFnData(MFnBase):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kAny = 24
    
    
    kComponentList = 13
    
    
    kDoubleArray = 7
    
    
    kDynArrayAttrs = 19
    
    
    kDynSweptGeometry = 20
    
    
    kFloatArray = 8
    
    
    kIntArray = 9
    
    
    kInvalid = 0
    
    
    kLast = 25
    
    
    kLattice = 15
    
    
    kMatrix = 5
    
    
    kMatrixArray = 12
    
    
    kMesh = 14
    
    
    kNId = 23
    
    
    kNObject = 22
    
    
    kNumeric = 1
    
    
    kNurbsCurve = 16
    
    
    kNurbsSurface = 17
    
    
    kPlugin = 2
    
    
    kPluginGeometry = 3
    
    
    kPointArray = 10
    
    
    kSphere = 18
    
    
    kString = 4
    
    
    kStringArray = 6
    
    
    kSubdSurface = 21
    
    
    kVectorArray = 11


class MArgDatabase(MArgParser):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def getCommandArgument(self, *args): pass
    def getFlagArgument(self, *args): pass
    def getObjects(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MCameraMessage(MMessage):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def addBeginManipulationCallback(*args, **kwargs): pass
    @staticmethod
    def addEndManipulationCallback(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MPolyMessage(MMessage):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def addColorSetChangedCallback(*args, **kwargs): pass
    @staticmethod
    def addPolyComponentIdChangedCallback(*args, **kwargs): pass
    @staticmethod
    def addPolyTopologyChangedCallback(*args, **kwargs): pass
    @staticmethod
    def addUVSetChangedCallback(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def deletedId(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kColorSetAdded = 0
    
    
    kColorSetDeleted = 1
    
    
    kCurrentColorSetChanged = 2
    
    
    kCurrentUVSetChanged = 2
    
    
    kEdgeIndex = 1
    
    
    kFaceIndex = 2
    
    
    kLastErrorIndex = 3
    
    
    kUVSetAdded = 0
    
    
    kUVSetDeleted = 1
    
    
    kVertexIndex = 0


class MEventMessage(MMessage):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def addEventCallback(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def getEventNames(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MAddRemoveAttrEdit(MEdit):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args, **kwargs): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def attributeName(self, *args): pass
    def editType(self, *args): pass
    def isAttributeAdded(self, *args): pass
    def node(self, *args): pass
    def nodeName(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MDGMessage(MMessage):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def addConnectionCallback(*args, **kwargs): pass
    @staticmethod
    def addDelayedTimeChangeCallback(*args, **kwargs): pass
    @staticmethod
    def addDelayedTimeChangeRunupCallback(*args, **kwargs): pass
    @staticmethod
    def addForceUpdateCallback(*args, **kwargs): pass
    @staticmethod
    def addNodeAddedCallback(*args, **kwargs): pass
    @staticmethod
    def addNodeChangeUuidCheckCallback(*args, **kwargs): pass
    @staticmethod
    def addNodeRemovedCallback(*args, **kwargs): pass
    @staticmethod
    def addPreConnectionCallback(*args, **kwargs): pass
    @staticmethod
    def addTimeChangeCallback(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnDependencyNode(MFnBase):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def absoluteName(self, *args): pass
    def addAttribute(self, *args): pass
    def addExternalContentForFileAttr(self, *args): pass
    def affectsAnimation(self, *args): pass
    def attribute(self, *args): pass
    def attributeClass(self, *args): pass
    def attributeCount(self, *args): pass
    def canBeWritten(self, *args): pass
    def create(self, *args): pass
    def dgCallbackIds(self, *args): pass
    def dgCallbacks(self, *args): pass
    def dgTimer(self, *args): pass
    def dgTimerOff(self, *args): pass
    def dgTimerOn(self, *args): pass
    def dgTimerQueryState(self, *args): pass
    def dgTimerReset(self, *args): pass
    def findAlias(self, *args): pass
    def findPlug(self, *args): pass
    def getAffectedAttributes(self, *args): pass
    def getAffectedByAttributes(self, *args): pass
    def getAliasAttr(self, *args): pass
    def getAliasList(self, *args): pass
    def getConnections(self, *args): pass
    def getExternalContent(self, *args): pass
    def hasAttribute(self, *args): pass
    def hasUniqueName(self, *args): pass
    def icon(self, *args): pass
    def isDefaultNode(self, *args): pass
    def isFlagSet(self, *args): pass
    def isFromReferencedFile(self, *args): pass
    def isLocked(self, *args): pass
    def isNewAttribute(self, *args): pass
    def isShared(self, *args): pass
    def isTrackingEdits(self, *args): pass
    def name(self, *args): pass
    def parentNamespace(self, *args): pass
    def pluginName(self, *args): pass
    def plugsAlias(self, *args): pass
    def removeAttribute(self, *args): pass
    def reorderedAttribute(self, *args): pass
    def setAffectsAnimation(self, *args): pass
    def setAlias(self, *args): pass
    def setDoNotWrite(self, *args): pass
    def setExternalContent(self, *args): pass
    def setExternalContentForFileAttr(self, *args): pass
    def setFlag(self, *args): pass
    def setIcon(self, *args): pass
    def setLocked(self, *args): pass
    def setName(self, *args): pass
    def setUuid(self, *args): pass
    def type(self, *args): pass
    def typeId(self, *args): pass
    def typeName(self, *args): pass
    def userNode(self, *args): pass
    def uuid(self, *args): pass
    @staticmethod
    def allocateFlag(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def classification(*args, **kwargs): pass
    @staticmethod
    def deallocateAllFlags(*args, **kwargs): pass
    @staticmethod
    def deallocateFlag(*args, **kwargs): pass
    @staticmethod
    def enableDGTiming(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kExtensionAttr = 3
    
    
    kInvalidAttr = 4
    
    
    kLocalDynamicAttr = 1
    
    
    kNormalAttr = 2
    
    
    kTimerInvalidState = 3
    
    
    kTimerMetric_callback = 0
    
    
    kTimerMetric_callbackNotViaAPI = 6
    
    
    kTimerMetric_callbackViaAPI = 5
    
    
    kTimerMetric_compute = 1
    
    
    kTimerMetric_computeDuringCallback = 7
    
    
    kTimerMetric_computeNotDuringCallback = 8
    
    
    kTimerMetric_dirty = 2
    
    
    kTimerMetric_draw = 3
    
    
    kTimerMetric_fetch = 4
    
    
    kTimerMetrics = 9
    
    
    kTimerOff = 0
    
    
    kTimerOn = 1
    
    
    kTimerType_count = 2
    
    
    kTimerType_inclusive = 1
    
    
    kTimerType_self = 0
    
    
    kTimerTypes = 3
    
    
    kTimerUninitialized = 2


class MFnAttribute(MFnBase):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def accepts(self, *args): pass
    def acceptsAttribute(self, *args): pass
    def addToCategory(self, *args): pass
    def affectsAppearance(self, *args): pass
    def disconnectBehavior(self, *args): pass
    def getAddAttrCmd(self, *args): pass
    def getCategories(self, *args): pass
    def hasCategory(self, *args): pass
    def indexMatters(self, *args): pass
    def internal(self, *args): pass
    def isAffectsWorldSpace(self, *args): pass
    def isArray(self, *args): pass
    def isCached(self, *args): pass
    def isChannelBoxFlagSet(self, *args): pass
    def isConnectable(self, *args): pass
    def isDynamic(self, *args): pass
    def isExtension(self, *args): pass
    def isHidden(self, *args): pass
    def isIndeterminant(self, *args): pass
    def isKeyable(self, *args): pass
    def isProxyAttribute(self, *args): pass
    def isReadable(self, *args): pass
    def isRenderSource(self, *args): pass
    def isStorable(self, *args): pass
    def isUsedAsColor(self, *args): pass
    def isUsedAsFilename(self, *args): pass
    def isWorldSpace(self, *args): pass
    def isWritable(self, *args): pass
    def name(self, *args): pass
    def parent(self, *args): pass
    def removeFromCategory(self, *args): pass
    def setAffectsAppearance(self, *args): pass
    def setAffectsWorldSpace(self, *args): pass
    def setArray(self, *args): pass
    def setCached(self, *args): pass
    def setChannelBox(self, *args): pass
    def setConnectable(self, *args): pass
    def setDisconnectBehavior(self, *args): pass
    def setHidden(self, *args): pass
    def setIndeterminant(self, *args): pass
    def setIndexMatters(self, *args): pass
    def setInternal(self, *args): pass
    def setKeyable(self, *args): pass
    def setNiceNameOverride(self, *args): pass
    def setProxyAttribute(self, *args): pass
    def setReadable(self, *args): pass
    def setRenderSource(self, *args): pass
    def setStorable(self, *args): pass
    def setUsedAsColor(self, *args): pass
    def setUsedAsFilename(self, *args): pass
    def setUsesArrayDataBuilder(self, *args): pass
    def setWorldSpace(self, *args): pass
    def setWritable(self, *args): pass
    def shortName(self, *args): pass
    def type(self, *args): pass
    def usesArrayDataBuilder(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kDelete = 0
    
    
    kNothing = 2
    
    
    kReset = 1


class MTimerMessage(MMessage):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def addTimerCallback(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def setSleepCallback(*args, **kwargs): pass
    @staticmethod
    def sleepCallback(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MUserEventMessage(MMessage):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def addUserEventCallback(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def deregisterUserEvent(*args, **kwargs): pass
    @staticmethod
    def isUserEvent(*args, **kwargs): pass
    @staticmethod
    def postUserEvent(*args, **kwargs): pass
    @staticmethod
    def registerUserEvent(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFcurveEdit(MEdit):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args, **kwargs): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def editType(self, *args): pass
    def fcurve(self, *args): pass
    def fcurveName(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MConditionMessage(MMessage):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def addConditionCallback(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def getConditionNames(*args, **kwargs): pass
    @staticmethod
    def getConditionState(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MNodeMessage(MMessage):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def addAttributeAddedOrRemovedCallback(*args, **kwargs): pass
    @staticmethod
    def addAttributeChangedCallback(*args, **kwargs): pass
    @staticmethod
    def addKeyableChangeOverride(*args, **kwargs): pass
    @staticmethod
    def addNameChangedCallback(*args, **kwargs): pass
    @staticmethod
    def addNodeAboutToDeleteCallback(*args, **kwargs): pass
    @staticmethod
    def addNodeDestroyedCallback(*args, **kwargs): pass
    @staticmethod
    def addNodeDirtyCallback(*args, **kwargs): pass
    @staticmethod
    def addNodeDirtyPlugCallback(*args, **kwargs): pass
    @staticmethod
    def addNodePreRemovalCallback(*args, **kwargs): pass
    @staticmethod
    def addUuidChangedCallback(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kAttributeAdded = 64
    
    
    kAttributeArrayAdded = 4096
    
    
    kAttributeArrayRemoved = 8192
    
    
    kAttributeEval = 4
    
    
    kAttributeKeyable = 512
    
    
    kAttributeLocked = 16
    
    
    kAttributeRemoved = 128
    
    
    kAttributeRenamed = 256
    
    
    kAttributeSet = 8
    
    
    kAttributeUnkeyable = 1024
    
    
    kAttributeUnlocked = 32
    
    
    kConnectionBroken = 2
    
    
    kConnectionMade = 1
    
    
    kIncomingDirection = 2048
    
    
    kKeyChangeInvalid = 0
    
    
    kKeyChangeLast = 3
    
    
    kLast = 32768
    
    
    kMakeKeyable = 1
    
    
    kMakeUnkeyable = 2
    
    
    kOtherPlugSet = 16384


class MSceneMessage(MMessage):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def addCallback(*args, **kwargs): pass
    @staticmethod
    def addCheckCallback(*args, **kwargs): pass
    @staticmethod
    def addCheckFileCallback(*args, **kwargs): pass
    @staticmethod
    def addCheckReferenceCallback(*args, **kwargs): pass
    @staticmethod
    def addConnectionFailedCallback(*args, **kwargs): pass
    @staticmethod
    def addNamespaceRenamedCallback(*args, **kwargs): pass
    @staticmethod
    def addReferenceCallback(*args, **kwargs): pass
    @staticmethod
    def addStringArrayCallback(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kAfterCreateReference = 45
    
    
    kAfterCreateReferenceAndRecordEdits = 50
    
    
    kAfterExport = 11
    
    
    kAfterExportReference = 21
    
    
    kAfterFileRead = 8
    
    
    kAfterImport = 4
    
    
    kAfterImportReference = 19
    
    
    kAfterLoadReference = 37
    
    
    kAfterLoadReferenceAndRecordEdits = 48
    
    
    kAfterNew = 2
    
    
    kAfterOpen = 6
    
    
    kAfterPluginLoad = 41
    
    
    kAfterPluginUnload = 43
    
    
    kAfterReference = 15
    
    
    kAfterRemoveReference = 17
    
    
    kAfterSave = 13
    
    
    kAfterSceneReadAndRecordEdits = 9
    
    
    kAfterSoftwareFrameRender = 27
    
    
    kAfterSoftwareRender = 25
    
    
    kAfterUnloadReference = 23
    
    
    kBeforeCreateReference = 44
    
    
    kBeforeCreateReferenceAndRecordEdits = 49
    
    
    kBeforeCreateReferenceCheck = 39
    
    
    kBeforeExport = 10
    
    
    kBeforeExportCheck = 35
    
    
    kBeforeExportReference = 20
    
    
    kBeforeFileRead = 7
    
    
    kBeforeImport = 3
    
    
    kBeforeImportCheck = 34
    
    
    kBeforeImportReference = 18
    
    
    kBeforeLoadReference = 36
    
    
    kBeforeLoadReferenceAndRecordEdits = 47
    
    
    kBeforeLoadReferenceCheck = 38
    
    
    kBeforeNew = 1
    
    
    kBeforeNewCheck = 31
    
    
    kBeforeOpen = 5
    
    
    kBeforeOpenCheck = 32
    
    
    kBeforePluginLoad = 40
    
    
    kBeforePluginUnload = 42
    
    
    kBeforeReference = 14
    
    
    kBeforeReferenceCheck = 39
    
    
    kBeforeRemoveReference = 16
    
    
    kBeforeSave = 12
    
    
    kBeforeSaveCheck = 33
    
    
    kBeforeSoftwareFrameRender = 26
    
    
    kBeforeSoftwareRender = 24
    
    
    kBeforeUnloadReference = 22
    
    
    kExportStarted = 46
    
    
    kLast = 51
    
    
    kMayaExiting = 30
    
    
    kMayaInitialized = 29
    
    
    kSceneUpdate = 0
    
    
    kSoftwareRenderInterrupted = 28


class MDagMessage(MMessage):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def addAllDagChangesCallback(*args, **kwargs): pass
    @staticmethod
    def addAllDagChangesDagPathCallback(*args, **kwargs): pass
    @staticmethod
    def addChildAddedCallback(*args, **kwargs): pass
    @staticmethod
    def addChildAddedDagPathCallback(*args, **kwargs): pass
    @staticmethod
    def addChildRemovedCallback(*args, **kwargs): pass
    @staticmethod
    def addChildRemovedDagPathCallback(*args, **kwargs): pass
    @staticmethod
    def addChildReorderedCallback(*args, **kwargs): pass
    @staticmethod
    def addChildReorderedDagPathCallback(*args, **kwargs): pass
    @staticmethod
    def addDagCallback(*args, **kwargs): pass
    @staticmethod
    def addDagDagPathCallback(*args, **kwargs): pass
    @staticmethod
    def addInstanceAddedCallback(*args, **kwargs): pass
    @staticmethod
    def addInstanceAddedDagPathCallback(*args, **kwargs): pass
    @staticmethod
    def addInstanceRemovedCallback(*args, **kwargs): pass
    @staticmethod
    def addInstanceRemovedDagPathCallback(*args, **kwargs): pass
    @staticmethod
    def addParentAddedCallback(*args, **kwargs): pass
    @staticmethod
    def addParentAddedDagPathCallback(*args, **kwargs): pass
    @staticmethod
    def addParentRemovedCallback(*args, **kwargs): pass
    @staticmethod
    def addParentRemovedDagPathCallback(*args, **kwargs): pass
    @staticmethod
    def addWorldMatrixModifiedCallback(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kAll = 268435455
    
    
    kChildAdded = 2
    
    
    kChildRemoved = 3
    
    
    kChildReordered = 4
    
    
    kInstanceAdded = 5
    
    
    kInstanceRemoved = 6
    
    
    kInvalidMsg = -1
    
    
    kLast = 7
    
    
    kParentAdded = 0
    
    
    kParentRemoved = 1
    
    
    kRotateOrder = 134217728
    
    
    kRotateOrient = 117440512
    
    
    kRotateOrientX = 16777216
    
    
    kRotateOrientY = 33554432
    
    
    kRotateOrientZ = 67108864
    
    
    kRotatePivot = 229376
    
    
    kRotatePivotTrans = 14680064
    
    
    kRotatePivotX = 32768
    
    
    kRotatePivotY = 65536
    
    
    kRotatePivotZ = 131072
    
    
    kRotateTransX = 2097152
    
    
    kRotateTransY = 4194304
    
    
    kRotateTransZ = 8388608
    
    
    kRotateX = 64
    
    
    kRotateY = 128
    
    
    kRotateZ = 256
    
    
    kRotation = 448
    
    
    kScale = 7
    
    
    kScalePivot = 28672
    
    
    kScalePivotTrans = 1835008
    
    
    kScalePivotX = 4096
    
    
    kScalePivotY = 8192
    
    
    kScalePivotZ = 16384
    
    
    kScaleTransX = 262144
    
    
    kScaleTransY = 524288
    
    
    kScaleTransZ = 1048576
    
    
    kScaleX = 1
    
    
    kScaleY = 2
    
    
    kScaleZ = 4
    
    
    kShear = 56
    
    
    kShearXY = 8
    
    
    kShearXZ = 16
    
    
    kShearYZ = 32
    
    
    kTranslateX = 512
    
    
    kTranslateY = 1024
    
    
    kTranslateZ = 2048
    
    
    kTranslation = 3584


class MDagModifier(MDGModifier):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def createNode(self, *args): pass
    def reparentNode(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MParentingEdit(MEdit):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args, **kwargs): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def editType(self, *args): pass
    def parent(self, *args): pass
    def parentName(self, *args): pass
    def parentedObject(self, *args): pass
    def parentedObjectName(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MContainerMessage(MMessage):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def addBoundAttrCallback(*args, **kwargs): pass
    @staticmethod
    def addPublishAttrCallback(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MObjectSetMessage(MMessage):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def addSetMembersModifiedCallback(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnComponent(MFnBase):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def componentType(self, *args): pass
    def elementCount(self, *args): pass
    def hasWeights(self, *args): pass
    def isComplete(self, *args): pass
    def isEmpty(self, *args): pass
    def isEqual(self, *args): pass
    def setComplete(self, *args): pass
    def setWeight(self, *args): pass
    def setWeights(self, *args): pass
    def type(self, *args): pass
    def weight(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MSetAttrEdit(MEdit):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args, **kwargs): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def editType(self, *args): pass
    def plug(self, *args): pass
    def plugName(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MLockMessage(MMessage):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def setNodeLockDAGQueryCallback(*args, **kwargs): pass
    @staticmethod
    def setNodeLockQueryCallback(*args, **kwargs): pass
    @staticmethod
    def setPlugLockQueryCallback(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kAddAttr = 5
    
    
    kChildReorder = 4
    
    
    kCreateChildInstance = 6
    
    
    kCreateNodeInstance = 5
    
    
    kCreateParentInstance = 7
    
    
    kDelete = 2
    
    
    kGroup = 1
    
    
    kInvalid = 0
    
    
    kInvalidDAG = 0
    
    
    kInvalidPlug = 0
    
    
    kLast = 10
    
    
    kLastDAG = 8
    
    
    kLastPlug = 8
    
    
    kLockAttr = 9
    
    
    kLockNode = 3
    
    
    kPlugAttrValChange = 3
    
    
    kPlugConnect = 6
    
    
    kPlugDisconnect = 7
    
    
    kPlugLockAttr = 1
    
    
    kPlugRemoveAttr = 4
    
    
    kPlugRenameAttr = 5
    
    
    kPlugUnlockAttr = 2
    
    
    kRemoveAttr = 6
    
    
    kRename = 1
    
    
    kRenameAttr = 7
    
    
    kReparent = 3
    
    
    kUnGroup = 2
    
    
    kUnlockAttr = 8
    
    
    kUnlockNode = 4


class MCameraSetMessage(MMessage):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    @staticmethod
    def addCameraChangedCallback(*args, **kwargs): pass
    @staticmethod
    def addCameraLayerCallback(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnStringData(MFnData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def set(self, *args): pass
    def string(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnPhongEShader(MFnDependencyNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def highlightSize(self, *args): pass
    def roughness(self, *args): pass
    def setHighlightSize(self, *args): pass
    def setRoughness(self, *args): pass
    def setWhiteness(self, *args): pass
    def type(self, *args): pass
    def whiteness(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnLambertShader(MFnDependencyNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def ambientColor(self, *args): pass
    def color(self, *args): pass
    def create(self, *args): pass
    def diffuseCoeff(self, *args): pass
    def glowIntensity(self, *args): pass
    def hideSource(self, *args): pass
    def incandescence(self, *args): pass
    def refractedRayDepthLimit(self, *args): pass
    def refractiveIndex(self, *args): pass
    def rtRefractedColor(self, *args): pass
    def setAmbientColor(self, *args): pass
    def setColor(self, *args): pass
    def setDiffuseCoeff(self, *args): pass
    def setGlowIntensity(self, *args): pass
    def setHideSource(self, *args): pass
    def setIncandescence(self, *args): pass
    def setRefractedRayDepthLimit(self, *args): pass
    def setRefractiveIndex(self, *args): pass
    def setRtRefractedColor(self, *args): pass
    def setTranslucenceCoeff(self, *args): pass
    def setTransparency(self, *args): pass
    def translucenceCoeff(self, *args): pass
    def transparency(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnDoubleIndexedComponent(MFnComponent):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addElement(self, *args): pass
    def addElements(self, *args): pass
    def create(self, *args): pass
    def getCompleteData(self, *args): pass
    def getElement(self, *args): pass
    def getElements(self, *args): pass
    def setCompleteData(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnLightDataAttribute(MFnAttribute):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def child(self, *args): pass
    def create(self, *args): pass
    def getDefault(self, *args): pass
    def setDefault(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnMatrixAttribute(MFnAttribute):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def getDefault(self, *args): pass
    def setDefault(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kDouble = 1
    
    
    kFloat = 0


class MFnTypedAttribute(MFnAttribute):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def attrType(self, *args): pass
    def create(self, *args): pass
    def getDefault(self, *args): pass
    def setDefault(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnVectorArrayData(MFnData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def array(self, *args): pass
    def copyTo(self, *args): pass
    def create(self, *args): pass
    def length(self, *args): pass
    def set(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnDoubleArrayData(MFnData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def array(self, *args): pass
    def copyTo(self, *args): pass
    def create(self, *args): pass
    def length(self, *args): pass
    def set(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnCompoundAttribute(MFnAttribute):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addChild(self, *args): pass
    def child(self, *args): pass
    def create(self, *args): pass
    def getAddAttrCmds(self, *args): pass
    def numChildren(self, *args): pass
    def removeChild(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnContainerNode(MFnDependencyNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def clear(self, *args): pass
    def getMembers(self, *args): pass
    def getParentContainer(self, *args): pass
    def getPublishedNames(self, *args): pass
    def getPublishedNodes(self, *args): pass
    def getPublishedPlugs(self, *args): pass
    def getRootTransform(self, *args): pass
    def getSubcontainers(self, *args): pass
    def isCurrent(self, *args): pass
    def makeCurrent(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def getCurrentAsMObject(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kChildAnchor = 1
    
    
    kGeneric = 2
    
    
    kParentAnchor = 0


class MFnPointArrayData(MFnData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def array(self, *args): pass
    def copyTo(self, *args): pass
    def create(self, *args): pass
    def length(self, *args): pass
    def set(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnExpression(MFnDependencyNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def evaluate(self, *args): pass
    def expression(self, *args): pass
    def getDefaultObject(self, *args): pass
    def isAnimated(self, *args): pass
    def setAnimated(self, *args): pass
    def setDefaultObject(self, *args): pass
    def setExpression(self, *args): pass
    def setUnitConversion(self, *args): pass
    def type(self, *args): pass
    def unitConversion(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kAll = 0
    
    
    kAngularOnly = 2
    
    
    kNone = 1


class MFnMatrixData(MFnData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def isTransformation(self, *args): pass
    def matrix(self, *args): pass
    def set(self, *args): pass
    def transformation(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnGenericAttribute(MFnAttribute):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addAccept(self, *args): pass
    def addDataAccept(self, *args): pass
    def addNumericDataAccept(self, *args): pass
    def create(self, *args): pass
    def removeAccept(self, *args): pass
    def removeDataAccept(self, *args): pass
    def removeNumericDataAccept(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnUInt64ArrayData(MFnData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def array(self, *args): pass
    def copyTo(self, *args): pass
    def create(self, *args): pass
    def length(self, *args): pass
    def set(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnSet(MFnDependencyNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addMember(self, *args): pass
    def addMembers(self, *args): pass
    def annotation(self, *args): pass
    def clear(self, *args): pass
    def create(self, *args): pass
    def getIntersection(self, *args): pass
    def getMembers(self, *args): pass
    def getUnion(self, *args): pass
    def hasRestrictions(self, *args): pass
    def intersectsWith(self, *args): pass
    def isMember(self, *args): pass
    def removeMember(self, *args): pass
    def removeMembers(self, *args): pass
    def restriction(self, *args): pass
    def setAnnotation(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kEdgesOnly = 2
    
    
    kEditPointsOnly = 4
    
    
    kFacetsOnly = 3
    
    
    kNone = 0
    
    
    kRenderableOnly = 5
    
    
    kVerticesOnly = 1


class MFnNumericData(MFnData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def getData2Double(self, *args): pass
    def getData2Float(self, *args): pass
    def getData2Int(self, *args): pass
    def getData2Short(self, *args): pass
    def getData3Double(self, *args): pass
    def getData3Float(self, *args): pass
    def getData3Int(self, *args): pass
    def getData3Short(self, *args): pass
    def getData4Double(self, *args): pass
    def numericType(self, *args): pass
    def setData2Double(self, *args): pass
    def setData2Float(self, *args): pass
    def setData2Int(self, *args): pass
    def setData2Short(self, *args): pass
    def setData3Double(self, *args): pass
    def setData3Float(self, *args): pass
    def setData3Int(self, *args): pass
    def setData3Short(self, *args): pass
    def setData4Double(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    k2Double = 15
    
    
    k2Float = 12
    
    
    k2Int = 8
    
    
    k2Long = 8
    
    
    k2Short = 5
    
    
    k3Double = 16
    
    
    k3Float = 13
    
    
    k3Int = 9
    
    
    k3Long = 9
    
    
    k3Short = 6
    
    
    k4Double = 17
    
    
    kAddr = 18
    
    
    kBoolean = 1
    
    
    kByte = 2
    
    
    kChar = 3
    
    
    kDouble = 14
    
    
    kFloat = 11
    
    
    kInt = 7
    
    
    kInt64 = 10
    
    
    kInvalid = 0
    
    
    kLast = 19
    
    
    kLong = 7
    
    
    kShort = 4


class MFnMatrixArrayData(MFnData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def array(self, *args): pass
    def copyTo(self, *args): pass
    def create(self, *args): pass
    def length(self, *args): pass
    def set(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnPluginData(MFnData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def constData(self, *args): pass
    def create(self, *args): pass
    def data(self, *args): pass
    def type(self, *args): pass
    def typeId(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnEnumAttribute(MFnAttribute):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addField(self, *args): pass
    def create(self, *args): pass
    def defaultValue(self, *args): pass
    def fieldIndex(self, *args): pass
    def fieldName(self, *args): pass
    def getDefault(self, *args): pass
    def getMax(self, *args): pass
    def getMin(self, *args): pass
    def setDefault(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnPartition(MFnDependencyNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addMember(self, *args): pass
    def create(self, *args): pass
    def isRenderPartition(self, *args): pass
    def removeMember(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kEdgesOnly = 2
    
    
    kEditPointsOnly = 4
    
    
    kFacetsOnly = 3
    
    
    kNone = 0
    
    
    kRenderableOnly = 5
    
    
    kVerticesOnly = 1


class MFnNumericAttribute(MFnAttribute):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def child(self, *args): pass
    def create(self, *args): pass
    def createAddr(self, *args): pass
    def createColor(self, *args): pass
    def createPoint(self, *args): pass
    def getDefault(self, *args): pass
    def getMax(self, *args): pass
    def getMin(self, *args): pass
    def getSoftMax(self, *args): pass
    def getSoftMin(self, *args): pass
    def hasMax(self, *args): pass
    def hasMin(self, *args): pass
    def hasSoftMax(self, *args): pass
    def hasSoftMin(self, *args): pass
    def setDefault(self, *args): pass
    def setMax(self, *args): pass
    def setMin(self, *args): pass
    def setSoftMax(self, *args): pass
    def setSoftMin(self, *args): pass
    def type(self, *args): pass
    def unitType(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnFloatArrayData(MFnData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def array(self, *args): pass
    def copyTo(self, *args): pass
    def create(self, *args): pass
    def length(self, *args): pass
    def set(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnDagNode(MFnDependencyNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def activeColor(self, *args): pass
    def addChild(self, *args): pass
    def boundingBox(self, *args): pass
    def child(self, *args): pass
    def childCount(self, *args): pass
    def create(self, *args): pass
    def dagPath(self, *args): pass
    def dagRoot(self, *args): pass
    def dormantColor(self, *args): pass
    def drawOverrideColor(self, *args): pass
    def drawOverrideEnabled(self, *args): pass
    def drawOverrideIsReference(self, *args): pass
    def drawOverrideIsTemplate(self, *args): pass
    def duplicate(self, *args): pass
    def fullPathName(self, *args): pass
    def getAllPaths(self, *args): pass
    def getConnectedSetsAndMembers(self, *args): pass
    def getPath(self, *args): pass
    def hasChild(self, *args): pass
    def hasParent(self, *args): pass
    def hiliteColor(self, *args): pass
    def inModel(self, *args): pass
    def inUnderWorld(self, *args): pass
    def instanceCount(self, *args): pass
    def isChildOf(self, *args): pass
    def isInstanceable(self, *args): pass
    def isInstanced(self, *args): pass
    def isInstancedAttribute(self, *args): pass
    def isIntermediateObject(self, *args): pass
    def isParentOf(self, *args): pass
    def model(self, *args): pass
    def objectColor(self, *args): pass
    def objectColorIndex(self, *args): pass
    def objectColorRGB(self, *args): pass
    def objectColorType(self, *args): pass
    def objectGroupComponent(self, *args): pass
    def parent(self, *args): pass
    def parentCount(self, *args): pass
    def partialPathName(self, *args): pass
    def removeChild(self, *args): pass
    def removeChildAt(self, *args): pass
    def setInstanceable(self, *args): pass
    def setIntermediateObject(self, *args): pass
    def setObject(self, *args): pass
    def setObjectColor(self, *args): pass
    def setObjectColorType(self, *args): pass
    def setUseObjectColor(self, *args): pass
    def transformationMatrix(self, *args): pass
    def type(self, *args): pass
    def usingHiliteColor(self, *args): pass
    def usingObjectColor(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kNextPos = 255
    
    
    kUseDefaultColor = 0
    
    
    kUseIndexColor = 1
    
    
    kUseRGBColor = 2


class MFnMessageAttribute(MFnAttribute):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnLayeredShader(MFnDependencyNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def color(self, *args): pass
    def compositingFlag(self, *args): pass
    def create(self, *args): pass
    def glowColor(self, *args): pass
    def hardwareColor(self, *args): pass
    def hardwareShader(self, *args): pass
    def setColor(self, *args): pass
    def setCompositingFlag(self, *args): pass
    def setGlowColor(self, *args): pass
    def setHardwareColor(self, *args): pass
    def setHardwareShader(self, *args): pass
    def setTransparency(self, *args): pass
    def transparency(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnComponentListData(MFnData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def add(self, *args): pass
    def clear(self, *args): pass
    def create(self, *args): pass
    def has(self, *args): pass
    def length(self, *args): pass
    def remove(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnSingleIndexedComponent(MFnComponent):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addElement(self, *args): pass
    def addElements(self, *args): pass
    def create(self, *args): pass
    def element(self, *args): pass
    def elementMax(self, *args): pass
    def getCompleteData(self, *args): pass
    def getElements(self, *args): pass
    def setCompleteData(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnIntArrayData(MFnData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def array(self, *args): pass
    def copyTo(self, *args): pass
    def create(self, *args): pass
    def length(self, *args): pass
    def set(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnTripleIndexedComponent(MFnComponent):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addElement(self, *args): pass
    def addElements(self, *args): pass
    def create(self, *args): pass
    def getCompleteData(self, *args): pass
    def getElement(self, *args): pass
    def getElements(self, *args): pass
    def setCompleteData(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnGeometryData(MFnData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addObjectGroup(self, *args): pass
    def addObjectGroupComponent(self, *args): pass
    def changeObjectGroupId(self, *args): pass
    def copyObjectGroups(self, *args): pass
    def getMatrix(self, *args): pass
    def hasObjectGroup(self, *args): pass
    def matrixIsIdentity(self, *args): pass
    def matrixIsNotIdentity(self, *args): pass
    def objectGroup(self, *args): pass
    def objectGroupComponent(self, *args): pass
    def objectGroupCount(self, *args): pass
    def objectGroupType(self, *args): pass
    def removeObjectGroup(self, *args): pass
    def removeObjectGroupComponent(self, *args): pass
    def setMatrix(self, *args): pass
    def setObjectGroupComponent(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnAnisotropyShader(MFnDependencyNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def anisotropicReflectivity(self, *args): pass
    def correlationX(self, *args): pass
    def correlationY(self, *args): pass
    def create(self, *args): pass
    def refractiveIndex(self, *args): pass
    def rotateAngle(self, *args): pass
    def roughness(self, *args): pass
    def setAnisotropicReflectivity(self, *args): pass
    def setCorrelationX(self, *args): pass
    def setCorrelationY(self, *args): pass
    def setRefractiveIndex(self, *args): pass
    def setRotateAngle(self, *args): pass
    def setRoughness(self, *args): pass
    def setTangentUCamera(self, *args): pass
    def setTangentVCamera(self, *args): pass
    def tangentUCamera(self, *args): pass
    def tangentVCamera(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnCameraSet(MFnDependencyNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def appendLayer(self, *args): pass
    def clear(self, *args): pass
    def create(self, *args): pass
    def deleteLayer(self, *args): pass
    def getLayerCamera(self, *args): pass
    def getLayerClearDepthValue(self, *args): pass
    def getLayerOrder(self, *args): pass
    def getLayerSceneData(self, *args): pass
    def getNumLayers(self, *args): pass
    def getSortedIndices(self, *args): pass
    def insertLayer(self, *args): pass
    def isLayerActive(self, *args): pass
    def setLayerActive(self, *args): pass
    def setLayerCamera(self, *args): pass
    def setLayerClearDepthValue(self, *args): pass
    def setLayerOrder(self, *args): pass
    def setLayerSceneData(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnSphereData(MFnData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def radius(self, *args): pass
    def setRadius(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnUint64SingleIndexedComponent(MFnComponent):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addElement(self, *args): pass
    def addElements(self, *args): pass
    def create(self, *args): pass
    def element(self, *args): pass
    def getCompleteData(self, *args): pass
    def getElements(self, *args): pass
    def setCompleteData(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnArrayAttrsData(MFnData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def checkArrayExist(self, *args): pass
    def clear(self, *args): pass
    def count(self, *args): pass
    def create(self, *args): pass
    def doubleArray(self, *args): pass
    def getDoubleData(self, *args): pass
    def getIntData(self, *args): pass
    def getStringData(self, *args): pass
    def getVectorData(self, *args): pass
    def intArray(self, *args): pass
    def list(self, *args): pass
    def stringArray(self, *args): pass
    def type(self, *args): pass
    def vectorArray(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kDoubleArray = 2
    
    
    kIntArray = 3
    
    
    kInvalid = 0
    
    
    kLast = 5
    
    
    kStringArray = 4
    
    
    kVectorArray = 1


class MFnReference(MFnDependencyNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def associatedNamespace(self, *args): pass
    def containsNode(self, *args): pass
    def containsNodeExactly(self, *args): pass
    def fileName(self, *args): pass
    def isExportEditsFile(self, *args): pass
    def isLoaded(self, *args): pass
    def isLocked(self, *args): pass
    def nodes(self, *args): pass
    def parentAssembly(self, *args): pass
    def parentFileName(self, *args): pass
    def parentReference(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def ignoreReferenceEdits(*args, **kwargs): pass
    @staticmethod
    def setIgnoreReferenceEdits(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnStringArrayData(MFnData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __getitem__(self, *args): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def array(self, *args): pass
    def copyTo(self, *args): pass
    def create(self, *args): pass
    def length(self, *args): pass
    def set(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnUnitAttribute(MFnAttribute):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def getDefault(self, *args): pass
    def getMax(self, *args): pass
    def getMin(self, *args): pass
    def getSoftMax(self, *args): pass
    def getSoftMin(self, *args): pass
    def hasMax(self, *args): pass
    def hasMin(self, *args): pass
    def hasSoftMax(self, *args): pass
    def hasSoftMin(self, *args): pass
    def setDefault(self, *args): pass
    def setMax(self, *args): pass
    def setMin(self, *args): pass
    def setSoftMax(self, *args): pass
    def setSoftMin(self, *args): pass
    def type(self, *args): pass
    def unitType(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kAngle = 1
    
    
    kDistance = 2
    
    
    kInvalid = 0
    
    
    kLast = 4
    
    
    kTime = 3


class MFnAssembly(MFnDagNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def activate(self, *args): pass
    def activateNonRecursive(self, *args): pass
    def canActivate(self, *args): pass
    def canRepApplyEdits(self, *args): pass
    def createRepresentation(self, *args): pass
    def deleteAllRepresentations(self, *args): pass
    def deleteRepresentation(self, *args): pass
    def getAbsoluteRepNamespace(self, *args): pass
    def getActive(self, *args): pass
    def getInitialRep(self, *args): pass
    def getParentAssembly(self, *args): pass
    def getRepLabel(self, *args): pass
    def getRepNamespace(self, *args): pass
    def getRepType(self, *args): pass
    def getRepresentations(self, *args): pass
    def getSubAssemblies(self, *args): pass
    def handlesAddEdits(self, *args): pass
    def importFile(self, *args): pass
    def isActive(self, *args): pass
    def isTopLevel(self, *args): pass
    def postLoad(self, *args): pass
    def repTypes(self, *args): pass
    def setRepLabel(self, *args): pass
    def setRepName(self, *args): pass
    def supportsEdits(self, *args): pass
    def supportsMemberChanges(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def getTopLevelAssemblies(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnSubd(MFnDagNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def collapse(self, *args): pass
    def convertToNurbs(self, *args): pass
    def copy(self, *args): pass
    def creasesClearAll(self, *args): pass
    def creasesGetAll(self, *args): pass
    def creasesSetAll(self, *args): pass
    def createBaseMesh(self, *args): pass
    def edgeAdjacentPolygon(self, *args): pass
    def edgeBetween(self, *args): pass
    def edgeChildren(self, *args): pass
    def edgeCount(self, *args): pass
    def edgeCreaseRelevant(self, *args): pass
    def edgeIsBoundary(self, *args): pass
    def edgeIsCreased(self, *args): pass
    def edgeIsValid(self, *args): pass
    def edgeSetCrease(self, *args): pass
    def edgeVertices(self, *args): pass
    def editsPending(self, *args): pass
    def editsUpdateAll(self, *args): pass
    def evaluateNormal(self, *args): pass
    def evaluatePosition(self, *args): pass
    def evaluatePositionAndNormal(self, *args): pass
    def getConnectedShaders(self, *args): pass
    def getCubicSpline(self, *args): pass
    def levelFullySubdivideTo(self, *args): pass
    def levelMaxAllowed(self, *args): pass
    def levelMaxCurrent(self, *args): pass
    def polygonBaseMeshAdd(self, *args): pass
    def polygonBaseMeshAddWithUVs(self, *args): pass
    def polygonChildren(self, *args): pass
    def polygonCount(self, *args): pass
    def polygonCountMaxWithGivenBaseMesh(self, *args): pass
    def polygonEdgeCount(self, *args): pass
    def polygonEdges(self, *args): pass
    def polygonGetCenterUV(self, *args): pass
    def polygonGetVertexUVs(self, *args): pass
    def polygonHasChildren(self, *args): pass
    def polygonHasVertexUVs(self, *args): pass
    def polygonIsValid(self, *args): pass
    def polygonSetUseUVs(self, *args): pass
    def polygonSetVertexUVs(self, *args): pass
    def polygonSubdivide(self, *args): pass
    def polygonVertexCount(self, *args): pass
    def polygonVertices(self, *args): pass
    def tesselate(self, *args): pass
    def tessellateViaNurbs(self, *args): pass
    def type(self, *args): pass
    def updateAllEditsAndCreases(self, *args): pass
    def updateSubdSurface(self, *args): pass
    def vertexAdjacentVertices(self, *args): pass
    def vertexBaseIndexFromVertexId(self, *args): pass
    def vertexBaseMeshAdd(self, *args): pass
    def vertexBaseMeshAddWithIndex(self, *args): pass
    def vertexBaseMeshGet(self, *args): pass
    def vertexBaseMeshGetWithId(self, *args): pass
    def vertexBaseMeshSet(self, *args): pass
    def vertexBaseMeshSetWithId(self, *args): pass
    def vertexChildren(self, *args): pass
    def vertexCount(self, *args): pass
    def vertexCreaseRelevant(self, *args): pass
    def vertexEditGet(self, *args): pass
    def vertexEditSet(self, *args): pass
    def vertexEditsClearAllNonBase(self, *args): pass
    def vertexEditsGetAllNonBase(self, *args): pass
    def vertexEditsSetAllNonBase(self, *args): pass
    def vertexIdFromBaseVertexIndex(self, *args): pass
    def vertexIncidentEdges(self, *args): pass
    def vertexIncidentPolygons(self, *args): pass
    def vertexIsBoundary(self, *args): pass
    def vertexIsCreased(self, *args): pass
    def vertexIsValid(self, *args): pass
    def vertexNormal(self, *args): pass
    def vertexPositionGet(self, *args): pass
    def vertexPositionGetNoEdit(self, *args): pass
    def vertexPositionSet(self, *args): pass
    def vertexSetCrease(self, *args): pass
    def vertexValence(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnLight(MFnDagNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def centerOfIllumination(self, *args): pass
    def color(self, *args): pass
    def intensity(self, *args): pass
    def lightAmbient(self, *args): pass
    def lightDiffuse(self, *args): pass
    def lightDirection(self, *args): pass
    def lightIntensity(self, *args): pass
    def lightSpecular(self, *args): pass
    def numShadowSamples(self, *args): pass
    def opticalFXvisibility(self, *args): pass
    def rayDepthLimit(self, *args): pass
    def setCenterOfIllumination(self, *args): pass
    def setColor(self, *args): pass
    def setIntensity(self, *args): pass
    def setNumShadowSamples(self, *args): pass
    def setOpticalFXvisibility(self, *args): pass
    def setRayDepthLimit(self, *args): pass
    def setShadowColor(self, *args): pass
    def setUseRayTraceShadows(self, *args): pass
    def shadowColor(self, *args): pass
    def type(self, *args): pass
    def useRayTraceShadows(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnNurbsCurveData(MFnGeometryData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnSubdData(MFnGeometryData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnMeshData(MFnGeometryData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnTransform(MFnDagNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def clearRestPosition(self, *args): pass
    def create(self, *args): pass
    def enableLimit(self, *args): pass
    def getRotation(self, *args): pass
    def getRotationQuaternion(self, *args): pass
    def getScale(self, *args): pass
    def getShear(self, *args): pass
    def getTranslation(self, *args): pass
    def isLimited(self, *args): pass
    def limitValue(self, *args): pass
    def resetFromRestPosition(self, *args): pass
    def restPosition(self, *args): pass
    def rotateBy(self, *args): pass
    def rotateByQuaternion(self, *args): pass
    def rotateOrientation(self, *args): pass
    def rotatePivot(self, *args): pass
    def rotatePivotTranslation(self, *args): pass
    def rotationOrder(self, *args): pass
    def scaleBy(self, *args): pass
    def scalePivot(self, *args): pass
    def scalePivotTranslation(self, *args): pass
    def set(self, *args): pass
    def setLimit(self, *args): pass
    def setRestPosition(self, *args): pass
    def setRotateOrientation(self, *args): pass
    def setRotatePivot(self, *args): pass
    def setRotatePivotTranslation(self, *args): pass
    def setRotation(self, *args): pass
    def setRotationOrder(self, *args): pass
    def setRotationQuaternion(self, *args): pass
    def setScale(self, *args): pass
    def setScalePivot(self, *args): pass
    def setScalePivotTranslation(self, *args): pass
    def setShear(self, *args): pass
    def setTranslation(self, *args): pass
    def shearBy(self, *args): pass
    def transformation(self, *args): pass
    def translateBy(self, *args): pass
    def translation(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kRotateMaxX = 13
    
    
    kRotateMaxY = 15
    
    
    kRotateMaxZ = 17
    
    
    kRotateMinX = 12
    
    
    kRotateMinY = 14
    
    
    kRotateMinZ = 16
    
    
    kScaleMaxX = 1
    
    
    kScaleMaxY = 3
    
    
    kScaleMaxZ = 5
    
    
    kScaleMinX = 0
    
    
    kScaleMinY = 2
    
    
    kScaleMinZ = 4
    
    
    kShearMaxXY = 7
    
    
    kShearMaxXZ = 9
    
    
    kShearMaxYZ = 11
    
    
    kShearMinXY = 6
    
    
    kShearMinXZ = 8
    
    
    kShearMinYZ = 10
    
    
    kTranslateMaxX = 19
    
    
    kTranslateMaxY = 21
    
    
    kTranslateMaxZ = 23
    
    
    kTranslateMinX = 18
    
    
    kTranslateMinY = 20
    
    
    kTranslateMinZ = 22


class MFnNurbsSurfaceData(MFnGeometryData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnCamera(MFnDagNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def aspectRatio(self, *args): pass
    def cameraScale(self, *args): pass
    def centerOfInterest(self, *args): pass
    def centerOfInterestPoint(self, *args): pass
    def computeDepthOfField(self, *args): pass
    def copyViewFrom(self, *args): pass
    def create(self, *args): pass
    def eyePoint(self, *args): pass
    def fStop(self, *args): pass
    def farClippingPlane(self, *args): pass
    def farFocusDistance(self, *args): pass
    def filmFit(self, *args): pass
    def filmFitOffset(self, *args): pass
    def filmRollOrder(self, *args): pass
    def filmRollValue(self, *args): pass
    def filmTranslateH(self, *args): pass
    def filmTranslateV(self, *args): pass
    def focalLength(self, *args): pass
    def focusDistance(self, *args): pass
    def getAspectRatioLimits(self, *args): pass
    def getFilmApertureLimits(self, *args): pass
    def getFilmFrustum(self, *args): pass
    def getFocalLengthLimits(self, *args): pass
    def getPortFieldOfView(self, *args): pass
    def getRenderingFrustum(self, *args): pass
    def getViewParameters(self, *args): pass
    def getViewingFrustum(self, *args): pass
    def hasSamePerspective(self, *args): pass
    def horizontalFieldOfView(self, *args): pass
    def horizontalFilmAperture(self, *args): pass
    def horizontalFilmOffset(self, *args): pass
    def horizontalPan(self, *args): pass
    def horizontalRollPivot(self, *args): pass
    def horizontalShake(self, *args): pass
    def isClippingPlanes(self, *args): pass
    def isDepthOfField(self, *args): pass
    def isDisplayFilmGate(self, *args): pass
    def isDisplayGateMask(self, *args): pass
    def isMotionBlur(self, *args): pass
    def isOrtho(self, *args): pass
    def isVerticalLock(self, *args): pass
    def lensSqueezeRatio(self, *args): pass
    def nearClippingPlane(self, *args): pass
    def nearFocusDistance(self, *args): pass
    def orthoWidth(self, *args): pass
    def overscan(self, *args): pass
    def panZoomEnabled(self, *args): pass
    def postProjectionMatrix(self, *args): pass
    def postScale(self, *args): pass
    def preScale(self, *args): pass
    def projectionMatrix(self, *args): pass
    def renderPanZoom(self, *args): pass
    def rightDirection(self, *args): pass
    def set(self, *args): pass
    def setAspectRatio(self, *args): pass
    def setCameraScale(self, *args): pass
    def setCenterOfInterest(self, *args): pass
    def setCenterOfInterestPoint(self, *args): pass
    def setClippingPlanes(self, *args): pass
    def setDepthOfField(self, *args): pass
    def setDisplayFilmGate(self, *args): pass
    def setDisplayGateMask(self, *args): pass
    def setEyePoint(self, *args): pass
    def setFStop(self, *args): pass
    def setFarClippingPlane(self, *args): pass
    def setFarFocusDistance(self, *args): pass
    def setFilmFit(self, *args): pass
    def setFilmFitOffset(self, *args): pass
    def setFilmRollOrder(self, *args): pass
    def setFilmRollValue(self, *args): pass
    def setFilmTranslateH(self, *args): pass
    def setFilmTranslateV(self, *args): pass
    def setFocalLength(self, *args): pass
    def setFocusDistance(self, *args): pass
    def setHorizontalFieldOfView(self, *args): pass
    def setHorizontalFilmAperture(self, *args): pass
    def setHorizontalFilmOffset(self, *args): pass
    def setHorizontalPan(self, *args): pass
    def setHorizontalRollPivot(self, *args): pass
    def setHorizontalShake(self, *args): pass
    def setIsOrtho(self, *args): pass
    def setLensSqueezeRatio(self, *args): pass
    def setMotionBlur(self, *args): pass
    def setNearClippingPlane(self, *args): pass
    def setNearFarClippingPlanes(self, *args): pass
    def setNearFocusDistance(self, *args): pass
    def setOrthoWidth(self, *args): pass
    def setOverscan(self, *args): pass
    def setPanZoomEnabled(self, *args): pass
    def setPostScale(self, *args): pass
    def setPreScale(self, *args): pass
    def setRenderPanZoom(self, *args): pass
    def setShakeEnabled(self, *args): pass
    def setShakeOverscan(self, *args): pass
    def setShakeOverscanEnabled(self, *args): pass
    def setShutterAngle(self, *args): pass
    def setStereoHIT(self, *args): pass
    def setStereoHITEnabled(self, *args): pass
    def setTumblePivot(self, *args): pass
    def setUsePivotAsLocalSpace(self, *args): pass
    def setVerticalFieldOfView(self, *args): pass
    def setVerticalFilmAperture(self, *args): pass
    def setVerticalFilmOffset(self, *args): pass
    def setVerticalLock(self, *args): pass
    def setVerticalPan(self, *args): pass
    def setVerticalRollPivot(self, *args): pass
    def setVerticalShake(self, *args): pass
    def setZoom(self, *args): pass
    def shakeEnabled(self, *args): pass
    def shakeOverscan(self, *args): pass
    def shakeOverscanEnabled(self, *args): pass
    def shutterAngle(self, *args): pass
    def stereoHIT(self, *args): pass
    def stereoHITEnabled(self, *args): pass
    def tumblePivot(self, *args): pass
    def type(self, *args): pass
    def unnormalizedFarClippingPlane(self, *args): pass
    def unnormalizedNearClippingPlane(self, *args): pass
    def upDirection(self, *args): pass
    def usePivotAsLocalSpace(self, *args): pass
    def verticalFieldOfView(self, *args): pass
    def verticalFilmAperture(self, *args): pass
    def verticalFilmOffset(self, *args): pass
    def verticalPan(self, *args): pass
    def verticalRollPivot(self, *args): pass
    def verticalShake(self, *args): pass
    def viewDirection(self, *args): pass
    def zoom(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kFillFilmFit = 0
    
    
    kHorizontalFilmFit = 1
    
    
    kInvalid = 4
    
    
    kOverscanFilmFit = 3
    
    
    kRotateTranslate = 0
    
    
    kTranslateRotate = 1
    
    
    kVerticalFilmFit = 2


class MFnNurbsSurface(MFnDagNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def area(self, *args): pass
    def assignUV(self, *args): pass
    def assignUVs(self, *args): pass
    def boundaryType(self, *args): pass
    def clearUVs(self, *args): pass
    def closestPoint(self, *args): pass
    def copy(self, *args): pass
    def create(self, *args): pass
    def cv(self, *args): pass
    def cvsInU(self, *args): pass
    def cvsInV(self, *args): pass
    def degreeU(self, *args): pass
    def degreeV(self, *args): pass
    def distanceToPoint(self, *args): pass
    def edge(self, *args): pass
    def formInU(self, *args): pass
    def formInV(self, *args): pass
    def getAssignedUVs(self, *args): pass
    def getCV(self, *args): pass
    def getCVs(self, *args): pass
    def getConnectedShaders(self, *args): pass
    def getDataObject(self, *args): pass
    def getDerivativesAtParm(self, *args): pass
    def getKnotDomain(self, *args): pass
    def getKnotsInU(self, *args): pass
    def getKnotsInV(self, *args): pass
    def getParamAtPoint(self, *args): pass
    def getPatchUV(self, *args): pass
    def getPatchUVid(self, *args): pass
    def getPatchUVs(self, *args): pass
    def getPointAtParam(self, *args): pass
    def getTangents(self, *args): pass
    def getTrimBoundaries(self, *args): pass
    def getUV(self, *args): pass
    def getUVs(self, *args): pass
    def hasHistoryOnCreate(self, *args): pass
    def intersect(self, *args): pass
    def isBezier(self, *args): pass
    def isFlipNorm(self, *args): pass
    def isFoldedOnBispan(self, *args): pass
    def isKnotU(self, *args): pass
    def isKnotV(self, *args): pass
    def isParamOnSurface(self, *args): pass
    def isPointInTrimmedRegion(self, *args): pass
    def isPointOnSurface(self, *args): pass
    def isTrimmedSurface(self, *args): pass
    def isUniform(self, *args): pass
    def knotInU(self, *args): pass
    def knotInV(self, *args): pass
    def normal(self, *args): pass
    def numBoundaries(self, *args): pass
    def numCVsInU(self, *args): pass
    def numCVsInV(self, *args): pass
    def numEdges(self, *args): pass
    def numKnotsInU(self, *args): pass
    def numKnotsInV(self, *args): pass
    def numNonZeroSpansInU(self, *args): pass
    def numNonZeroSpansInV(self, *args): pass
    def numPatches(self, *args): pass
    def numPatchesInU(self, *args): pass
    def numPatchesInV(self, *args): pass
    def numRegions(self, *args): pass
    def numSpansInU(self, *args): pass
    def numSpansInV(self, *args): pass
    def numUVs(self, *args): pass
    def projectCurve(self, *args): pass
    def removeKnotInU(self, *args): pass
    def removeKnotInV(self, *args): pass
    def removeOneKnotInU(self, *args): pass
    def removeOneKnotInV(self, *args): pass
    def setCV(self, *args): pass
    def setCVs(self, *args): pass
    def setKnotInU(self, *args): pass
    def setKnotInV(self, *args): pass
    def setKnotsInU(self, *args): pass
    def setKnotsInV(self, *args): pass
    def setUV(self, *args): pass
    def setUVs(self, *args): pass
    def tesselate(self, *args): pass
    def trim(self, *args): pass
    def trimWithBoundaries(self, *args): pass
    def type(self, *args): pass
    def updateSurface(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kClosed = 2
    
    
    kClosedSegment = 4
    
    
    kInner = 2
    
    
    kInvalid = 0
    
    
    kInvalidBoundary = 0
    
    
    kLast = 4
    
    
    kOpen = 1
    
    
    kOuter = 1
    
    
    kPeriodic = 3
    
    
    kSegment = 3


class MFnMesh(MFnDagNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def addHoles(self, *args): pass
    def addPolygon(self, *args): pass
    def allIntersections(self, *args): pass
    def anyIntersection(self, *args): pass
    def assignColor(self, *args): pass
    def assignColors(self, *args): pass
    def assignUV(self, *args): pass
    def assignUVs(self, *args): pass
    def binaryBlindDataComponentId(self, *args): pass
    def booleanOp(self, *args): pass
    def booleanOps(self, *args): pass
    def cachedIntersectionAcceleratorInfo(self, *args): pass
    def cleanupEdgeSmoothing(self, *args): pass
    def clearBlindData(self, *args): pass
    def clearColors(self, *args): pass
    def clearUVs(self, *args): pass
    def closestIntersection(self, *args): pass
    def collapseEdges(self, *args): pass
    def collapseFaces(self, *args): pass
    def copy(self, *args): pass
    def copyInPlace(self, *args): pass
    def copyUVSetWithName(self, *args): pass
    def create(self, *args): pass
    def createBlindDataType(self, *args): pass
    def createColorSetDataMesh(self, *args): pass
    def createColorSetWithName(self, *args): pass
    def createColorSetWithNameDataMesh(self, *args): pass
    def createInPlace(self, *args): pass
    def createUVSetDataMeshWithName(self, *args): pass
    def createUVSetWithName(self, *args): pass
    def currentColorSetName(self, *args): pass
    def currentUVSetName(self, *args): pass
    def deleteColorSet(self, *args): pass
    def deleteEdge(self, *args): pass
    def deleteFace(self, *args): pass
    def deleteUVSet(self, *args): pass
    def deleteVertex(self, *args): pass
    def displayColors(self, *args): pass
    def duplicateFaces(self, *args): pass
    def extractFaces(self, *args): pass
    def extrudeEdges(self, *args): pass
    def extrudeFaces(self, *args): pass
    def freeCachedIntersectionAccelerator(self, *args): pass
    def generateSmoothMesh(self, *args): pass
    def getAssignedUVs(self, *args): pass
    def getAssociatedColorSetInstances(self, *args): pass
    def getAssociatedUVSetInstances(self, *args): pass
    def getAssociatedUVSetTextures(self, *args): pass
    def getAxisAtPoint(self, *args): pass
    def getBinaryBlindData(self, *args): pass
    def getBinormals(self, *args): pass
    def getBlindDataAttrNames(self, *args): pass
    def getBlindDataFaceVertexIndices(self, *args): pass
    def getBlindDataTypes(self, *args): pass
    def getBoolBlindData(self, *args): pass
    def getCheckSamePointTwice(self, *args): pass
    def getClosestNormal(self, *args): pass
    def getClosestPoint(self, *args): pass
    def getClosestPointAndNormal(self, *args): pass
    def getClosestUVs(self, *args): pass
    def getColor(self, *args): pass
    def getColorIndex(self, *args): pass
    def getColorRepresentation(self, *args): pass
    def getColorSetFamilyNames(self, *args): pass
    def getColorSetNames(self, *args): pass
    def getColorSetsInFamily(self, *args): pass
    def getColors(self, *args): pass
    def getConnectedShaders(self, *args): pass
    def getCreaseEdges(self, *args): pass
    def getCreaseVertices(self, *args): pass
    def getDoubleBlindData(self, *args): pass
    def getEdgeVertices(self, *args): pass
    def getFaceNormalIds(self, *args): pass
    def getFaceUVSetNames(self, *args): pass
    def getFaceVertexBinormal(self, *args): pass
    def getFaceVertexBinormals(self, *args): pass
    def getFaceVertexBlindDataIndex(self, *args): pass
    def getFaceVertexColorIndex(self, *args): pass
    def getFaceVertexColors(self, *args): pass
    def getFaceVertexNormal(self, *args): pass
    def getFaceVertexNormals(self, *args): pass
    def getFaceVertexTangent(self, *args): pass
    def getFaceVertexTangents(self, *args): pass
    def getFloatBlindData(self, *args): pass
    def getHoles(self, *args): pass
    def getIntBlindData(self, *args): pass
    def getInvisibleFaces(self, *args): pass
    def getNormalIds(self, *args): pass
    def getNormals(self, *args): pass
    def getPinUVs(self, *args): pass
    def getPoint(self, *args): pass
    def getPointAtUV(self, *args): pass
    def getPoints(self, *args): pass
    def getPointsAtUV(self, *args): pass
    def getPolygonNormal(self, *args): pass
    def getPolygonTriangleVertices(self, *args): pass
    def getPolygonUV(self, *args): pass
    def getPolygonUVid(self, *args): pass
    def getPolygonVertices(self, *args): pass
    def getRawDoublePoints(self, *args): pass
    def getRawNormals(self, *args): pass
    def getRawPoints(self, *args): pass
    def getSmoothMeshDisplayOptions(self, *args): pass
    def getStringBlindData(self, *args): pass
    def getTangentId(self, *args): pass
    def getTangents(self, *args): pass
    def getTriangleOffsets(self, *args): pass
    def getTriangles(self, *args): pass
    def getUV(self, *args): pass
    def getUVAtPoint(self, *args): pass
    def getUVSetFamilyNames(self, *args): pass
    def getUVSetNames(self, *args): pass
    def getUVSetsInFamily(self, *args): pass
    def getUVs(self, *args): pass
    def getUvShellsIds(self, *args): pass
    def getVertexColors(self, *args): pass
    def getVertexNormal(self, *args): pass
    def getVertexNormals(self, *args): pass
    def getVertices(self, *args): pass
    def hasAlphaChannels(self, *args): pass
    def hasBlindData(self, *args): pass
    def hasBlindDataComponentId(self, *args): pass
    def hasColorChannels(self, *args): pass
    def intersect(self, *args): pass
    def intersectFaceAtUV(self, *args): pass
    def isBlindDataTypeUsed(self, *args): pass
    def isColorClamped(self, *args): pass
    def isColorSetPerInstance(self, *args): pass
    def isEdgeSmooth(self, *args): pass
    def isNormalLocked(self, *args): pass
    def isPolygonConvex(self, *args): pass
    def isPolygonUVReversed(self, *args): pass
    def isRightHandedTangent(self, *args): pass
    def isUVSetPerInstance(self, *args): pass
    def lockFaceVertexNormals(self, *args): pass
    def lockVertexNormals(self, *args): pass
    def numColorSets(self, *args): pass
    def numColors(self, *args): pass
    def numEdges(self, *args): pass
    def numFaceVertices(self, *args): pass
    def numNormals(self, *args): pass
    def numPolygons(self, *args): pass
    def numUVSets(self, *args): pass
    def numUVs(self, *args): pass
    def numVertices(self, *args): pass
    def onBoundary(self, *args): pass
    def polygonVertexCount(self, *args): pass
    def removeFaceColors(self, *args): pass
    def removeFaceVertexColors(self, *args): pass
    def removeVertexColors(self, *args): pass
    def renameUVSet(self, *args): pass
    def setBinaryBlindData(self, *args): pass
    def setBoolBlindData(self, *args): pass
    def setCheckSamePointTwice(self, *args): pass
    def setColor(self, *args): pass
    def setColors(self, *args): pass
    def setCreaseEdges(self, *args): pass
    def setCreaseVertices(self, *args): pass
    def setCurrentColorSetName(self, *args): pass
    def setCurrentUVSetName(self, *args): pass
    def setDisplayColors(self, *args): pass
    def setDoubleBlindData(self, *args): pass
    def setEdgeSmoothing(self, *args): pass
    def setEdgeSmoothings(self, *args): pass
    def setFaceColor(self, *args): pass
    def setFaceColors(self, *args): pass
    def setFaceVertexColor(self, *args): pass
    def setFaceVertexColors(self, *args): pass
    def setFaceVertexNormal(self, *args): pass
    def setFaceVertexNormals(self, *args): pass
    def setFloatBlindData(self, *args): pass
    def setIntBlindData(self, *args): pass
    def setInvisibleFaces(self, *args): pass
    def setIsColorClamped(self, *args): pass
    def setNormals(self, *args): pass
    def setPinUVs(self, *args): pass
    def setPoint(self, *args): pass
    def setPoints(self, *args): pass
    def setSmoothMeshDisplayOptions(self, *args): pass
    def setSomeColors(self, *args): pass
    def setSomeUVs(self, *args): pass
    def setStringBlindData(self, *args): pass
    def setUV(self, *args): pass
    def setUVs(self, *args): pass
    def setVertexColor(self, *args): pass
    def setVertexColors(self, *args): pass
    def setVertexNormal(self, *args): pass
    def setVertexNormals(self, *args): pass
    def sortIntersectionFaceTriIds(self, *args): pass
    def split(self, *args): pass
    def stringBlindDataComponentId(self, *args): pass
    def subdivideEdges(self, *args): pass
    def subdivideFaces(self, *args): pass
    def syncObject(self, *args): pass
    def type(self, *args): pass
    def unlockFaceVertexNormals(self, *args): pass
    def unlockVertexNormals(self, *args): pass
    def updateSurface(self, *args): pass
    @staticmethod
    def autoUniformGridParams(*args, **kwargs): pass
    @staticmethod
    def className(*args, **kwargs): pass
    @staticmethod
    def clearGlobalIntersectionAcceleratorInfo(*args, **kwargs): pass
    @staticmethod
    def componentTypeFromName(*args, **kwargs): pass
    @staticmethod
    def componentTypeName(*args, **kwargs): pass
    @staticmethod
    def globalIntersectionAcceleratorsInfo(*args, **kwargs): pass
    @staticmethod
    def polyTriangulate(*args, **kwargs): pass
    @staticmethod
    def uniformGridParams(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kAlpha = 1
    
    
    kDifference = 2
    
    
    kInternalPoint = 1
    
    
    kIntersection = 3
    
    
    kInvalid = 2
    
    
    kOnEdge = 0
    
    
    kRGB = 3
    
    
    kRGBA = 4
    
    
    kUnion = 1


class MFnReflectShader(MFnLambertShader):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def reflectedColor(self, *args): pass
    def reflectedRayDepthLimit(self, *args): pass
    def reflectivity(self, *args): pass
    def setReflectedColor(self, *args): pass
    def setReflectedRayDepthLimit(self, *args): pass
    def setReflectivity(self, *args): pass
    def setSpecularColor(self, *args): pass
    def specularColor(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnNurbsCurve(MFnDagNode):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def area(self, *args): pass
    def closestPoint(self, *args): pass
    def copy(self, *args): pass
    def create(self, *args): pass
    def createWithEditPoints(self, *args): pass
    def cv(self, *args): pass
    def cvs(self, *args): pass
    def degree(self, *args): pass
    def distanceToPoint(self, *args): pass
    def findLengthFromParam(self, *args): pass
    def findParamFromLength(self, *args): pass
    def form(self, *args): pass
    def getCV(self, *args): pass
    def getCVs(self, *args): pass
    def getDerivativesAtParm(self, *args): pass
    def getKnotDomain(self, *args): pass
    def getKnots(self, *args): pass
    def getParamAtPoint(self, *args): pass
    def getPointAtParam(self, *args): pass
    def hasHistoryOnCreate(self, *args): pass
    def isParamOnCurve(self, *args): pass
    def isPlanar(self, *args): pass
    def isPointOnCurve(self, *args): pass
    def knot(self, *args): pass
    def length(self, *args): pass
    def makeMultipleEndKnots(self, *args): pass
    def normal(self, *args): pass
    def numCVs(self, *args): pass
    def numKnots(self, *args): pass
    def numSpans(self, *args): pass
    def rebuild(self, *args): pass
    def removeKnot(self, *args): pass
    def reverse(self, *args): pass
    def setCV(self, *args): pass
    def setCVs(self, *args): pass
    def setKnot(self, *args): pass
    def setKnots(self, *args): pass
    def tangent(self, *args): pass
    def type(self, *args): pass
    def updateCurve(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kClosed = 2
    
    
    kInvalid = 0
    
    
    kLast = 4
    
    
    kOpen = 1
    
    
    kPeriodic = 3


class MFnLatticeData(MFnGeometryData):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def lattice(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnNonAmbientLight(MFnLight):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def decayRate(self, *args): pass
    def setDecayRate(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnPhongShader(MFnReflectShader):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def cosPower(self, *args): pass
    def create(self, *args): pass
    def setCosPower(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnBlinnShader(MFnReflectShader):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def eccentricity(self, *args): pass
    def setEccentricity(self, *args): pass
    def setSpecularRollOff(self, *args): pass
    def specularRollOff(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnAmbientLight(MFnLight):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def ambientShade(self, *args): pass
    def castSoftShadows(self, *args): pass
    def create(self, *args): pass
    def setAmbientShade(self, *args): pass
    def setCastSoftShadows(self, *args): pass
    def setShadowRadius(self, *args): pass
    def shadowRadius(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnNonExtendedLight(MFnNonAmbientLight):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def castSoftShadows(self, *args): pass
    def depthMapBias(self, *args): pass
    def depthMapFilterSize(self, *args): pass
    def depthMapFocus(self, *args): pass
    def depthMapResolution(self, *args): pass
    def depthMapWidthFocus(self, *args): pass
    def setCastSoftShadows(self, *args): pass
    def setDepthMapBias(self, *args): pass
    def setDepthMapFilterSize(self, *args): pass
    def setDepthMapFocus(self, *args): pass
    def setDepthMapResolution(self, *args): pass
    def setDepthMapWidthFocus(self, *args): pass
    def setShadowRadius(self, *args): pass
    def setUseDepthMapAutoFocus(self, *args): pass
    def setUseDepthMapShadows(self, *args): pass
    def shadowRadius(self, *args): pass
    def type(self, *args): pass
    def useDepthMapAutoFocus(self, *args): pass
    def useDepthMapShadows(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnPointLight(MFnNonExtendedLight):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnDirectionalLight(MFnNonExtendedLight):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def setShadowAngle(self, *args): pass
    def setUseLightPosition(self, *args): pass
    def shadowAngle(self, *args): pass
    def type(self, *args): pass
    def useLightPosition(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnSpotLight(MFnNonExtendedLight):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def barnDoorAngle(self, *args): pass
    def barnDoors(self, *args): pass
    def coneAngle(self, *args): pass
    def create(self, *args): pass
    def dropOff(self, *args): pass
    def endDistance(self, *args): pass
    def penumbraAngle(self, *args): pass
    def setBarnDoorAngle(self, *args): pass
    def setBarnDoors(self, *args): pass
    def setConeAngle(self, *args): pass
    def setDropOff(self, *args): pass
    def setEndDistance(self, *args): pass
    def setPenumbraAngle(self, *args): pass
    def setStartDistance(self, *args): pass
    def setUseDecayRegions(self, *args): pass
    def startDistance(self, *args): pass
    def type(self, *args): pass
    def useDecayRegions(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kBottom = 3
    
    
    kFirst = 0
    
    
    kLeft = 0
    
    
    kRight = 1
    
    
    kSecond = 1
    
    
    kThird = 2
    
    
    kTop = 2


class MFnAreaLight(MFnNonExtendedLight):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def create(self, *args): pass
    def type(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}


class MFnVolumeLight(MFnPointLight):
    def __del__(self): pass
    def __getattr__(self, name): pass
    def __init__(self, *args): pass
    def __repr__(self): pass
    def __setattr__(self, name, value): pass
    def arc(self, *args): pass
    def colorRamp(self, *args): pass
    def coneEndRadius(self, *args): pass
    def create(self, *args): pass
    def emitAmbient(self, *args): pass
    def lightShape(self, *args): pass
    def penumbraRamp(self, *args): pass
    def setArc(self, *args): pass
    def setConeEndRadius(self, *args): pass
    def setEmitAmbient(self, *args): pass
    def setLightShape(self, *args): pass
    def setShadowAngle(self, *args): pass
    def setVolumeLightDirection(self, *args): pass
    def shadowAngle(self, *args): pass
    def type(self, *args): pass
    def volumeLightDirection(self, *args): pass
    @staticmethod
    def className(*args, **kwargs): pass
    __swig_destroy__ = None
    
    
    __swig_getmethods__ = {}
    
    
    __swig_setmethods__ = {}
    
    
    kBoxVolume = 0
    
    
    kConeVolume = 3
    
    
    kCylinderVolume = 2
    
    
    kDownAxis = 2
    
    
    kInward = 1
    
    
    kOutward = 0
    
    
    kSphereVolume = 1




def MItMeshFaceVertex_swigregister(*args, **kwargs): pass
def MInt64Array_className(*args, **kwargs): pass
def MObjectHandle_objectHashCode(*args, **kwargs): pass
def MProfiler_setRecordingActive(*args, **kwargs): pass
def MFnSpotLight_swigregister(*args, **kwargs): pass
def MFnComponentListData_className(*args, **kwargs): pass
def MFnBlinnShader_swigregister(*args, **kwargs): pass
def MScriptUtil_getShort(*args, **kwargs): pass
def MGlobal_animSelectionMask(*args, **kwargs): pass
def MIffFile_className(*args, **kwargs): pass
def MSceneMessage_addConnectionFailedCallback(*args, **kwargs): pass
def MScriptUtil_setUintArray(*args, **kwargs): pass
def MScriptUtil_setCharArray(*args, **kwargs): pass
def MMeshIntersector_className(*args, **kwargs): pass
def MNodeMessage_addNodePreRemovalCallback(*args, **kwargs): pass
def MScriptUtil_getIntArrayItem(*args, **kwargs): pass
def MGlobal_addToModel(*args, **kwargs): pass
def MRenderPassRegistry_className(*args, **kwargs): pass
def MIteratorType_swigregister(*args, **kwargs): pass
def MTimeArray_swigregister(*args, **kwargs): pass
def MFnPointLight_swigregister(*args, **kwargs): pass
def MAngle_internalToUI(*args, **kwargs): pass
def MFnLightDataAttribute_swigregister(*args, **kwargs): pass
def MFnMatrixAttribute_className(*args, **kwargs): pass
def MSelectionList_className(*args, **kwargs): pass
def MPlug_className(*args, **kwargs): pass
def MGlobal_setObjectSelectionMask(*args, **kwargs): pass
def MAttributePattern_attrPattern(*args, **kwargs): pass
def MStreamUtils_readDouble(*args, **kwargs): pass
def MFileIO_importFile(*args, **kwargs): pass
def MGlobal_optionVarDoubleValue(*args, **kwargs): pass
def MArgParser_swigregister(*args, **kwargs): pass
def MTime_ticksPerSecond(*args, **kwargs): pass
def MGlobal_currentToolContext(*args, **kwargs): pass
def MItSelectionList_className(*args, **kwargs): pass
def MNamespace_relativeNames(*args, **kwargs): pass
def MFnSubdNames_baseFaceId(*args, **kwargs): pass
def array4dDouble_swigregister(*args, **kwargs): pass
def MTimerMessage_swigregister(*args, **kwargs): pass
def MDataBlock_swigregister(*args, **kwargs): pass
def MFnSubdNames_level(*args, **kwargs): pass
def MProfilingContextManager(*args, **kwds):
    """
    Context manager that defines a profiling scope around a block of code.
    
    Parameters
    ----------
    categoryId : int
            The index of the category which the event belongs to.
    colorIndex : MProfiler.ProfilingColor
            The color to draw the profiling result in Profiler Window.
    eventName : string
            The name of the event.
    description : string (optional)
            Description of the event.
    associatedNode : MObject (optional)
            The dependency node associated with the event.
    
    Example
    -------
    >>> import maya.OpenMaya as OM
    >>> categoryIndex = OM.MProfiler.addCategory("Python Scripts")
    >>> def Factorial(number):
    ...     # Instrument the following block of code:
    ...     with OM.MProfilingContextManager(categoryIndex, OM.MProfiler.kColorE_L1, "Factorial", "FactorialDesc"):
    ...             result = 1
    ...             for i in xrange(2, number+1):
    ...                     result *= i
    ...     return result
    ...
    >>>
    """
    pass
def MFileIO_isWritingFile(*args, **kwargs): pass
def MGlobal_className(*args, **kwargs): pass
def MFcurveEdit_swigregister(*args, **kwargs): pass
def MFnDependencyNode_allocateFlag(*args, **kwargs): pass
def MGlobal_optionVarExists(*args, **kwargs): pass
def MObjectHandle_swigregister(*args, **kwargs): pass
def MGlobal_mayaState(*args, **kwargs): pass
def MDagMessage_addDagDagPathCallback(*args, **kwargs): pass
def MGlobal_setAnimSelectionMask(*args, **kwargs): pass
def MGlobal_executeCommand(*args, **kwargs): pass
def MGlobal_setRichSelection(*args, **kwargs): pass
def MDAGDrawOverrideInfo_swigregister(*args, **kwargs): pass
def MDGMessage_addTimeChangeCallback(*args, **kwargs): pass
def floatPtr_swigregister(*args, **kwargs): pass
def MFnDoubleArrayData_swigregister(*args, **kwargs): pass
def MFnReflectShader_className(*args, **kwargs): pass
def MFileIO_beforeExportUserFileTranslator(*args, **kwargs): pass
def MUserEventMessage_addUserEventCallback(*args, **kwargs): pass
def MAngle_setUIUnit(*args, **kwargs): pass
def MSceneMessage_addCheckReferenceCallback(*args, **kwargs): pass
def MFnAmbientLight_className(*args, **kwargs): pass
def MFnAreaLight_className(*args, **kwargs): pass
def MProfiler_getCategoryName(*args, **kwargs): pass
def MProfiler_getThreadId(*args, **kwargs): pass
def MProfiler_isDataFromFile(*args, **kwargs): pass
def MPolyMessage_addColorSetChangedCallback(*args, **kwargs): pass
def MPolyMessage_deletedId(*args, **kwargs): pass
def MScriptUtil_setUcharArray(*args, **kwargs): pass
def MFileIO_isReferencingFile(*args, **kwargs): pass
def MAttributePattern_attrPatternCount(*args, **kwargs): pass
def MFnDependencyNode_swigregister(*args, **kwargs): pass
def MScriptUtil_createIntArrayFromList(*args, **kwargs): pass
def MScriptUtil_setUshortArray(*args, **kwargs): pass
def MContainerMessage_swigregister(*args, **kwargs): pass
def MDGMessage_addDelayedTimeChangeCallback(*args, **kwargs): pass
def MModelMessage_className(*args, **kwargs): pass
def MNurbsIntersector_swigregister(*args, **kwargs): pass
def MProfiler_eventEnd(*args, **kwargs): pass
def MFnDirectionalLight_swigregister(*args, **kwargs): pass
def MScriptUtil_getShort4ArrayItem(*args, **kwargs): pass
def MFileIO_mustRenameToSaveMsg(*args, **kwargs): pass
def MRampAttribute_createCurveRamp(*args, **kwargs): pass
def MGlobal_optionVarIntValue(*args, **kwargs): pass
def MArgParser_className(*args, **kwargs): pass
def MTime_className(*args, **kwargs): pass
def MTransformationMatrix_swigregister(*args, **kwargs): pass
def MMessage_setRegisteringCallableScript(*args, **kwargs): pass
def MFnNurbsCurve_swigregister(*args, **kwargs): pass
def MNamespace_rootNamespace(*args, **kwargs): pass
def MFnSphereData_swigregister(*args, **kwargs): pass
def MDagPathArray_swigregister(*args, **kwargs): pass
def MFnMatrixData_swigregister(*args, **kwargs): pass
def MDataBlock_className(*args, **kwargs): pass
def MScriptUtil_setDouble3ArrayItem(*args, **kwargs): pass
def MDistance_swigregister(*args, **kwargs): pass
def uIntPtr_frompointer(*args, **kwargs): pass
def MGlobal_isRedoing(*args, **kwargs): pass
def MImage_className(*args, **kwargs): pass
def MAttributeIndex_swigregister(*args, **kwargs): pass
def MTimerMessage_sleepCallback(*args, **kwargs): pass
def MColorArray_swigregister(*args, **kwargs): pass
def MCommandMessage_swigregister(*args, **kwargs): pass
def MFnSubd_swigregister(*args, **kwargs): pass
def MFnSubdNames_levelOneFaceId(*args, **kwargs): pass
def MFnPointLight_className(*args, **kwargs): pass
def MUserEventMessage_className(*args, **kwargs): pass
def MDGContextGuard_swigregister(*args, **kwargs): pass
def MFnSubdNames_parentFaceId(*args, **kwargs): pass
def MNamespace_validateName(*args, **kwargs): pass
def MScriptUtil_setUchar(*args, **kwargs): pass
def MImage_swigregister(*args, **kwargs): pass
def MFileIO_setMustRenameToSaveMsg(*args, **kwargs): pass
def MAngle_uiUnit(*args, **kwargs): pass
def MIntArray_className(*args, **kwargs): pass
def uIntRefValue(ptr): pass
def MAttributeSpecArray_swigregister(*args, **kwargs): pass
def MGlobal_setOptionVarValue(*args, **kwargs): pass
def MGlobal_getSelectionListByName(*args, **kwargs): pass
def MGlobal_unselect(*args, **kwargs): pass
def MFnPartition_className(*args, **kwargs): pass
def MFnStringData_className(*args, **kwargs): pass
def MGlobal_disableStow(*args, **kwargs): pass
def MFnEnumAttribute_className(*args, **kwargs): pass
def MFnVectorArrayData_swigregister(*args, **kwargs): pass
def MUserEventMessage_isUserEvent(*args, **kwargs): pass
def MFileIO_isImportingFile(*args, **kwargs): pass
def MFnBase_className(*args, **kwargs): pass
def MScriptUtil_setDouble4ArrayItem(*args, **kwargs): pass
def MTime_setUIUnit(*args, **kwargs): pass
def MItMeshEdge_swigregister(*args, **kwargs): pass
def weakref_proxy(*args, **kwargs):
    """
    proxy(object[, callback]) -- create a proxy object that weakly
    references 'object'.  'callback', if given, is called with a
    reference to the proxy when 'object' is about to be finalized.
    """
    pass
def boolRefValue(ptr): pass
def MModelMessage_addNodeRemovedFromModelCallback(*args, **kwargs): pass
def MFileIO_getFiles(*args, **kwargs): pass
def MNurbsIntersector_className(*args, **kwargs): pass
def MProfiler_getColor(*args, **kwargs): pass
def MDagModifier_swigregister(*args, **kwargs): pass
def MProfiler_addCategory(*args, **kwargs): pass
def MScriptUtil_setChar(*args, **kwargs): pass
def MFileIO_save(*args, **kwargs): pass
def MEventMessage_swigregister(*args, **kwargs): pass
def MScriptUtil_setInt(*args, **kwargs): pass
def MScriptUtil_getBool(*args, **kwargs): pass
def MScriptUtil_getShortArrayItem(*args, **kwargs): pass
def MCallbackIdArray_swigregister(*args, **kwargs): pass
def MScriptUtil_getInt2ArrayItem(*args, **kwargs): pass
def MMessage_nodeCallbacks(*args, **kwargs): pass
def MScriptUtil_setFloat2ArrayItem(*args, **kwargs): pass
def MScriptUtil_setShort2ArrayItem(*args, **kwargs): pass
def MLockMessage_swigregister(*args, **kwargs): pass
def MScriptUtil_getUint3ArrayItem(*args, **kwargs): pass
def MNamespace_moveNamespace(*args, **kwargs): pass
def MFnCamera_className(*args, **kwargs): pass
def MDagPathArray_className(*args, **kwargs): pass
def MPlug_swigregister(*args, **kwargs): pass
def MScriptUtil_getCharArrayItem(*args, **kwargs): pass
def MFnSubdNames_base(*args, **kwargs): pass
def MFileIO_removeReference(*args, **kwargs): pass
def MFnPartition_swigregister(*args, **kwargs): pass
def MFcurveEdit_className(*args, **kwargs): pass
def MAttributeIndex_className(*args, **kwargs): pass
def MFnDependencyNode_classification(*args, **kwargs): pass
def MFnGeometryData_swigregister(*args, **kwargs): pass
def MScriptUtil_getShort2ArrayItem(*args, **kwargs): pass
def MColorArray_className(*args, **kwargs): pass
def MDagMessage_addChildReorderedDagPathCallback(*args, **kwargs): pass
def MFnSpotLight_className(*args, **kwargs): pass
def MFnComponent_swigregister(*args, **kwargs): pass
def MItMeshVertex_className(*args, **kwargs): pass
def MDoubleArray_className(*args, **kwargs): pass
def MEvaluationManager_swigregister(*args, **kwargs): pass
def MFileIO_beforeImportUserFileTranslator(*args, **kwargs): pass
def MURI_swigregister(*args, **kwargs): pass
def MFileIO_beforeImportFilename(*args, **kwargs): pass
def MProfiler_getEventCount(*args, **kwargs): pass
def MAttributeSpecArray_className(*args, **kwargs): pass
def MFnNumericAttribute_className(*args, **kwargs): pass
def MNodeMessage_addNameChangedCallback(*args, **kwargs): pass
def intRefValue(ptr): pass
def MCameraSetMessage_className(*args, **kwargs): pass
def MPolyMessage_addUVSetChangedCallback(*args, **kwargs): pass
def MScriptUtil_setBoolArray(*args, **kwargs): pass
def MFileIO_fileCurrentlyLoading(*args, **kwargs): pass
def MFloatArray_swigregister(*args, **kwargs): pass
def MFnVectorArrayData_className(*args, **kwargs): pass
def MTime_uiUnit(*args, **kwargs): pass
def MCacheFormatDescription_swigregister(*args, **kwargs): pass
def MGlobal_getLiveList(*args, **kwargs): pass
def MGlobal_selectionMode(*args, **kwargs): pass
def MDataHandle_swigregister(*args, **kwargs): pass
def MDagMessage_addChildRemovedDagPathCallback(*args, **kwargs): pass
def MDagModifier_className(*args, **kwargs): pass
def MGlobal_optionVarStringValue(*args, **kwargs): pass
def MGlobal_isUndoing(*args, **kwargs): pass
def MFileIO_open(*args, **kwargs): pass
def MGlobal_setDisableStow(*args, **kwargs): pass
def floatRefValue(ptr): pass
def MFileIO_currentFile(*args, **kwargs): pass
def MCallbackIdArray_className(*args, **kwargs): pass
def MNodeMessage_addNodeDestroyedCallback(*args, **kwargs): pass
def MMessage_currentCallbackId(*args, **kwargs): pass
def MUserData_swigregister(*args, **kwargs): pass
def MFnAttribute_className(*args, **kwargs): pass
def MNamespace_getNamespaceObjects(*args, **kwargs): pass
def array3dInt_swigregister(*args, **kwargs): pass
def MDistance_className(*args, **kwargs): pass
def MFileIO_reference(*args, **kwargs): pass
def MGlobal_doErrorLogEntry(*args, **kwargs): pass
def MScriptUtil_setDouble(*args, **kwargs): pass
def MParentingEdit_swigregister(*args, **kwargs): pass
def MTimerMessage_className(*args, **kwargs): pass
def MScriptUtil_getUintArrayItem(*args, **kwargs): pass
def MTrimBoundaryArray_className(*args, **kwargs): pass
def MScriptUtil_setInt3ArrayItem(*args, **kwargs): pass
def MFnMesh_polyTriangulate(*args, **kwargs): pass
def MDagMessage_addChildReorderedCallback(*args, **kwargs): pass
def MWeight_className(*args, **kwargs): pass
def MScriptUtil_setUint4ArrayItem(*args, **kwargs): pass
def setRefValue(refObject, value): pass
def MFnSubdNames_baseFaceIdFromLong(*args, **kwargs): pass
def MEvaluationManager_className(*args, **kwargs): pass
def MGlobal_objectSelectionMask(*args, **kwargs): pass
def MRampAttribute_swigregister(*args, **kwargs): pass
def MScriptUtil_getInt4ArrayItem(*args, **kwargs): pass
def MBoundingBox_swigregister(*args, **kwargs): pass
def MFnPhongShader_className(*args, **kwargs): pass
def MStreamUtils_readInt(*args, **kwargs): pass
def MFnIntArrayData_className(*args, **kwargs): pass
def MFnLight_swigregister(*args, **kwargs): pass
def MSceneMessage_addCallback(*args, **kwargs): pass
def MFnNonExtendedLight_swigregister(*args, **kwargs): pass
def MScriptUtil_setFloat4ArrayItem(*args, **kwargs): pass
def MFnCompoundAttribute_className(*args, **kwargs): pass
def charPtr_frompointer(*args, **kwargs): pass
def MPolyMessage_addPolyTopologyChangedCallback(*args, **kwargs): pass
def MItSelectionList_swigregister(*args, **kwargs): pass
def MFileIO_saveReference(*args, **kwargs): pass
def MItSubdEdge_className(*args, **kwargs): pass
def MProfiler_eventBegin(*args, **kwargs): pass
def MGlobal_clearSelectionList(*args, **kwargs): pass
def MContainerMessage_className(*args, **kwargs): pass
def MGlobal_addToModelAt(*args, **kwargs): pass
def MFnSubdNames_path(*args, **kwargs): pass
def MScriptUtil_setFloat3ArrayItem(*args, **kwargs): pass
def MFnSubdNames_baseFaceIdFromIndex(*args, **kwargs): pass
def MFnComponent_className(*args, **kwargs): pass
def MFnSubd_className(*args, **kwargs): pass
def MFnExpression_className(*args, **kwargs): pass
def MGlobal_displayError(*args, **kwargs): pass
def MCommandResult_className(*args, **kwargs): pass
def MTrimBoundaryArray_swigregister(*args, **kwargs): pass
def boolPtr_swigregister(*args, **kwargs): pass
def MGlobal_mayaVersion(*args, **kwargs): pass
def createCharRef(): pass
def MGlobal_setActiveSelectionList(*args, **kwargs): pass
def MFloatArray_className(*args, **kwargs): pass
def MNamespace_renameNamespace(*args, **kwargs): pass
def MGlobal_isZAxisUp(*args, **kwargs): pass
def MDistance_uiToInternal(*args, **kwargs): pass
def MFnFloatArrayData_className(*args, **kwargs): pass
def MFileIO_getReferenceConnectionsBroken(*args, **kwargs): pass
def MFnNumericData_swigregister(*args, **kwargs): pass
def MScriptUtil_swigregister(*args, **kwargs): pass
def MItDependencyGraph_className(*args, **kwargs): pass
def MTimerMessage_addTimerCallback(*args, **kwargs): pass
def MNodeMessage_addNodeAboutToDeleteCallback(*args, **kwargs): pass
def array2dDouble_swigregister(*args, **kwargs): pass
def MCommandMessage_addProcCallback(*args, **kwargs): pass
def MWeight_swigregister(*args, **kwargs): pass
def MProfiler_getEventDuration(*args, **kwargs): pass
def MProfiler_resetRecording(*args, **kwargs): pass
def MInt64Array_swigregister(*args, **kwargs): pass
def MDGContext_swigregister(*args, **kwargs): pass
def MFnNumericData_className(*args, **kwargs): pass
def MFnSubdNames_levelOneFaceIdFromIndex(*args, **kwargs): pass
def MEvaluationManager_evaluationInExecution(*args, **kwargs): pass
def MFileIO_beforeReferenceFilename(*args, **kwargs): pass
def MArgList_swigregister(*args, **kwargs): pass
def MDagMessage_addInstanceRemovedCallback(*args, **kwargs): pass
def MScriptUtil_setDoubleArray(*args, **kwargs): pass
def MCacheConfigRuleRegistry_swigregister(*args, **kwargs): pass
def MMessageNode_swigregister(*args, **kwargs): pass
def MScriptUtil_setShort4ArrayItem(*args, **kwargs): pass
def MMessage_swigregister(*args, **kwargs): pass
def MScriptUtil_setDouble2ArrayItem(*args, **kwargs): pass
def MFnNurbsSurface_swigregister(*args, **kwargs): pass
def MScriptUtil_getDoubleArrayItem(*args, **kwargs): pass
def MFnStringArrayData_swigregister(*args, **kwargs): pass
def MCameraSetMessage_addCameraLayerCallback(*args, **kwargs): pass
def MFnDoubleIndexedComponent_swigregister(*args, **kwargs): pass
def MEvaluationNode_swigregister(*args, **kwargs): pass
def MMessage_registeringCallableScriptNewAPI(*args, **kwargs): pass
def MFileIO_cleanReference(*args, **kwargs): pass
def MFnFloatArrayData_swigregister(*args, **kwargs): pass
def MFnMesh_autoUniformGridParams(*args, **kwargs): pass
def MRenderPassRegistry_registerRenderPassDefinition(*args, **kwargs): pass
def MFnAssembly_getTopLevelAssemblies(*args, **kwargs): pass
def MFnLatticeData_swigregister(*args, **kwargs): pass
def MContainerMessage_addBoundAttrCallback(*args, **kwargs): pass
def MSceneMessage_addStringArrayCallback(*args, **kwargs): pass
def MModelMessage_addBeforeDuplicateCallback(*args, **kwargs): pass
def MDataHandle_className(*args, **kwargs): pass
def MFnSingleIndexedComponent_className(*args, **kwargs): pass
def MSelectionMask_getSelectionTypePriority(*args, **kwargs): pass
def MEdit_swigregister(*args, **kwargs): pass
def MFileIO_newFile(*args, **kwargs): pass
def MProfiler_setCategoryRecording(*args, **kwargs): pass
def MFnMessageAttribute_className(*args, **kwargs): pass
def MArrayDataHandle_swigregister(*args, **kwargs): pass
def MCacheConfigRuleRegistry_className(*args, **kwargs): pass
def MMessage_removeCallback(*args, **kwargs): pass
def doublePtr_swigregister(*args, **kwargs): pass
def MGlobal_executeCommandStringResult(*args, **kwargs): pass
def MLockMessage_className(*args, **kwargs): pass
def MNamespace_removeNamespace(*args, **kwargs): pass
def MFnReference_swigregister(*args, **kwargs): pass
def MFnSubdNames_nonBaseFaceEdges(*args, **kwargs): pass
def MDistance_internalToUI(*args, **kwargs): pass
def MFileIO_getReferenceConnectionsMade(*args, **kwargs): pass
def MGlobal_stopErrorLogging(*args, **kwargs): pass
def createShortRef(): pass
def MTimer_swigregister(*args, **kwargs): pass
def MCommandMessage_className(*args, **kwargs): pass
def MDagMessage_addChildRemovedCallback(*args, **kwargs): pass
def MGlobal_selectCommand(*args, **kwargs): pass
def shortPtr_frompointer(*args, **kwargs): pass
def MGlobal_executeCommandOnIdle(*args, **kwargs): pass
def MProfiler_categoryRecording(*args, **kwargs): pass
def MEvaluationManager_evaluationManagerActive(*args, **kwargs): pass
def MFileIO_beforeExportFilename(*args, **kwargs): pass
def MUuid_className(*args, **kwargs): pass
def MArgList_className(*args, **kwargs): pass
def MUserEventMessage_swigregister(*args, **kwargs): pass
def MStreamUtils_readChar(*args, **kwargs): pass
def MFileIO_saveAs(*args, **kwargs): pass
def MCacheConfigRuleRegistry_registeringCallableScript(*args, **kwargs): pass
def MFnMessageAttribute_swigregister(*args, **kwargs): pass
def MDagMessage_swigregister(*args, **kwargs): pass
def MNodeMessage_addAttributeAddedOrRemovedCallback(*args, **kwargs): pass
def MProfiler_loadRecording(*args, **kwargs): pass
def MDGMessage_swigregister(*args, **kwargs): pass
def MProfilingScope_swigregister(*args, **kwargs): pass
def MEvaluationNode_className(*args, **kwargs): pass
def MFileIO_getReferenceFileByNode(*args, **kwargs): pass
def MFnMesh_uniformGridParams(*args, **kwargs): pass
def MScriptUtil_createFloatMatrixFromList(*args, **kwargs): pass
def MContainerMessage_addPublishAttrCallback(*args, **kwargs): pass
def MFnArrayAttrsData_className(*args, **kwargs): pass
def MScriptUtil_getDouble4ArrayItem(*args, **kwargs): pass
def MDGContext_className(*args, **kwargs): pass
def MItMeshEdge_className(*args, **kwargs): pass
def MFileIO_getFileTypes(*args, **kwargs): pass
def MDagMessage_addWorldMatrixModifiedCallback(*args, **kwargs): pass
def MGlobal_displayWarning(*args, **kwargs): pass
def MGlobal_getAbsolutePathToResources(*args, **kwargs): pass
def MDagMessage_className(*args, **kwargs): pass
def _swig_repr(self): pass
def MFnLayeredShader_className(*args, **kwargs): pass
def MFnArrayAttrsData_swigregister(*args, **kwargs): pass
def MNamespace_parentNamespace(*args, **kwargs): pass
def MFnReference_setIgnoreReferenceEdits(*args, **kwargs): pass
def MSelectionList_swigregister(*args, **kwargs): pass
def MDistance_internalUnit(*args, **kwargs): pass
def MStreamUtils_stdErrorStream(*args, **kwargs): pass
def MEulerRotation_decompose(*args, **kwargs): pass
def MFileIO_getReferenceNodes(*args, **kwargs): pass
def MGlobal_errorLoggingIsOn(*args, **kwargs): pass
def MConnectDisconnectAttrEdit_swigregister(*args, **kwargs): pass
def MFloatVectorArray_swigregister(*args, **kwargs): pass
def uCharPtr_swigregister(*args, **kwargs): pass
def MFnTransform_className(*args, **kwargs): pass
def MCommandMessage_addCommandOutputFilterCallback(*args, **kwargs): pass
def MDagMessage_addChildAddedDagPathCallback(*args, **kwargs): pass
def MStreamUtils_readFloat(*args, **kwargs): pass
def MModelMessage_addNodeAddedToModelCallback(*args, **kwargs): pass
def MFnSubdNames_levelOneFaceIndexFromId(*args, **kwargs): pass
def MEvaluationManager_graphConstructionActive(*args, **kwargs): pass
def MFileIO_beforeSaveFilename(*args, **kwargs): pass
def MNamespace_currentNamespace(*args, **kwargs): pass
def MFloatPointArray_swigregister(*args, **kwargs): pass
def MStreamUtils_writeDouble(*args, **kwargs): pass
def MFileIO_beforeReferenceUserFileTranslator(*args, **kwargs): pass
def MGlobal_setErrorLogPathName(*args, **kwargs): pass
def MObjectSetMessage_className(*args, **kwargs): pass
def MGlobal_getAssociatedSets(*args, **kwargs): pass
def MItSubdFace_swigregister(*args, **kwargs): pass
def MMatrix_swigregister(*args, **kwargs): pass
def MGlobal_setMiscSelectionMask(*args, **kwargs): pass
def MFnComponentListData_swigregister(*args, **kwargs): pass
def MProfilingScope_className(*args, **kwargs): pass
def MScriptUtil_setFloatArray(*args, **kwargs): pass
def MFileIO_unloadReferenceByNode(*args, **kwargs): pass
def MRenderPassRegistry_getRenderPassDefinition(*args, **kwargs): pass
def MIntArray_swigregister(*args, **kwargs): pass
def MAttributeSpec_swigregister(*args, **kwargs): pass
def MNodeMessage_addNodeDirtyCallback(*args, **kwargs): pass
def MFnAssembly_className(*args, **kwargs): pass
def MConditionMessage_swigregister(*args, **kwargs): pass
def MPointOnMesh_swigregister(*args, **kwargs): pass
def MMatrixArray_swigregister(*args, **kwargs): pass
def MCacheConfigRuleRegistry_setRegisteringCallableScript(*args, **kwargs): pass
def MProfiler_className(*args, **kwargs): pass
def MFnSubdData_swigregister(*args, **kwargs): pass
def MPolyMessage_className(*args, **kwargs): pass
def MFnEnumAttribute_swigregister(*args, **kwargs): pass
def MFnAmbientLight_swigregister(*args, **kwargs): pass
def MFileIO_fileType(*args, **kwargs): pass
def MGlobal_displayInfo(*args, **kwargs): pass
def MAngle_internalUnit(*args, **kwargs): pass
def MScriptUtil_createFloatArrayFromList(*args, **kwargs): pass
def MMessage_registeringCallableScript(*args, **kwargs): pass
def MScriptUtil_getFloat2ArrayItem(*args, **kwargs): pass
def MLockMessage_setNodeLockDAGQueryCallback(*args, **kwargs): pass
def MScriptUtil_setUint2ArrayItem(*args, **kwargs): pass
def MFnLambertShader_className(*args, **kwargs): pass
def MFnPhongShader_swigregister(*args, **kwargs): pass
def MFnExpression_swigregister(*args, **kwargs): pass
def MGlobal_getFunctionSetList(*args, **kwargs): pass
def MGlobal_startErrorLogging(*args, **kwargs): pass
def MConnectDisconnectAttrEdit_className(*args, **kwargs): pass
def MFnPhongEShader_swigregister(*args, **kwargs): pass
def MFloatVectorArray_className(*args, **kwargs): pass
def uCharPtr_frompointer(*args, **kwargs): pass
def MFnIntArrayData_swigregister(*args, **kwargs): pass
def MCommandMessage_addCommandOutputCallback(*args, **kwargs): pass
def MDagMessage_addChildAddedCallback(*args, **kwargs): pass
def MFnMatrixAttribute_swigregister(*args, **kwargs): pass
def MDGContext_current(*args, **kwargs): pass
def MItMeshPolygon_className(*args, **kwargs): pass
def MProfiler_getCategoryIndex(*args, **kwargs): pass
def MFnLayeredShader_swigregister(*args, **kwargs): pass
def MGlobal_miscSelectionMask(*args, **kwargs): pass
def MMessage_setRegisteringCallableScriptNewAPI(*args, **kwargs): pass
def MFloatPointArray_className(*args, **kwargs): pass
def MStreamUtils_writeFloat(*args, **kwargs): pass
def MProfiler_getEventCategory(*args, **kwargs): pass
def MItSubdFace_className(*args, **kwargs): pass
def MMatrix_className(*args, **kwargs): pass
def MRenderPassDef_swigregister(*args, **kwargs): pass
def MNodeClass_swigregister(*args, **kwargs): pass
def charRefValue(ptr): pass
def MSceneMessage_addNamespaceRenamedCallback(*args, **kwargs): pass
def MScriptUtil_setShortArray(*args, **kwargs): pass
def MGlobal_getPreselectionHiliteList(*args, **kwargs): pass
def MNodeMessage_className(*args, **kwargs): pass
def MFloatVector_swigregister(*args, **kwargs): pass
def MColor_swigregister(*args, **kwargs): pass
def MGlobal_getRichSelection(*args, **kwargs): pass
def MGlobal_selectionMethod(*args, **kwargs): pass
def MGlobal_trackSelectionOrderEnabled(*args, **kwargs): pass
def MDGModifier_swigregister(*args, **kwargs): pass
def MGlobal_deleteNode(*args, **kwargs): pass
def MFnReflectShader_swigregister(*args, **kwargs): pass
def MScriptUtil_getUcharArrayItem(*args, **kwargs): pass
def MArrayDataBuilder_swigregister(*args, **kwargs): pass
def MGlobal_upAxis(*args, **kwargs): pass
def MUserEventMessage_postUserEvent(*args, **kwargs): pass
def uIntPtr_swigregister(*args, **kwargs): pass
def MArrayDataHandle_className(*args, **kwargs): pass
def MNodeMessage_addAttributeChangedCallback(*args, **kwargs): pass
def MPointArray_swigregister(*args, **kwargs): pass
def MFileIO_exportSelectedAnimFromReference(*args, **kwargs): pass
def MLockMessage_setNodeLockQueryCallback(*args, **kwargs): pass
def MNamespace_getNamespaces(*args, **kwargs): pass
def MVectorArray_className(*args, **kwargs): pass
def MProfiler_getBufferSize(*args, **kwargs): pass
def MPolyMessage_swigregister(*args, **kwargs): pass
def MFileIO_getReferences(*args, **kwargs): pass
def MGlobal_errorLogPathName(*args, **kwargs): pass
def MFloatMatrix_className(*args, **kwargs): pass
def MScriptUtil_setFloat(*args, **kwargs): pass
def MItDependencyGraph_swigregister(*args, **kwargs): pass
def MScriptUtil_getInt3ArrayItem(*args, **kwargs): pass
def MCommandMessage_addCommandCallback(*args, **kwargs): pass
def MDagMessage_addParentRemovedDagPathCallback(*args, **kwargs): pass
def MFnNurbsSurface_className(*args, **kwargs): pass
def MScriptUtil_getUint4ArrayItem(*args, **kwargs): pass
def MNamespace_swigregister(*args, **kwargs): pass
def MFnDoubleArrayData_className(*args, **kwargs): pass
def MFileIO_beforeOpenFilename(*args, **kwargs): pass
def MRampAttribute_className(*args, **kwargs): pass
def MStreamUtils_writeInt(*args, **kwargs): pass
def MCacheConfigRuleRegistry_unregisterFilter(*args, **kwargs): pass
def MFnLatticeData_className(*args, **kwargs): pass
def MFileIO_resetError(*args, **kwargs): pass
def MRichSelection_swigregister(*args, **kwargs): pass
def MFnSingleIndexedComponent_swigregister(*args, **kwargs): pass
def intPtr_frompointer(*args, **kwargs): pass
def MSceneMessage_addReferenceCallback(*args, **kwargs): pass
def MFnMatrixData_className(*args, **kwargs): pass
def MDGMessage_addNodeChangeUuidCheckCallback(*args, **kwargs): pass
def MScriptUtil_getDouble2ArrayItem(*args, **kwargs): pass
def MFnTripleIndexedComponent_className(*args, **kwargs): pass
def MUuid_swigregister(*args, **kwargs): pass
def MFileIO_loadReferenceByNode(*args, **kwargs): pass
def MRenderPassDef_className(*args, **kwargs): pass
def MSyntax_className(*args, **kwargs): pass
def MArrayDataBuilder_className(*args, **kwargs): pass
def array4dFloat_swigregister(*args, **kwargs): pass
def MGlobal_setPreselectionHiliteList(*args, **kwargs): pass
def MFnSubdNames_levelOneFaceIdFromLong(*args, **kwargs): pass
def MFnData_swigregister(*args, **kwargs): pass
def createUIntRef(): pass
def MFnPhongEShader_className(*args, **kwargs): pass
def MSpace_swigregister(*args, **kwargs): pass
def MFnDirectionalLight_className(*args, **kwargs): pass
def MFnUint64SingleIndexedComponent_swigregister(*args, **kwargs): pass
def MDistance_uiUnit(*args, **kwargs): pass
def MEdit_className(*args, **kwargs): pass
def MFloatPoint_className(*args, **kwargs): pass
def MAttributePattern_swigregister(*args, **kwargs): pass
def MGlobal_removeOptionVar(*args, **kwargs): pass
def MFnVolumeLight_swigregister(*args, **kwargs): pass
def MAngle_setInternalUnit(*args, **kwargs): pass
def intPtr_swigregister(*args, **kwargs): pass
def MItSurfaceCV_swigregister(*args, **kwargs): pass
def MNamespace_setCurrentNamespace(*args, **kwargs): pass
def MFnNonExtendedLight_className(*args, **kwargs): pass
def MGlobal_isYAxisUp(*args, **kwargs): pass
def floatPtr_frompointer(*args, **kwargs): pass
def MFnUint64SingleIndexedComponent_className(*args, **kwargs): pass
def MFileIO_exportAsReference(*args, **kwargs): pass
def MUserEventMessage_deregisterUserEvent(*args, **kwargs): pass
def MFnMesh_className(*args, **kwargs): pass
def MArgDatabase_swigregister(*args, **kwargs): pass
def MAttributePatternArray_swigregister(*args, **kwargs): pass
def MFnAssembly_swigregister(*args, **kwargs): pass
def MFnMesh_componentTypeName(*args, **kwargs): pass
def MDagMessage_addParentRemovedCallback(*args, **kwargs): pass
def MTransformationMatrix_className(*args, **kwargs): pass
def MProfiler_getEventTime(*args, **kwargs): pass
def MProfiler_eventDataAvailable(*args, **kwargs): pass
def MFnSubdNames_baseFaceIndexFromId(*args, **kwargs): pass
def MFnGenericAttribute_className(*args, **kwargs): pass
def MGlobal_select(*args, **kwargs): pass
def MFnNurbsCurveData_className(*args, **kwargs): pass
def MRampAttribute_createRamp(*args, **kwargs): pass
def MScriptUtil_setBool(*args, **kwargs): pass
def MStreamUtils_writeCharBuffer(*args, **kwargs): pass
def MCacheConfigRuleRegistry_registerFilter(*args, **kwargs): pass
def MScriptUtil_setInt4ArrayItem(*args, **kwargs): pass
def MDistance_setUIUnit(*args, **kwargs): pass
def MItGeometry_swigregister(*args, **kwargs): pass
def MObjectSetMessage_swigregister(*args, **kwargs): pass
def MDGMessage_addPreConnectionCallback(*args, **kwargs): pass
def MProfiler_swigregister(*args, **kwargs): pass
def MNodeMessage_addUuidChangedCallback(*args, **kwargs): pass
def MScriptUtil_getUchar(*args, **kwargs): pass
def MFileIO_loadReference(*args, **kwargs): pass
def MItDag_className(*args, **kwargs): pass
def MItEdits_swigregister(*args, **kwargs): pass
def MFnDagNode_swigregister(*args, **kwargs): pass
def MConditionMessage_className(*args, **kwargs): pass
def MSceneMessage_addCheckFileCallback(*args, **kwargs): pass
def MNodeMessage_swigregister(*args, **kwargs): pass
def createDoubleRef(): pass
def MPlugArray_swigregister(*args, **kwargs): pass
def MFnSubdData_className(*args, **kwargs): pass
def MCameraMessage_swigregister(*args, **kwargs): pass
def MScriptUtil_getBoolArrayItem(*args, **kwargs): pass
def doublePtr_frompointer(*args, **kwargs): pass
def MAttributePattern_className(*args, **kwargs): pass
def MGlobal_setTrackSelectionOrderEnabled(*args, **kwargs): pass
def MItSurfaceCV_className(*args, **kwargs): pass
def MFnContainerNode_className(*args, **kwargs): pass
def MFnAttribute_swigregister(*args, **kwargs): pass
def MPointOnNurbs_swigregister(*args, **kwargs): pass
def MFnSubdNames_nonBaseFaceVertices(*args, **kwargs): pass
def MFnSphereData_className(*args, **kwargs): pass
def MDagPath_getAllPathsTo(*args, **kwargs): pass
def MProfiler_removeCategory(*args, **kwargs): pass
def MFnTypedAttribute_swigregister(*args, **kwargs): pass
def MFnNonAmbientLight_swigregister(*args, **kwargs): pass
def MFileIO_exportSelectedAnim(*args, **kwargs): pass
def MArgDatabase_className(*args, **kwargs): pass
def MAttributePatternArray_className(*args, **kwargs): pass
def MFnLight_className(*args, **kwargs): pass
def MDagMessage_addParentAddedDagPathCallback(*args, **kwargs): pass
def MGlobal_setDisplayCVs(*args, **kwargs): pass
def MGlobal_setComponentSelectionMask(*args, **kwargs): pass
def MNodeClass_className(*args, **kwargs): pass
def MGlobal_sourceFile(*args, **kwargs): pass
def MPlane_swigregister(*args, **kwargs): pass
def MFnSubdNames_baseFaceIndex(*args, **kwargs): pass
def MURI_className(*args, **kwargs): pass
def MEventMessage_className(*args, **kwargs): pass
def MUserEventMessage_registerUserEvent(*args, **kwargs): pass
def MGlobal_unselectByName(*args, **kwargs): pass
def MFnReference_ignoreReferenceEdits(*args, **kwargs): pass
def array4dInt_swigregister(*args, **kwargs): pass
def MItDependencyNodes_swigregister(*args, **kwargs): pass
def MTypeId_swigregister(*args, **kwargs): pass
def MNodeMessage_addKeyableChangeOverride(*args, **kwargs): pass
def MCommandResult_swigregister(*args, **kwargs): pass
def MDagMessage_addInstanceRemovedDagPathCallback(*args, **kwargs): pass
def MFileIO_unloadReference(*args, **kwargs): pass
def MProfiler_getDescription(*args, **kwargs): pass
def MFnMatrixArrayData_swigregister(*args, **kwargs): pass
def MProfiler_saveRecording(*args, **kwargs): pass
def MDGMessage_addConnectionCallback(*args, **kwargs): pass
def MItCurveCV_swigregister(*args, **kwargs): pass
def MProfiler_getAllCategories(*args, **kwargs): pass
def MScriptUtil_getChar(*args, **kwargs): pass
def MFileIO_setError(*args, **kwargs): pass
def MFnNurbsCurveData_swigregister(*args, **kwargs): pass
def MAngle_swigregister(*args, **kwargs): pass
def MSceneMessage_swigregister(*args, **kwargs): pass
def MFloatMatrix_swigregister(*args, **kwargs): pass
def MScriptUtil_createMatrixFromList(*args, **kwargs): pass
def MMessage_removeCallbacks(*args, **kwargs): pass
def MScriptUtil_getShort3ArrayItem(*args, **kwargs): pass
def MFnData_className(*args, **kwargs): pass
def MScriptUtil_getFloat3ArrayItem(*args, **kwargs): pass
def MFnSet_swigregister(*args, **kwargs): pass
def MUintArray_swigregister(*args, **kwargs): pass
def MLockMessage_setPlugLockQueryCallback(*args, **kwargs): pass
def MScriptUtil_getUshortArrayItem(*args, **kwargs): pass
def MFnBase_swigregister(*args, **kwargs): pass
def MGlobal_setZAxisUp(*args, **kwargs): pass
def MRenderPassRegistry_swigregister(*args, **kwargs): pass
def MAttributeSpec_className(*args, **kwargs): pass
def createUCharRef(): pass
def MGlobal_getActiveSelectionList(*args, **kwargs): pass
def MQuaternion_swigregister(*args, **kwargs): pass
def createIntRef(): pass
def MURI_isValidURI(*args, **kwargs): pass
def MModelMessage_addCallback(*args, **kwargs): pass
def MCameraSetMessage_addCameraChangedCallback(*args, **kwargs): pass
def MDagPath_swigregister(*args, **kwargs): pass
def MPoint_swigregister(*args, **kwargs): pass
def MSetAttrEdit_swigregister(*args, **kwargs): pass
def MFileIO_exportAnim(*args, **kwargs): pass
def MGlobal_defaultErrorLogPathName(*args, **kwargs): pass
def MSelectionMask_swigregister(*args, **kwargs): pass
def MTesselationParams_className(*args, **kwargs): pass
def MDoubleArray_swigregister(*args, **kwargs): pass
def MDagMessage_addParentAddedCallback(*args, **kwargs): pass
def createFloatRef(): pass
def MFnNurbsSurfaceData_swigregister(*args, **kwargs): pass
def MProfiler_setBufferSize(*args, **kwargs): pass
def MFnPointArrayData_className(*args, **kwargs): pass
def MFnSubdNames_toSelectionIndices(*args, **kwargs): pass
def MModelMessage_addAfterDuplicateCallback(*args, **kwargs): pass
def MNamespace_namespaceExists(*args, **kwargs): pass
def MFnCameraSet_swigregister(*args, **kwargs): pass
def MFnUInt64ArrayData_className(*args, **kwargs): pass
def MEventMessage_getEventNames(*args, **kwargs): pass
def MFileIO_setMustRenameToSave(*args, **kwargs): pass
def MFnTripleIndexedComponent_swigregister(*args, **kwargs): pass
def MStreamUtils_stdOutStream(*args, **kwargs): pass
def MItDependencyNodes_className(*args, **kwargs): pass
def MObjectArray_swigregister(*args, **kwargs): pass
def MTypeId_className(*args, **kwargs): pass
def MMeshIsectAccelParams_swigregister(*args, **kwargs): pass
def MSetAttrEdit_className(*args, **kwargs): pass
def MGlobal_closeErrorLog(*args, **kwargs): pass
def MItDag_swigregister(*args, **kwargs): pass
def MFnSet_className(*args, **kwargs): pass
def MDGMessage_addNodeRemovedCallback(*args, **kwargs): pass
def MFnSubdNames_swigregister(*args, **kwargs): pass
def MUserData_className(*args, **kwargs): pass
def MFnUnitAttribute_swigregister(*args, **kwargs): pass
def MFnMatrixArrayData_className(*args, **kwargs): pass
def MMessage_stopRegisteringCallableScript(*args, **kwargs): pass
def MTimeArray_className(*args, **kwargs): pass
def doubleRefValue(ptr): pass
def MUint64Array_className(*args, **kwargs): pass
def MConditionMessage_getConditionNames(*args, **kwargs): pass
def MFnGenericAttribute_swigregister(*args, **kwargs): pass
def MItSubdVertex_swigregister(*args, **kwargs): pass
def MProfiler_getCategoryInfo(*args, **kwargs): pass
def MProfiler_getCPUId(*args, **kwargs): pass
def MProfiler_getNumberOfCPUs(*args, **kwargs): pass
def MFnCompoundAttribute_swigregister(*args, **kwargs): pass
def MEvaluationNodeIterator_swigregister(*args, **kwargs): pass
def MGlobal_setYAxisUp(*args, **kwargs): pass
def MFnNurbsCurve_className(*args, **kwargs): pass
def MScriptUtil_getDouble(*args, **kwargs): pass
def MSyntax_swigregister(*args, **kwargs): pass
def MFnAnisotropyShader_swigregister(*args, **kwargs): pass
def MScriptUtil_setIntArray(*args, **kwargs): pass
def MScriptUtil_getInt(*args, **kwargs): pass
def MScriptUtil_getUint2ArrayItem(*args, **kwargs): pass
def MNamespace_addNamespace(*args, **kwargs): pass
def MDistance_setInternalUnit(*args, **kwargs): pass
def MGlobal_setHiliteList(*args, **kwargs): pass
def MDagPath_getAPathTo(*args, **kwargs): pass
def MPoint_className(*args, **kwargs): pass
def MFnUInt64ArrayData_swigregister(*args, **kwargs): pass
def MRampAttribute_createColorRamp(*args, **kwargs): pass
def MFnMeshData_swigregister(*args, **kwargs): pass
def MItMeshFaceVertex_className(*args, **kwargs): pass
def MIffTag_swigregister(*args, **kwargs): pass
def MFnPluginData_className(*args, **kwargs): pass
def MFnDependencyNode_enableDGTiming(*args, **kwargs): pass
def MMessage_className(*args, **kwargs): pass
def MCurveAttribute_swigregister(*args, **kwargs): pass
def MScriptUtil_getFloat4ArrayItem(*args, **kwargs): pass
def MNamespace_makeNamepathAbsolute(*args, **kwargs): pass
def MPlane_className(*args, **kwargs): pass
def MFnSubdNames_toMUint64(*args, **kwargs): pass
def MStreamUtils_writeChar(*args, **kwargs): pass
def MEventMessage_addEventCallback(*args, **kwargs): pass
def MFileIO_mustRenameToSave(*args, **kwargs): pass
def MFileObject_swigregister(*args, **kwargs): pass
def MTesselationParams_swigregister(*args, **kwargs): pass
def MDagMessage_addInstanceAddedDagPathCallback(*args, **kwargs): pass
def MFnSubdNames_levelOneFaceAsLong(*args, **kwargs): pass
def MConditionMessage_getConditionState(*args, **kwargs): pass
def MFnStringArrayData_className(*args, **kwargs): pass
def MDGMessage_addNodeAddedCallback(*args, **kwargs): pass
def MFnSubdNames_className(*args, **kwargs): pass
def MScriptUtil_getUint(*args, **kwargs): pass
def MFileIO_getErrorStatus(*args, **kwargs): pass
def MAngle_className(*args, **kwargs): pass
def MTimerMessage_setSleepCallback(*args, **kwargs): pass
def MNamespace_className(*args, **kwargs): pass
def MUint64Array_swigregister(*args, **kwargs): pass
def MConditionMessage_addConditionCallback(*args, **kwargs): pass
def MItSubdVertex_className(*args, **kwargs): pass
def MGlobal_selectFromScreen(*args, **kwargs): pass
def MUintArray_className(*args, **kwargs): pass
def MGlobal_isSelected(*args, **kwargs): pass
def shortPtr_swigregister(*args, **kwargs): pass
def MGlobal_removeFromModel(*args, **kwargs): pass
def MFnStringData_swigregister(*args, **kwargs): pass
def MCameraMessage_className(*args, **kwargs): pass
def MFnTypedAttribute_className(*args, **kwargs): pass
def MEvaluationNodeIterator_className(*args, **kwargs): pass
def MFileIO_swigregister(*args, **kwargs): pass
def MFnMesh_clearGlobalIntersectionAcceleratorInfo(*args, **kwargs): pass
def array2dFloat_swigregister(*args, **kwargs): pass
def array3dDouble_swigregister(*args, **kwargs): pass
def MAddRemoveAttrEdit_className(*args, **kwargs): pass
def MPointArray_className(*args, **kwargs): pass
def MFnNumericAttribute_swigregister(*args, **kwargs): pass
def MModelMessage_swigregister(*args, **kwargs): pass
def MProfiler_getThreadDuration(*args, **kwargs): pass
def MCameraSetMessage_swigregister(*args, **kwargs): pass
def MDagPath_className(*args, **kwargs): pass
def MProfiler_getEventName(*args, **kwargs): pass
def MFileIO_exportAnimFromReference(*args, **kwargs): pass
def MFn_swigregister(*args, **kwargs): pass
def MFnCamera_swigregister(*args, **kwargs): pass
def MScriptUtil_setShort(*args, **kwargs): pass
def MSelectionMask_deregisterSelectionType(*args, **kwargs): pass
def MScriptUtil_setInt2ArrayItem(*args, **kwargs): pass
def MFnContainerNode_swigregister(*args, **kwargs): pass
def MCurveAttribute_className(*args, **kwargs): pass
def MObjectArray_className(*args, **kwargs): pass
def MNamespace_stripNamespaceFromName(*args, **kwargs): pass
def MMeshSmoothOptions_className(*args, **kwargs): pass
def shortRefValue(ptr): pass
def MFnSubdNames_fromMUint64(*args, **kwargs): pass
def MEulerRotation_swigregister(*args, **kwargs): pass
def MDagMessage_addDagCallback(*args, **kwargs): pass
def MFileIO_isSavingReference(*args, **kwargs): pass
def MFileObject_getResolvedFullName(*args, **kwargs): pass
def MItEdits_className(*args, **kwargs): pass
def MItInstancer_swigregister(*args, **kwargs): pass
def MRichSelection_className(*args, **kwargs): pass
def MDagMessage_addInstanceAddedCallback(*args, **kwargs): pass
def MFnLightDataAttribute_className(*args, **kwargs): pass
def _swig_getattr(self, class_type, name): pass
def MItMeshPolygon_swigregister(*args, **kwargs): pass
def MGlobal_selectByName(*args, **kwargs): pass
def MObjectSetMessage_addSetMembersModifiedCallback(*args, **kwargs): pass
def MFileIO_isReadingFile(*args, **kwargs): pass
def MDGMessage_addForceUpdateCallback(*args, **kwargs): pass
def MItMeshVertex_swigregister(*args, **kwargs): pass
def MFnDoubleIndexedComponent_className(*args, **kwargs): pass
def MFnGeometryData_className(*args, **kwargs): pass
def MScriptUtil_setUint3ArrayItem(*args, **kwargs): pass
def MFileIO_getLastTempFile(*args, **kwargs): pass
def MAngle_uiToInternal(*args, **kwargs): pass
def MSceneMessage_className(*args, **kwargs): pass
def _swig_setattr(self, class_type, name, value): pass
def MComputation_swigregister(*args, **kwargs): pass
def MProfiler_isSignalEvent(*args, **kwargs): pass
def MFnAreaLight_swigregister(*args, **kwargs): pass
def MFnSubdNames_first(*args, **kwargs): pass
def MCameraMessage_addEndManipulationCallback(*args, **kwargs): pass
def MObject_swigregister(*args, **kwargs): pass
def MFnNonAmbientLight_className(*args, **kwargs): pass
def MScriptUtil_getFloatArrayItem(*args, **kwargs): pass
def MFileIO_className(*args, **kwargs): pass
def MFnMesh_globalIntersectionAcceleratorsInfo(*args, **kwargs): pass
def MFnDependencyNode_className(*args, **kwargs): pass
def MFnDagNode_className(*args, **kwargs): pass
def MFileIO_beforeOpenUserFileTranslator(*args, **kwargs): pass
def MFnTransform_swigregister(*args, **kwargs): pass
def MGlobal_getHiliteList(*args, **kwargs): pass
def MPlugArray_className(*args, **kwargs): pass
def MGlobal_setSelectionMode(*args, **kwargs): pass
def MDGModifier_className(*args, **kwargs): pass
def MFnCameraSet_className(*args, **kwargs): pass
def MFileIO_exportAll(*args, **kwargs): pass
def _swig_setattr_nondynamic(self, class_type, name, value, static='1'): pass
def MItGeometry_className(*args, **kwargs): pass
def MSelectionMask_registerSelectionType(*args, **kwargs): pass
def MFnUnitAttribute_className(*args, **kwargs): pass
def MNodeMessage_addNodeDirtyPlugCallback(*args, **kwargs): pass
def MFnContainerNode_getCurrentAsMObject(*args, **kwargs): pass
def MCurveAttribute_createCurve(*args, **kwargs): pass
def MFileIO_beforeSaveUserFileTranslator(*args, **kwargs): pass
def MFnNurbsSurfaceData_className(*args, **kwargs): pass
def MNamespace_getNamespaceFromName(*args, **kwargs): pass
def MPolyMessage_addPolyComponentIdChangedCallback(*args, **kwargs): pass
def MFnPluginData_swigregister(*args, **kwargs): pass
def MProfiler_recordingActive(*args, **kwargs): pass
def MFnSubdNames_corner(*args, **kwargs): pass
def MMeshSmoothOptions_swigregister(*args, **kwargs): pass
def MFileIO_isNewingFile(*args, **kwargs): pass
def MFileObject_isAbsolutePath(*args, **kwargs): pass
def MScriptUtil_setUint(*args, **kwargs): pass
def MItCurveCV_className(*args, **kwargs): pass
def MFnDependencyNode_deallocateAllFlags(*args, **kwargs): pass
def MItInstancer_className(*args, **kwargs): pass
def MFnMesh_swigregister(*args, **kwargs): pass
def MDagMessage_addAllDagChangesDagPathCallback(*args, **kwargs): pass
def MFloatPoint_swigregister(*args, **kwargs): pass
def MFnLambertShader_swigregister(*args, **kwargs): pass
def MFnPointArrayData_swigregister(*args, **kwargs): pass
def MFileIO_currentlyReadingFileVersion(*args, **kwargs): pass
def MFnSubdNames_fromSelectionIndices(*args, **kwargs): pass
def MScriptUtil_getFloat(*args, **kwargs): pass
def uCharRefValue(ptr): pass
def MFileIO_exportType(*args, **kwargs): pass
def MIffFile_swigregister(*args, **kwargs): pass
def MGlobal_customVersion(*args, **kwargs): pass
def MStreamUtils_swigregister(*args, **kwargs): pass
def array3dFloat_swigregister(*args, **kwargs): pass
def MVector_swigregister(*args, **kwargs): pass
def MComputation_className(*args, **kwargs): pass
def MSceneMessage_addCheckCallback(*args, **kwargs): pass
def MMeshIntersector_swigregister(*args, **kwargs): pass
def MFnMesh_componentTypeFromName(*args, **kwargs): pass
def MFnBlinnShader_className(*args, **kwargs): pass
def MCameraMessage_addBeginManipulationCallback(*args, **kwargs): pass
def charPtr_swigregister(*args, **kwargs): pass
def MStreamUtils_readCharBuffer(*args, **kwargs): pass
def MFnVolumeLight_className(*args, **kwargs): pass
def MFileIO_latestMayaFileVersion(*args, **kwargs): pass
def MItSubdEdge_swigregister(*args, **kwargs): pass
def MImageFileInfo_swigregister(*args, **kwargs): pass
def MVectorArray_swigregister(*args, **kwargs): pass
def MFileIO_setCurrentFile(*args, **kwargs): pass
def MScriptUtil_setShort3ArrayItem(*args, **kwargs): pass
def createBoolRef(): pass
def MMatrixArray_className(*args, **kwargs): pass
def MFnAnisotropyShader_className(*args, **kwargs): pass
def MCacheFormatDescription_className(*args, **kwargs): pass
def MFileIO_exportSelected(*args, **kwargs): pass
def MFnMeshData_className(*args, **kwargs): pass
def MAddRemoveAttrEdit_swigregister(*args, **kwargs): pass
def MParentingEdit_className(*args, **kwargs): pass
def MDGMessage_addDelayedTimeChangeRunupCallback(*args, **kwargs): pass
def MTime_swigregister(*args, **kwargs): pass
def MGlobal_resetToDefaultErrorLogPathName(*args, **kwargs): pass
def MGlobal_apiVersion(*args, **kwargs): pass
def MCurveAttribute_createCurveAttr(*args, **kwargs): pass
def MGlobal_componentSelectionMask(*args, **kwargs): pass
def MNamespace_setRelativeNames(*args, **kwargs): pass
def MGlobal_viewFrame(*args, **kwargs): pass
def MAttributePattern_findPattern(*args, **kwargs): pass
def MGlobal_swigregister(*args, **kwargs): pass
def MFileIO_isOpeningFile(*args, **kwargs): pass
def boolPtr_frompointer(*args, **kwargs): pass
def MFnReference_className(*args, **kwargs): pass
def MProfiler_signalEvent(*args, **kwargs): pass
def MScriptUtil_getDouble3ArrayItem(*args, **kwargs): pass
def MFnDependencyNode_deallocateFlag(*args, **kwargs): pass
def MImage_filterExists(*args, **kwargs): pass
def MDagMessage_addAllDagChangesCallback(*args, **kwargs): pass


MAYA_API_VERSION = 20190000

MAYA_APP_VERSION = 2019

kMFnSubdPointTolerance = 1e-10

MVector_kTol = 1e-10

MPoint_kTol = 1e-10

cvar = None

kMFnNurbsEpsilon = 0.001

kMFnSubdTolerance = 0.001

kMFnMeshInstanceUnspecified = -1

kUnknownParameter = 'unknown'

kMFnMeshTolerance = 0.001

MTransformationMatrix_kTol = 1e-10

MMatrix_kTol = 1e-10

kDefaultNodeType = 'dependNode'

MFloatPoint_kTol = 1e-05

MFloatMatrix_kTol = 1e-05

STRICT = 1

kEulerRotationEpsilon = 1e-10

MFloatVector_kTol = 1e-05

MAYA_CUSTOM_VERSION_CLIENT = ''

kMFnMeshPointTolerance = 1e-10

MAYA_CUSTOM_VERSION_MAJOR = 0

kQuaternionEpsilon = 1e-10

MAYA_CUSTOM_VERSION = 20190000


